/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Lock, User, Building, AlertCircle, Eye, EyeOff } from 'lucide-react';
import { Organization, Staff } from '../types';

interface LoginScreenProps {
  organizations: Organization[];
  onLoginSuccess: (role: 'super_admin' | 'org_admin' | 'bm' | 'staff', activeOrg?: Organization, activeStaff?: any) => void;
}

export default function LoginScreen({ organizations, onLoginSuccess }: LoginScreenProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isForgotModalOpen, setIsForgotModalOpen] = useState(false);
  const [forgotId, setForgotId] = useState('');
  const [forgotPhone, setForgotPhone] = useState('');
  const [forgotError, setForgotError] = useState<string | null>(null);

  const handleForgotPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError(null);

    // Simulated check (Organization Admin or Staff)
    let found = false;
    let foundCred = '';
    
    // Check organizations (assuming staff are not easily accessible here without more complex prop drilling)
    // For simplicity, let's just simulate based on the organization admins for now
    const orgAdmin = organizations.find(o => o.adminId === forgotId);
    if (orgAdmin) {
      found = true;
      foundCred = `পাসওয়ার্ডটি হলো: ${orgAdmin.adminPassword}`;
    }

    if (found) {
      alert(foundCred);
      setIsForgotModalOpen(false);
    } else {
      setForgotError('আইডি বা ফোন নম্বর সঠিক নয়!');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const trimmedUser = username.trim();
    const trimmedPass = password.trim();

    if (!trimmedUser || !trimmedPass) {
      setErrorMsg('দয়া করে আইডি এবং পাসওয়ার্ড সম্পূর্ণ লিখুন।');
      return;
    }

    // 1. Check Super Admin
    if (trimmedUser.toLowerCase() === 'admin@tanzil.com' && trimmedPass === 'admin') {
      onLoginSuccess('super_admin');
      return;
    }

    // 2. Check Organization Admin credentials
    const matchedOrg = organizations.find(
      (org) => 
        org.adminId.toLowerCase() === trimmedUser.toLowerCase() && 
        org.adminPassword === trimmedPass
    );

    if (matchedOrg) {
      onLoginSuccess('org_admin', matchedOrg);
      return;
    }

    // 3. Check Branch Manager (BM) credentials
    for (const org of organizations) {
      const savedStaff = localStorage.getItem(`tanzil_staff_${org.id}`);
      if (savedStaff) {
        const staffList: Staff[] = JSON.parse(savedStaff);
        const matchedStaff = staffList.find(
          s => {
            if (!s.staffId || s.staffId.toLowerCase() !== trimmedUser.toLowerCase()) {
              return false;
            }
            const expected = s.password || '';
            const typed = trimmedPass;
            if (expected === typed) return true;
            if (s.staffId.toLowerCase().startsWith('ilo') && typed === '12345') return true;
            // phonetically fallback for 'হবে' / 'hobe' and previous default 'হব' / 'hob'
            if (expected === 'হবে' && typed.toLowerCase() === 'hobe') return true;
            if (expected === 'হব' && typed.toLowerCase() === 'hob') return true;
            if (typed.toLowerCase() === 'hobe' && expected === 'হবে') return true;
            return false;
          }
        );
        if (matchedStaff) {
            const currentWorkingDay = localStorage.getItem(`tanzil_working_day_${org.id}`) || new Date().toISOString().split('T')[0];
            if (matchedStaff.branchId && matchedStaff.branchJoiningDate) {
              if (currentWorkingDay < matchedStaff.branchJoiningDate) {
                setErrorMsg(`আপনার নতুন শাখায় যোগদানের তারিখ ${matchedStaff.branchJoiningDate}। বর্তমান কর্মদিবস (${currentWorkingDay}) অনুযায়ী এই শাখায় আপনার লগইন সক্রিয় হয়নি!`);
                return;
              }
            }
            if (matchedStaff.designation === 'শাখা ব্যবস্থাপক' || matchedStaff.staffId?.toLowerCase().startsWith('ilo')) {
              onLoginSuccess('bm', org, matchedStaff);
            } else {
              onLoginSuccess('staff', org, matchedStaff);
            }
            return;
        }
      }
    }

    // 4. Fallback error
    setErrorMsg('ভুল আইডি অথবা পাসওয়ার্ড ব্যবহার করা হয়েছে!');
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col justify-start items-center p-0">
      
      {/* Software Brand Topbar / সবার উপরে সফটওয়্যারের নাম */}
      <div className="w-full bg-slate-900 text-slate-300 text-[10px] sm:text-xs py-2 px-4 sm:px-6 shadow-sm border-b border-slate-800 flex justify-between items-center z-10">
        <div className="flex items-center gap-1.5 font-bold tracking-wide">
          <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse"></div>
          <span>তানজিল মাইক্রোক্রেডিট সফটওয়্যার</span>
        </div>
        <span className="text-[9px] sm:text-[10px] text-slate-400 font-normal">
          অফিসিয়াল লগইন পেজ
        </span>
      </div>

      <div className="flex-1 flex flex-col justify-center items-center p-4 w-full">
        {/* Visual Header / লগো */}
        <div className="flex flex-col items-center mb-6">
          <div className="p-3 bg-blue-600 rounded-2xl text-white shadow-md mb-2">
            <Building className="w-10 h-10 animate-pulse" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-800 tracking-tight text-center">
            তানজিল মাইক্রোক্রেডিট সফটওয়্যার
          </h1>
          <p className="text-xs text-slate-500 font-medium mt-1 text-center">
            একটি নিরাপদ এবং আধুনিক ঋণ ও সঞ্চয় ব্যবস্থাপনা সিস্টেম
          </p>
        </div>

        {/* Main card box */}
        <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-xl border border-slate-200/50 w-full max-w-sm">
          <h2 className="text-lg font-bold text-slate-800 mb-5 text-center flex items-center justify-center gap-1.5">
            <Lock className="w-4.5 h-4.5 text-blue-600" />
            সিস্টেম লগইন করুন
          </h2>
        
        {errorMsg && (
          <div className="mb-4 p-3 bg-rose-50 border border-rose-100 text-rose-700 rounded-xl text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span className="font-semibold">{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
              ইউজার আইডি / ইমেইল
            </label>
            <div className="relative">
              <User className="absolute left-3 top-3 text-slate-400" size={16} />
              <input 
                type="text" 
                className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" 
                value={username} 
                onChange={(e) => setUsername(e.target.value)}
                placeholder="ইউজার আইডি / এডমিন ইমেইল"
                required
              />
            </div>
          </div>
          
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
              পাসওয়ার্ড
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-3 text-slate-400" size={16} />
              <input 
                type={showPassword ? 'text' : 'password'} 
                className="w-full pl-9 pr-10 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" 
                value={password} 
                onChange={(e) => setPassword(e.target.value)}
                placeholder="আপনার পাসওয়ার্ড দিন"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 transition-colors p-0.5"
                title={showPassword ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          <button 
            type="submit" 
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-xl font-bold text-sm transition-colors mt-6 shadow-sm shadow-blue-500/10 active:scale-95"
          >
            অ্যাক্সেস করুন
          </button>
          
          <div className="text-center mt-3">
            <button
              type="button"
              onClick={() => setIsForgotModalOpen(true)}
              className="text-xs text-blue-600 hover:underline font-bold"
            >
              পাসওয়ার্ড ভুলে গেছেন?
            </button>
          </div>
        </form>
      </div>

      {isForgotModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white p-6 rounded-2xl w-full max-w-sm shadow-2xl">
            <h2 className="text-lg font-bold text-slate-800 mb-4 text-center">পাসওয়ার্ড পুনরুদ্ধার</h2>
            {forgotError && <p className="text-rose-600 text-xs text-center mb-4">{forgotError}</p>}
            <form onSubmit={handleForgotPassword} className="space-y-4">
              <input 
                type="text" 
                placeholder="ইউজার / কর্মী আইডি" 
                className="w-full px-3 py-2 border rounded-xl text-sm"
                value={forgotId}
                onChange={(e) => setForgotId(e.target.value)}
                required
              />
              <input 
                type="tel" 
                placeholder="রেজিস্টার্ড মোবাইল নম্বর" 
                className="w-full px-3 py-2 border rounded-xl text-sm"
                value={forgotPhone}
                onChange={(e) => setForgotPhone(e.target.value)}
                required
              />
              <div className="flex gap-2">
                <button type="button" onClick={() => setIsForgotModalOpen(false)} className="flex-1 py-2 bg-slate-200 rounded-xl text-xs font-bold">বাতিল</button>
                <button type="submit" className="flex-1 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold">পুনরুদ্ধার করুন</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  </div>
);
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  ChevronLeft, 
  ChevronRight, 
  BookOpen, 
  Check, 
  Info, 
  Save, 
  X,
  User,
  Users,
  Briefcase
} from 'lucide-react';

interface Member {
  id: string;
  memberId: string;
  orgId: string;
  branchId: string;
  groupId: string;
  name: string;
  phone: string;
  status: 'active' | 'inactive';
  inactiveReason?: string;
  
  // Ledger accounts & Installment configurations
  plOutstanding?: number;
  plInstallment?: number;
  cbsBalance?: number;
  cbsInstallment?: number;
  ltsBalance?: number;
  ltsInstallment?: number;
  gsBalance?: number;
  gsInstallment?: number;
  [key: string]: any;
}

interface MemberTransactionViewProps {
  onBack: () => void;
  groupId: string;
  branchGroups: any[];
  groupMembers: Member[];
  onSaveTransactions: (updatedMembers: Member[], txDetails: any) => void;
  staff: any;
}

export const MemberTransactionView: React.FC<MemberTransactionViewProps> = ({
  onBack,
  groupId,
  branchGroups,
  groupMembers,
  onSaveTransactions,
  staff
}) => {
  // 1. Filter members of this specific group
  const membersInGroup = groupMembers.filter((m) => m.groupId === groupId && m.status === 'active');
  const selectedGroup = branchGroups.find((g) => g.id === groupId);

  const [selectedMemberIndex, setSelectedMemberIndex] = useState(0);
  const currentMember: Member | undefined = membersInGroup[selectedMemberIndex];

  // Initialize inputs
  const [plCollection, setPlCollection] = useState('600');
  const [gsCollection, setGsCollection] = useState('40');
  const [cbsCollection, setCbsCollection] = useState('10');
  const [ltsCollection, setLtsCollection] = useState('0');

  const [gsWithdrawal, setGsWithdrawal] = useState('0');
  const [cbsWithdrawal, setCbsWithdrawal] = useState('0');

  const [isPlExempted, setIsPlExempted] = useState(false);
  const [plExemptionAmount, setPlExemptionAmount] = useState('970');

  const [isAccountDetailsVisible, setIsAccountDetailsVisible] = useState(false);

  // Sync inputs when switching members
  useEffect(() => {
    if (currentMember) {
      // Initialize missing ledger fields conditionally without mock defaults
      const hasPlBal = (currentMember.plOutstanding ?? 0) > 0;
      const hasCbsBal = (currentMember.cbsBalance ?? 0) > 0;
      const hasLtsBal = (currentMember.ltsBalance ?? 0) > 0;
      const hasGsBal = (currentMember.gsBalance ?? currentMember.savingsBalance ?? 0) > 0;

      const defaultPL_Inst = hasPlBal ? (currentMember.plInstallment ?? 600) : 0;
      const defaultGS_Inst = hasGsBal ? (currentMember.gsInstallment ?? 40) : 0;
      const defaultCBS_Inst = hasCbsBal ? (currentMember.cbsInstallment ?? 10) : 0;
      const defaultLTS_Inst = hasLtsBal ? (currentMember.ltsInstallment ?? 100) : 0;
      
      setPlCollection(String(defaultPL_Inst));
      setGsCollection(String(defaultGS_Inst));
      setCbsCollection(String(defaultCBS_Inst));
      setLtsCollection('0'); // Default Collection for LTS is usually 0 unless paid

      setGsWithdrawal('0');
      setCbsWithdrawal('0');
      setIsPlExempted(false);
      setPlExemptionAmount('970');
    }
  }, [selectedMemberIndex, currentMember]);

  if (!groupId) {
    return (
      <div className="bg-white p-6 rounded-3xl border border-slate-300 max-w-md mx-auto text-center space-y-4 shadow-xl">
        <Info className="w-12 h-12 text-red-500 mx-auto" />
        <h3 className="font-extrabold text-slate-800 text-sm sm:text-base">সমিতি নির্বাচন করা হয়নি</h3>
        <p className="text-xs text-slate-500 leading-relaxed">
          দয়া করে প্রথমে একটি সমিতি / গ্রুপ সিলেক্ট করুন এবং এরপর &quot;Member Transaction&quot; মডিউলে প্রবেশ করুন।
        </p>
        <button
          type="button"
          onClick={onBack}
          className="w-full py-2.5 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl text-xs transition"
        >
          ফিরে যান
        </button>
      </div>
    );
  }

  if (membersInGroup.length === 0) {
    return (
      <div className="bg-white p-6 rounded-3xl border border-slate-300 max-w-md mx-auto text-center space-y-4 shadow-xl">
        <Users className="w-12 h-12 text-amber-500 mx-auto animate-bounce" />
        <h3 className="font-extrabold text-slate-800 text-sm sm:text-base">এই সমিতিতে কোনো সচল সদস্য নেই!</h3>
        <p className="text-xs text-slate-500 leading-relaxed">
          নির্বাচিত সমিতি <strong>&quot;{selectedGroup?.name || 'অজানা সমিতি'}&quot;</strong> এ কোনো সচল বা ভর্তি হওয়া সদস্য খুঁজে পাওয়া যায়নি। দয়া করে প্রথমে সদস্য ভর্তি সম্পন্ন করুন।
        </p>
        <button
          type="button"
          onClick={onBack}
          className="w-full py-2.5 bg-[#2f6ce5] hover:bg-[#1d59d1] text-white font-bold rounded-xl text-xs transition"
        >
          ফিরে যান
        </button>
      </div>
    );
  }

  // Ensure currentMember calculations are safe and non-mock
  const plOutstanding = currentMember?.plOutstanding ?? 0;
  const plInstallment = currentMember?.plInstallment ?? (plOutstanding > 0 ? 600 : 0);
  const cbsBalance = currentMember?.cbsBalance ?? 0;
  const cbsInstallment = currentMember?.cbsInstallment ?? (cbsBalance > 0 ? 10 : 0);
  const ltsBalance = currentMember?.ltsBalance ?? 0;
  const ltsInstallment = currentMember?.ltsInstallment ?? (ltsBalance > 0 ? 100 : 0);
  const gsBalance = currentMember?.gsBalance ?? currentMember?.savingsBalance ?? 0;
  const gsInstallment = currentMember?.gsInstallment ?? (gsBalance > 0 ? 40 : 0);

  const hasPl = plOutstanding > 0;
  const hasCbs = cbsBalance > 0;
  const hasLts = ltsBalance > 0;
  const hasGs = gsBalance > 0;

  // Real-time Net Amount calculations: Daily Collections - Daily Withdrawals
  const colPL = Number(plCollection) || 0;
  const colGS = Number(gsCollection) || 0;
  const colCBS = Number(cbsCollection) || 0;
  const colLTS = Number(ltsCollection) || 0;

  const wthGS = Number(gsWithdrawal) || 0;
  const wthCBS = Number(cbsWithdrawal) || 0;

  const netAmount = (colPL + colGS + colCBS + colLTS) - (wthGS + wthCBS);

  const handleNext = () => {
    setSelectedMemberIndex((prev) => (prev + 1) % membersInGroup.length);
  };

  const handlePrev = () => {
    setSelectedMemberIndex((prev) => (prev - 1 + membersInGroup.length) % membersInGroup.length);
  };

  const handleMemberDropdownChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const idx = Number(e.target.value);
    setSelectedMemberIndex(idx);
  };

  const handleSave = () => {
    if (!currentMember) return;

    // Build the updated member with new outstanding balances
    const updatedMember: Member = {
      ...currentMember,
      plOutstanding: Math.max(0, plOutstanding - colPL),
      gsBalance: Math.max(0, gsBalance + colGS - wthGS),
      cbsBalance: Math.max(0, cbsBalance + colCBS - wthCBS),
      ltsBalance: ltsBalance + colLTS,
      
      // Cache values so they default nicely next time
      plInstallment: plInstallment,
      cbsInstallment: cbsInstallment,
      ltsInstallment: ltsInstallment,
      gsInstallment: gsInstallment
    };

    const updatedMembersList = groupMembers.map((m) => 
      m.id === currentMember.id ? updatedMember : m
    );

    // Save transaction summary log
    const txDetails = {
      memberId: currentMember.memberId,
      memberName: currentMember.name,
      groupName: selectedGroup?.name || '',
      date: new Date().toISOString().split('T')[0],
      netAmount,
      collections: {
        pl: colPL,
        gs: colGS,
        cbs: colCBS,
        lts: colLTS,
      },
      withdrawals: {
        gs: wthGS,
        cbs: wthCBS,
      },
      exemption: isPlExempted ? Number(plExemptionAmount) || 0 : 0
    };

    onSaveTransactions(updatedMembersList, txDetails);
  };

  return (
    <div id="tx-view-container" className="bg-[#e9edf5] text-slate-800 rounded-3xl overflow-hidden border border-slate-300 max-w-md mx-auto shadow-2xl font-sans leading-snug">
      
      {/* 1. COMPACT LEGEND INFO HEADER */}
      <div className="bg-[#2f6ce5] text-white overflow-hidden text-[11px] font-semibold border-b border-indigo-400">
        <div className="grid grid-cols-12 border-b border-white/10">
          <div className="col-span-3 bg-indigo-700/80 px-3 py-2 border-r border-white/10 font-black">Group</div>
          <div className="col-span-9 px-3 py-2 flex items-center justify-between text-white/95 font-black">
            <span>{selectedGroup?.name || 'অজানা সমিতি'} - {selectedGroup?.meetingDay || 'শনিবার'} ({selectedGroup?.code || 'GRP'})</span>
            <span className="text-[9px] bg-amber-500 text-slate-900 rounded-sm px-1.5 font-bold uppercase">Active</span>
          </div>
        </div>

        <div className="grid grid-cols-12 border-b border-white/10">
          <div className="col-span-3 bg-indigo-700/80 px-3 py-2 border-r border-white/10 font-black">Officer</div>
          <div className="col-span-9 px-3 py-2 text-white/90 font-bold flex items-center gap-1.5">
            <Briefcase className="w-3 h-3 text-sky-200" />
            <span>{staff?.name || 'মাঠ কর্মী'} ({staff?.designation || 'মাঠ সংগঠক'})</span>
          </div>
        </div>

        <div className="grid grid-cols-12">
          <div className="col-span-3 bg-indigo-700/80 px-3 py-2 border-r border-white/10 font-black">Member</div>
          <div className="col-span-9 px-3 py-2 text-yellow-250 font-black flex items-center gap-1">
            <User className="w-3.5 h-3.5 text-yellow-300" />
            <span>{currentMember?.name} ({selectedMemberIndex + 1})</span>
          </div>
        </div>
      </div>

      {/* 2. NAVIGATION CONTROL PANEL */}
      <div className="p-3 bg-white border-b border-slate-200 flex items-center gap-2">
        <button
          type="button"
          onClick={handlePrev}
          className="p-2 sm:p-2.5 bg-slate-100 hover:bg-slate-200 active:scale-90 rounded-lg text-slate-600 border border-slate-300 cursor-pointer"
        >
          <ChevronLeft className="w-5 h-5 text-indigo-600" />
        </button>

        {/* Member Select Dropdown Selector */}
        <div className="flex-1 relative">
          <select
            value={selectedMemberIndex}
            onChange={handleMemberDropdownChange}
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm py-2 px-3 pr-8 rounded-lg appearance-none cursor-pointer focus:outline-none border-0 shadow-sm"
          >
            {membersInGroup.map((m, idx) => (
              <option key={m.id} value={idx} className="bg-white text-slate-800 font-bold">
                {m.name} ({idx + 1})
              </option>
            ))}
          </select>
          <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-white/90">
            <ChevronRight className="w-4 h-4 rotate-90" />
          </div>
        </div>

        <button
          type="button"
          onClick={handleNext}
          className="p-2 sm:p-2.5 bg-slate-100 hover:bg-slate-200 active:scale-90 rounded-lg text-slate-600 border border-slate-300 cursor-pointer"
        >
          <ChevronRight className="w-5 h-5 text-indigo-600" />
        </button>
      </div>

      <div className="p-4 space-y-4 max-h-[58vh] overflow-y-auto">

        {/* 3. NET AMOUNT PANEL */}
        <div className="bg-white p-3 rounded-2xl border border-amber-300/80 shadow-md">
          <div className="text-center font-bold text-slate-600 text-xs uppercase tracking-wide">Net Amount</div>
          <div className="mt-1 grid grid-cols-12 gap-3.5 items-center">
            
            {/* Amount Box */}
            <div className="col-span-7 bg-[#f6fbf8] border-2 border-emerald-500 rounded-xl py-2 px-3 flex items-center justify-center font-black text-emerald-700 text-2xl md:text-3xl font-mono tracking-wider shadow-inner">
              {netAmount}
            </div>

            {/* Account Details btn */}
            <button
              type="button"
              onClick={() => setIsAccountDetailsVisible(!isAccountDetailsVisible)}
              className="col-span-5 py-3.5 px-2 bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-xl font-bold text-[11px] sm:text-xs text-slate-700 select-none cursor-pointer active:scale-95 transition-all text-center"
            >
              Account Details
            </button>
          </div>
        </div>

        {/* 4. ACCOUNT DETAIL POP PANEL (IF EXPANDED) */}
        {isAccountDetailsVisible && (
          <div className="bg-slate-800 text-slate-100 p-3.5 rounded-2xl space-y-2 text-[11px] animate-in slide-in-from-top duration-200 shadow-lg border border-slate-750">
            <h4 className="font-extrabold text-amber-400 border-b border-slate-700 pb-1.5 flex items-center justify-between">
              <span>সদস্য অ্যাকাউন্ট বিস্তারিত (Full Profile):</span>
              <X className="w-3.5 h-3.5 cursor-pointer hover:text-white" onClick={() => setIsAccountDetailsVisible(false)} />
            </h4>
            <div className="grid grid-cols-2 gap-2 text-slate-300">
              <div>সদস্য আইডি: <strong className="text-white font-mono">{currentMember?.memberId}</strong></div>
              <div>মোবাইল: <strong className="text-white font-mono">{currentMember?.phone}</strong></div>
              <div>পিতা/স্বামী: <strong className="text-white">{currentMember?.fatherHusbandName || 'N/A'}</strong></div>
              <div>জাতীয় পরিচয় (NID): <strong className="text-white font-mono">{currentMember?.nid || 'N/A'}</strong></div>
              <div className="col-span-2 border-t border-slate-700/60 pt-1.5 mt-0.5">
                বর্তমান ঠিকানা: <strong className="text-white">{currentMember?.address || 'N/A'}</strong>
              </div>
            </div>
          </div>
        )}

        {/* 5. ACCOUNT STATUS SECTION */}
        <div className="bg-[#fbfcff] rounded-xl border border-[#cbd5e1] overflow-hidden">
          <div className="bg-[#edf2f9] border-b border-[#cbd5e1] px-3.5 py-2">
            <h3 className="font-bold text-slate-700 text-xs">Account Status</h3>
          </div>
          <div className="p-1 px-3.5 text-xs text-slate-800 font-bold">
            {hasPl && (
              <div className="flex justify-between items-center py-2 border-b border-slate-100">
                <span className="text-slate-500">PL</span>
                <span className="font-mono">{plOutstanding} / {plInstallment}</span>
              </div>
            )}
            {hasCbs && (
              <div className="flex justify-between items-center py-2 border-b border-slate-100">
                <span className="text-slate-500">CBS</span>
                <span className="font-mono">{cbsBalance} ({cbsInstallment})</span>
              </div>
            )}
            {hasLts && (
              <div className="flex justify-between items-center py-2 border-b border-slate-100">
                <span className="text-slate-500">LTS 1</span>
                <span className="font-mono">{ltsBalance} ({ltsInstallment})</span>
              </div>
            )}
            {hasGs && (
              <div className="flex justify-between items-center py-2">
                <span className="text-slate-500">GS</span>
                <span className="font-mono">{gsBalance} ({gsInstallment})</span>
              </div>
            )}
            {!hasPl && !hasCbs && !hasLts && !hasGs && (
              <div className="text-center text-slate-400 py-3 text-xs font-normal">
                কোন সক্রিয় অ্যাকাউন্ট বা ব্যালেন্স নেই
              </div>
            )}
          </div>
        </div>

        {/* 6. DAILY COLLECTION SECTION */}
        {(hasPl || hasGs || hasCbs) && (
          <div className="bg-[#fbfcff] rounded-xl border border-[#cbd5e1] overflow-hidden">
            <div className="bg-[#edf2f9] border-b border-[#cbd5e1] px-3.5 py-2">
              <h3 className="font-bold text-slate-700 text-xs">Daily Collection (আজকের আদায়)</h3>
            </div>
            <div className="p-3 space-y-3">
              {/* PL Input */}
              {hasPl && (
                <div className="bg-[#dbeafe]/70 p-2.5 rounded-lg border border-indigo-100 flex items-center justify-between gap-3">
                  <span className="font-extrabold text-indigo-900 text-xs min-w-[2.5rem]">PL</span>
                  <div className="flex items-center gap-1.5 flex-1 justify-end">
                    <input
                      type="text"
                      value={plCollection}
                      onChange={(e) => setPlCollection(e.target.value.replace(/\D/g, ''))}
                      className="w-24 bg-white border-b-2 border-indigo-400 font-black text-right text-sm px-1.5 py-0.5 outline-none font-mono focus:border-indigo-600 text-slate-850"
                    />
                    <div className="w-5 h-5 bg-emerald-600 rounded-full flex items-center justify-center">
                      <Check className="w-3.5 h-3.5 text-white" />
                    </div>
                  </div>
                </div>
              )}

              {/* GS Input */}
              {hasGs && (
                <div className="bg-[#dbeafe]/70 p-2.5 rounded-lg border border-indigo-100 flex items-center justify-between gap-3">
                  <span className="font-extrabold text-indigo-900 text-xs min-w-[2.5rem]">GS</span>
                  <div className="flex items-center gap-1.5 flex-1 justify-end">
                    <input
                      type="text"
                      value={gsCollection}
                      onChange={(e) => setGsCollection(e.target.value.replace(/\D/g, ''))}
                      className="w-24 bg-white border-b-2 border-indigo-400 font-black text-right text-sm px-1.5 py-0.5 outline-none font-mono focus:border-indigo-600 text-slate-850"
                    />
                    <div className="w-5 h-5 bg-emerald-600 rounded-full flex items-center justify-center">
                      <Check className="w-3.5 h-3.5 text-white" />
                    </div>
                  </div>
                </div>
              )}

              {/* CBS Input */}
              {hasCbs && (
                <div className="bg-[#dbeafe]/70 p-2.5 rounded-lg border border-indigo-100 flex items-center justify-between gap-3">
                  <span className="font-extrabold text-indigo-900 text-xs min-w-[2.5rem]">CBS</span>
                  <div className="flex items-center gap-1.5 flex-1 justify-end">
                    <input
                      type="text"
                      value={cbsCollection}
                      onChange={(e) => setCbsCollection(e.target.value.replace(/\D/g, ''))}
                      className="w-24 bg-white border-b-2 border-indigo-400 font-black text-right text-sm px-1.5 py-0.5 outline-none font-mono focus:border-indigo-600 text-slate-850"
                    />
                    <div className="w-5 h-5 bg-emerald-600 rounded-full flex items-center justify-center">
                      <Check className="w-3.5 h-3.5 text-white" />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* 7. LTS COLLECTION SECTION */}
        {hasLts && (
          <div className="bg-[#fbfcff] rounded-xl border border-[#cbd5e1] overflow-hidden">
            <div className="bg-[#edf2f9] border-b border-[#cbd5e1] px-3.5 py-2">
              <h3 className="font-bold text-slate-700 text-xs">LTS Collection</h3>
            </div>
            <div className="p-3">
              <div className="bg-[#dbeafe]/70 p-2.5 rounded-lg border border-indigo-100 flex items-center justify-between gap-3">
                <span className="font-extrabold text-[#15803d] text-xs">LTS {currentMember?.ltsIndex || '1'} ({ltsBalance} / {ltsInstallment})</span>
                <div className="flex items-center gap-1.5 flex-1 justify-end">
                  <input
                    type="text"
                    value={ltsCollection}
                    onChange={(e) => setLtsCollection(e.target.value.replace(/\D/g, ''))}
                    className="w-24 bg-white border-b-2 border-indigo-400 font-black text-right text-sm px-1.5 py-0.5 outline-none font-mono focus:border-indigo-600 text-slate-850"
                  />
                  <div className="w-5 h-5 bg-emerald-600 rounded-full flex items-center justify-center">
                    <Check className="w-3.5 h-3.5 text-white" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 8. DAILY WITHDRAWAL SECTION */}
        {(hasGs || hasCbs) && (
          <div className="bg-[#fbfcff] rounded-xl border border-[#cbd5e1] overflow-hidden animate-in fade-in">
            <div className="bg-[#edf2f9] border-b border-[#cbd5e1] px-3.5 py-2">
              <h3 className="font-bold text-slate-700 text-xs">Daily Withdrawal (সঞ্চয় উত্তোলন)</h3>
            </div>
            <div className="p-3 space-y-3">
              {/* GS Withdrawal */}
              {hasGs && (
                <div className="bg-[#eaeef6] p-2.5 rounded-lg border border-slate-200 flex items-center justify-between gap-3">
                  <span className="font-extrabold text-slate-700 text-xs min-w-[2.5rem]">GS</span>
                  <div className="flex items-center gap-1.5 flex-1 justify-end">
                    <input
                      type="text"
                      value={gsWithdrawal}
                      onChange={(e) => setGsWithdrawal(e.target.value.replace(/\D/g, ''))}
                      className="w-24 bg-white border-b border-rose-400 font-black text-right text-sm px-1.5 py-0.5 outline-none font-mono focus:border-rose-600 text-slate-850"
                    />
                  </div>
                </div>
              )}

              {/* CBS Withdrawal */}
              {hasCbs && (
                <div className="bg-[#eaeef6] p-2.5 rounded-lg border border-slate-200 flex items-center justify-between gap-3">
                  <span className="font-extrabold text-slate-700 text-xs min-w-[2.5rem]">CBS</span>
                  <div className="flex items-center gap-1.5 flex-1 justify-end">
                    <input
                      type="text"
                      value={cbsWithdrawal}
                      onChange={(e) => setCbsWithdrawal(e.target.value.replace(/\D/g, ''))}
                      className="w-24 bg-white border-b border-rose-400 font-black text-right text-sm px-1.5 py-0.5 outline-none font-mono focus:border-rose-600 text-slate-850"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* 9. EXEMPTION SECTION */}
        {hasPl && (
          <div className="bg-[#fbfcff] rounded-xl border border-[#cbd5e1] overflow-hidden">
            <div className="bg-[#edf2f9] border-b border-[#cbd5e1] px-3.5 py-2">
              <h3 className="font-bold text-slate-700 text-xs">Exemption (ঋণ মওকুফ)</h3>
            </div>
            <div className="p-3">
              <div className="bg-white p-2.5 rounded-lg border border-slate-200 flex items-center justify-between">
                <span className="font-extrabold text-slate-700 text-xs">PL</span>
                <div className="flex items-center gap-3.5">
                  <input
                    type="checkbox"
                    checked={isPlExempted}
                    onChange={(e) => setIsPlExempted(e.target.checked)}
                    className="w-4 h-4 text-emerald-600 border-slate-300 focus:ring-emerald-500 rounded"
                  />
                  <span className="font-mono font-black text-slate-800 text-sm">{plExemptionAmount}</span>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* 10. ACTION FOOTER BUTTONS */}
      <div className="p-4 bg-white border-t border-slate-200 flex gap-4">
        <button
          type="button"
          onClick={onBack}
          className="flex-1 py-3 bg-white text-[#2f6ce5] hover:bg-slate-50 border border-slate-300 rounded-xl font-bold text-xs select-none cursor-pointer active:scale-95 text-center transition"
        >
          Close
        </button>

        <button
          type="button"
          onClick={handleSave}
          className="flex-1 py-3 bg-[#2f6ce5] hover:bg-[#1d59d1] text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md hover:shadow-lg select-none cursor-pointer active:scale-95 transition"
        >
          <Save className="w-4 h-4" />
          Save
        </button>
      </div>

    </div>
  );
};

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Building, 
  UserCheck, 
  Users, 
  LogOut, 
  Plus, 
  Search, 
  Trash2, 
  Phone, 
  MapPin, 
  Calendar, 
  X,
  Settings,
  Save,
  Sliders,
  Shield,
  Eye,
  EyeOff,
  Globe,
  Mail,
  FileText,
  Lock,
  Key,
  Clock,
  Info,
  Check,
  Pencil,
  Edit2,
  Layers,
  ChevronLeft,
  ChevronRight,
  RotateCcw
} from 'lucide-react';
import { Organization, Staff, Branch, Holiday, Group } from '../types';
import ReportViews from './ReportViews';
import { getDefaultHolidays } from '../utils/holidayHelper';

interface OrgAdminDashboardProps {
  org: Organization;
  onLogout: () => void;
  onUpdateOrg?: (updatedOrg: Organization) => void;
}

type ActiveTab = 'branches' | 'staff' | 'config' | 'reports' | 'holidays' | 'operations';

export default function OrgAdminDashboard({ org, onLogout, onUpdateOrg }: OrgAdminDashboardProps) {
  const [activeTab, setActiveTab] = useState<ActiveTab>('branches');
  const [selectedReportType, setSelectedReportType] = useState<string>('loan_calc');

  // Load branches and staff list from localStorage based on org.id
  const [branchesList, setBranchesList] = useState<Branch[]>(() => {
    const saved = localStorage.getItem(`tanzil_branches_${org.id}`);
    return saved ? JSON.parse(saved) : [];
  });

  const [staffList, setStaffList] = useState<Staff[]>(() => {
    const saved = localStorage.getItem(`tanzil_staff_${org.id}`);
    if (!saved) return [];
    const parsed: Staff[] = JSON.parse(saved);

    const alreadyMigrated = parsed.every(s => s.staffId && s.password === '1234' && /^\d+$/.test(s.staffId));
    
    if (alreadyMigrated) return parsed;
    
    let humanStaffCounter = 9;
    const updated = parsed.map((s: Staff) => {
      if (s.staffId?.startsWith('ILO')) {
        return { ...s, password: '1234' };
      } else {
        const newId = humanStaffCounter.toString().padStart(3, '0');
        humanStaffCounter++;
        return { ...s, staffId: newId, password: '1234' };
      }
    });

    localStorage.setItem(`tanzil_staff_${org.id}`, JSON.stringify(updated));
    return updated;
  });

  // Save states back to localStorage
  useEffect(() => {
    localStorage.setItem(`tanzil_branches_${org.id}`, JSON.stringify(branchesList));
  }, [branchesList, org.id]);

  useEffect(() => {
    localStorage.setItem(`tanzil_staff_${org.id}`, JSON.stringify(staffList));
  }, [staffList, org.id]);

  // Load holidays list from localStorage based on org.id
  const [holidaysList, setHolidaysList] = useState<Holiday[]>(() => {
    const saved = localStorage.getItem(`tanzil_holidays_${org.id}`);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      } catch (e) {
        console.error("Error parsing holidays", e);
      }
    }
    const defaultHolidays = getDefaultHolidays(org.id);
    localStorage.setItem(`tanzil_holidays_${org.id}`, JSON.stringify(defaultHolidays));
    return defaultHolidays;
  });

  useEffect(() => {
    localStorage.setItem(`tanzil_holidays_${org.id}`, JSON.stringify(holidaysList));
  }, [holidaysList, org.id]);

  // Custom dialog confirmation & alert states (Iframe safe)
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  } | null>(null);

  const [alertModal, setAlertModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
  } | null>(null);

  const showConfirm = (message: string, onConfirm: () => void, title = "নিশ্চিত করুন") => {
    setConfirmModal({
      isOpen: true,
      title,
      message,
      onConfirm: () => {
        onConfirm();
        setConfirmModal(null);
      }
    });
  };

  const showAlert = (message: string, title = "বিজ্ঞপ্তি") => {
    setAlertModal({
      isOpen: true,
      title,
      message
    });
  };

  // Holiday Modal & Form States
  const [isHolidayModalOpen, setIsHolidayModalOpen] = useState(false);
  const [editingHolidayId, setEditingHolidayId] = useState<string | null>(null);
  const [holidayType, setHolidayType] = useState<'direct' | 'general'>('direct');
  const [holidayName, setHolidayName] = useState('');
  const [holidayDate, setHolidayDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [holidayDayOfWeek, setHolidayDayOfWeek] = useState('শুক্রবার');

  const replaceNumbersWithBN = (num: number | string) => {
    const numbers: { [key: string]: string } = {
      '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪', '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯'
    };
    return num.toString().split('').map(x => numbers[x] || x).join('');
  };

  // Working day state & dialogs
  const [workingDay, setWorkingDay] = useState(() => {
    return localStorage.getItem(`tanzil_working_day_${org.id}`) || new Date().toISOString().split('T')[0];
  });
  const [isWorkingDayModalOpen, setIsWorkingDayModalOpen] = useState(false);
  const [workingDayInput, setWorkingDayInput] = useState(workingDay);

  // Topbar Action Change Password dialogs
  const [isChangePasswordModalOpen, setIsChangePasswordModalOpen] = useState(false);
  const [newPasswordVal, setNewPasswordVal] = useState('');
  const [confirmPasswordVal, setConfirmPasswordVal] = useState('');
  const [passwordChangeSuccess, setPasswordChangeSuccess] = useState('');

  // Search filter query state
  const [searchTerm, setSearchTerm] = useState('');
  const [holidayYearFilter, setHolidayYearFilter] = useState('all');
  const [holidaySearchQuery, setHolidaySearchQuery] = useState('');
  const [holidayViewMode, setHolidayViewMode] = useState<'calendar' | 'list'>('calendar');
  const [currentCalendarYear, setCurrentCalendarYear] = useState(2026);
  const [currentCalendarMonth, setCurrentCalendarMonth] = useState(5); // June is 5 (0-indexed)

  // Modal & Form States for Branches (Manager state is removed, automatically resolved from staff list)
  const [isBranchModalOpen, setIsBranchModalOpen] = useState(false);
  const [isBranchEditMode, setIsBranchEditMode] = useState(false);
  const [editingBranchId, setEditingBranchId] = useState<string | null>(null);
  const [branchName, setBranchName] = useState('');
  const [branchCode, setBranchCode] = useState('');
  const [branchPhone, setBranchPhone] = useState('');
  const [branchAddress, setBranchAddress] = useState('');
  const [branchDate, setBranchDate] = useState(() => new Date().toISOString().split('T')[0]);

  // Modal & Form States for Staff (Added working branch and branch joining date)
  const [isStaffModalOpen, setIsStaffModalOpen] = useState(false);
  const [isStaffEditMode, setIsStaffEditMode] = useState(false);
  const [editingStaffId, setEditingStaffId] = useState<string | null>(null);
  const [staffName, setStaffName] = useState('');
  const [staffPhone, setStaffPhone] = useState('');
  const [staffDesignation, setStaffDesignation] = useState('মাঠ কর্মী');
  const [staffDate, setStaffDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [staffBranchId, setStaffBranchId] = useState('');
  const [staffBranchJoiningDate, setStaffBranchJoiningDate] = useState(() => new Date().toISOString().split('T')[0]);

  // Configuration values (Loaded and synchronized to localStorage)
  const [orgName, setOrgName] = useState(org.name);
  const [orgAddress, setOrgAddress] = useState(org.address);
  const [orgPassword, setOrgPassword] = useState(org.adminPassword);
  
  const [minSavings, setMinSavings] = useState(() => localStorage.getItem(`tanzil_min_savings_${org.id}`) || '৫০');
  const [savingsInterest, setSavingsInterest] = useState(() => localStorage.getItem(`tanzil_savings_interest_${org.id}`) || '৮');
  const [maxLoanLimit, setMaxLoanLimit] = useState(() => localStorage.getItem(`tanzil_max_loan_${org.id}`) || '১০০০০০');
  const [withdrawalFee, setWithdrawalFee] = useState(() => localStorage.getItem(`tanzil_withdrawal_fee_${org.id}`) || '২');

  // --- Configuration Section 1: General Info ---
  const [orgPhone, setOrgPhone] = useState(() => localStorage.getItem(`tanzil_phone_${org.id}`) || '01712345678');
  const [orgEmail, setOrgEmail] = useState(() => localStorage.getItem(`tanzil_email_${org.id}`) || 'info@tanzilcredit.org');
  const [orgWebsite, setOrgWebsite] = useState(() => localStorage.getItem(`tanzil_website_${org.id}`) || 'www.tanzilcredit.org');
  const [orgTradeLicense, setOrgTradeLicense] = useState(() => localStorage.getItem(`tanzil_trade_license_${org.id}`) || 'TR-72849/2026');
  const [orgLogoStyle, setOrgLogoStyle] = useState(() => localStorage.getItem(`tanzil_logo_style_${org.id}`) || 'shield'); // icon style preset
  const [orgLogoUrl, setOrgLogoUrl] = useState(() => localStorage.getItem(`tanzil_logo_url_${org.id}`) || ''); // custom base64/url if provided

  // --- Configuration Section 2: Loan Settings ---
  const [loanDefaultInterest, setLoanDefaultInterest] = useState(() => localStorage.getItem(`tanzil_loan_interest_${org.id}`) || '১২');
  const [loanInterestType, setLoanInterestType] = useState(() => localStorage.getItem(`tanzil_loan_interest_type_${org.id}`) || 'Flat'); // Flat / Declining
  const [loanMinAmount, setLoanMinAmount] = useState(() => localStorage.getItem(`tanzil_loan_min_${org.id}`) || '৫০০০');
  const [loanMaxAmount, setLoanMaxAmount] = useState(() => localStorage.getItem(`tanzil_loan_max_${org.id}`) || '১০০০০০');
  const [loanDuration, setLoanDuration] = useState(() => localStorage.getItem(`tanzil_loan_duration_${org.id}`) || '৪৫ সপ্তাহ');
  const [loanGracePeriod, setLoanGracePeriod] = useState(() => localStorage.getItem(`tanzil_loan_grace_${org.id}`) || '২ সপ্তাহ');
  const [loanLateFee, setLoanLateFee] = useState(() => localStorage.getItem(`tanzil_loan_late_fee_${org.id}`) || '৫০');
  const [loanProcessingFee, setLoanProcessingFee] = useState(() => localStorage.getItem(`tanzil_loan_processing_fee_${org.id}`) || '২০০');

  // --- Configuration Section 3: Installment Settings ---
  const [instWeeklyActive, setInstWeeklyActive] = useState(() => localStorage.getItem(`tanzil_inst_weekly_${org.id}`) !== 'false'); // boolean
  const [instMonthlyActive, setInstMonthlyActive] = useState(() => localStorage.getItem(`tanzil_inst_monthly_${org.id}`) !== 'false'); // boolean
  const [instTermActive, setInstTermActive] = useState(() => {
    const term = localStorage.getItem(`tanzil_inst_term_active_${org.id}`);
    if (term !== null) return term === 'true';
    return localStorage.getItem(`tanzil_inst_biweekly_${org.id}`) === 'true';
  }); // boolean
  const [instCollectionDay, setInstCollectionDay] = useState(() => localStorage.getItem(`tanzil_inst_day_${org.id}`) || 'সমিতির বার ভিত্তিক');
  const [instAutoGeneration, setInstAutoGeneration] = useState(() => localStorage.getItem(`tanzil_inst_auto_${org.id}`) !== 'false'); // boolean
  const [instRoundingRule, setInstRoundingRule] = useState(() => localStorage.getItem(`tanzil_inst_rounding_${org.id}`) || 'Nearest 10');

  // --- Configuration Section 4: Savings Settings & Multi-type configuration ---
  const [savingsType, setSavingsType] = useState(() => localStorage.getItem(`tanzil_sav_type_${org.id}`) || 'Regular');
  const [savingsMinDeposit, setSavingsMinDeposit] = useState(() => localStorage.getItem(`tanzil_sav_min_dep_${org.id}`) || '১০০');
  const [savingsMinBalance, setSavingsMinBalance] = useState(() => localStorage.getItem(`tanzil_sav_min_bal_${org.id}`) || '৫০');
  // 4 types of savings profit rates
  const [savProfitGS, setSavProfitGS] = useState(() => localStorage.getItem(`tanzil_sav_profit_gs_${org.id}`) || '৬');
  const [savProfitCBS, setSavProfitCBS] = useState(() => localStorage.getItem(`tanzil_sav_profit_cbs_${org.id}`) || '৭');
  const [savProfitLTS, setSavProfitLTS] = useState(() => localStorage.getItem(`tanzil_sav_profit_lts_${org.id}`) || '৮.৫');
  const [savProfitFDR, setSavProfitFDR] = useState(() => localStorage.getItem(`tanzil_sav_profit_fdr_${org.id}`) || '১০');
  const [savFdrPayoutType, setSavFdrPayoutType] = useState(() => localStorage.getItem(`tanzil_sav_fdr_payout_${org.id}`) || 'মাসিক'); // FDR interest payment fixed type to monthly

  const [savingsAdmissionFee, setSavingsAdmissionFee] = useState(() => localStorage.getItem(`tanzil_sav_admission_fee_${org.id}`) || '১০০');
  const [savingsWelfareFee, setSavingsWelfareFee] = useState(() => localStorage.getItem(`tanzil_sav_welfare_fee_${org.id}`) || '২০');

  // Loan Insurance fields (বিতরণকৃত আসলের % এবং যৌথ/একক বীমা)
  const [loanInsurancePercent, setLoanInsurancePercent] = useState(() => localStorage.getItem(`tanzil_loan_ins_percent_${org.id}`) || '১০');
  const [loanInsuranceType, setLoanInsuranceType] = useState(() => localStorage.getItem(`tanzil_loan_ins_type_${org.id}`) || 'যৌথ বীমা');

  // Mandatory Savings as % of loan principal, running during loan tenure
  const [mandatorySavingsPercent, setMandatorySavingsPercent] = useState(() => localStorage.getItem(`tanzil_mandatory_sav_percent_${org.id}`) || '৫');

  const [configSuccessMsg, setConfigSuccessMsg] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // --- Loan Disbursement Sandbox States ---
  const [dispMemberName, setDispMemberName] = useState('');
  const [dispMemberPhone, setDispMemberPhone] = useState('');
  const [dispMemberGender, setDispMemberGender] = useState<'female' | 'male'>('female');
  const [dispInsuranceType, setDispInsuranceType] = useState<'যৌথ বীমা' | 'একক বীমা'>(() => {
    const savedType = localStorage.getItem(`tanzil_loan_ins_type_${org.id}`);
    if (savedType === 'একক বীমা' || savedType === 'যৌথ বীমা') return savedType as 'একক বীমা' | 'যৌথ বীমা';
    return 'যৌথ বীমা';
  });
  const [dispBranchId, setDispBranchId] = useState('');
  const [dispAmount, setDispAmount] = useState('20000');
  const [dispInterestRate, setDispInterestRate] = useState(() => localStorage.getItem(`tanzil_loan_interest_${org.id}`) || '12');
  const [dispIntervalType, setDispIntervalType] = useState<'weekly' | 'monthly' | 'term'>('weekly');
  const [dispTenure, setDispTenure] = useState('1.0'); // 1.0, 1.5, 2.0 (years)
  const [dispTermTenure, setDispTermTenure] = useState('3_months'); // 3_months, 6_months
  const [dispInsPolicy, setDispInsPolicy] = useState('policy_a'); // policy_a, policy_b, etc
  const [isDisbursedSuccess, setIsDisbursedSuccess] = useState(false);
  const [lastDisbursedSummary, setLastDisbursedSummary] = useState<any>(null);

  const handleEditBranchClick = (branch: Branch) => {
    setEditingBranchId(branch.id);
    setBranchName(branch.name);
    setBranchCode(branch.code);
    setBranchPhone(branch.phone);
    setBranchAddress(branch.address);
    setBranchDate(branch.addDate);
    setIsBranchEditMode(true);
    setIsBranchModalOpen(true);
  };

  const handleToggleBranchStatus = (id: string) => {
    setBranchesList(prev => prev.map(b => {
      if (b.id === id) {
        const nextStatus = b.status === 'closed' ? 'active' : 'closed';
        return { ...b, status: nextStatus };
      }
      return b;
    }));
  };

  // Handlers for Branch
  const handleAddBranch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!branchName || !branchCode || !branchPhone || !branchAddress) {
      alert('দয়া করে সর্ম্পূর্ণ তথ্য পূরণ করুন');
      return;
    }

    if (isBranchEditMode && editingBranchId) {
      setBranchesList(prev => prev.map(b => b.id === editingBranchId ? {
        ...b,
        name: branchName,
        code: branchCode,
        phone: branchPhone,
        address: branchAddress,
        addDate: branchDate
      } : b));
    } else {
      const newBranch: Branch = {
        id: Date.now().toString(),
        orgId: org.id,
        name: branchName,
        code: branchCode,
        manager: '', // Will be automatically mapped dynamically
        phone: branchPhone,
        address: branchAddress,
        addDate: branchDate,
        status: 'active'
      };
      setBranchesList([...branchesList, newBranch]);
    }
    
    // Reset Branch States
    setBranchName('');
    setBranchCode('');
    setBranchPhone('');
    setBranchAddress('');
    setIsBranchEditMode(false);
    setEditingBranchId(null);
    setIsBranchModalOpen(false);
  };

  const handleDeleteBranch = (id: string, name: string) => {
    if (confirm(`আপনি কি নিশ্চিত যে "${name}" শাখাটি ডিলিট করতে চান?`)) {
      setBranchesList(branchesList.filter(b => b.id !== id));
      // Also unassign staff assigned to this deleted branch
      setStaffList(prev => prev.map(s => s.branchId === id ? { ...s, branchId: undefined, branchJoiningDate: undefined } : s));
    }
  };

  // Handlers for Staff
  const handleEditStaffClick = (staff: Staff) => {
    setEditingStaffId(staff.id);
    setStaffName(staff.name);
    setStaffPhone(staff.phone);
    setStaffDesignation(staff.designation);
    setStaffDate(staff.joiningDate);
    setStaffBranchId(staff.branchId || '');
    setStaffBranchJoiningDate(staff.branchJoiningDate || new Date().toISOString().split('T')[0]);
    setIsStaffEditMode(true);
    setIsStaffModalOpen(true);
  };

  const handleAddStaff = (e: React.FormEvent) => {
    e.preventDefault();
    if (!staffName || !staffPhone) {
      alert('দয়া করে সর্ম্পূর্ণ তথ্য পূরণ করুন');
      return;
    }

    if (isStaffEditMode && editingStaffId) {
      setStaffList(prev => prev.map(s => s.id === editingStaffId ? {
        ...s,
        name: staffName,
        phone: staffPhone,
        designation: staffDesignation,
        joiningDate: staffDate,
        branchId: staffBranchId || undefined,
        branchJoiningDate: staffBranchId ? staffBranchJoiningDate : undefined
      } : s));
    } else {
      let autoStaffId = '';
      let currentNum = 9;
      do {
        autoStaffId = currentNum.toString().padStart(3, '0');
        currentNum++;
      } while (staffList.some(s => s.staffId === autoStaffId));
      const autoPassword = '1234';

      const newStaff: Staff = {
        id: Date.now().toString(),
        orgId: org.id,
        name: staffName,
        phone: staffPhone,
        designation: staffDesignation,
        joiningDate: staffDate,
        branchId: staffBranchId || undefined,
        branchJoiningDate: staffBranchId ? staffBranchJoiningDate : undefined,
        staffId: autoStaffId,
        password: autoPassword
      };
      setStaffList([...staffList, newStaff]);
    }
    
    // Reset Staff States
    setStaffName('');
    setStaffPhone('');
    setStaffDesignation('মাঠ কর্মী');
    setStaffBranchId('');
    setStaffBranchJoiningDate(new Date().toISOString().split('T')[0]);
    setIsStaffEditMode(false);
    setEditingStaffId(null);
    setIsStaffModalOpen(false);
  };

  const handleDeleteStaff = (id: string, name: string) => {
    const targetStaff = staffList.find(s => s.id === id);
    if (!targetStaff) return;
    if (targetStaff.staffId?.startsWith('ILO')) {
      alert('সিস্টেম ও ব্যাকআপ এও "ILO" অ্যাকাউন্ট কে ডিলিট করা যাবে না!');
      return;
    }

    // Load groupList to see if this staff is assigned to any groups
    const groupsSaved = localStorage.getItem(`tanzil_groups_${org.id}`);
    const groups: Group[] = groupsSaved ? JSON.parse(groupsSaved) : [];
    
    // Find groups assigned to this staff member (checking both ID and staffId/UID)
    const assignedGroups = groups.filter(g => g.assignedStaffId === targetStaff.id || g.assignedStaffId === targetStaff.staffId);
    
    let confirmMsg = `আপনি কি নিশ্চিত যে "${name}" কর্মকর্তাকে বাদ দিতে চান?`;
    if (assignedGroups.length > 0) {
      confirmMsg = `কর্মী "${name}" বর্তমানে ${assignedGroups.length} টি গ্রুপ/সমিতির দায়িত্বে আছেন (যেমন: ${assignedGroups.map(g => g.name).join(', ')})।\n\nডিলিট করার পর তার দায়ীত্বাধীন গ্রুপগুলো স্বয়ংক্রিয়ভাবে সংশ্লিষ্ট শাখার ডিফল্ট ব্যাকআপ কর্মকর্তা (ILO) অ্যাকাউন্টে স্থানান্তরিত হবে যাতে মাঠ কার্যক্রমে বিঘ্ন না ঘটে।\n\nআপনি কি নিশ্চিতভাবে তাকে ডিলিট করতে চান?`;
    }

    if (confirm(confirmMsg)) {
      if (assignedGroups.length > 0) {
        const updatedGroups = groups.map(g => {
          if (g.assignedStaffId === targetStaff.id || g.assignedStaffId === targetStaff.staffId) {
            const groupBranch = branchesList.find(b => b.id === g.branchId);
            const branchCode = groupBranch?.code || 'HO';
            return {
              ...g,
              assignedStaffId: `ILO-${branchCode}`
            };
          }
          return g;
        });
        localStorage.setItem(`tanzil_groups_${org.id}`, JSON.stringify(updatedGroups));
      }
      const newStaffList = staffList.filter(s => s.id !== id);
      setStaffList(newStaffList);
      localStorage.setItem(`tanzil_staff_${org.id}`, JSON.stringify(newStaffList));
    }
  };

  const handleAddHoliday = (e: React.FormEvent) => {
    e.preventDefault();
    if (!holidayName.trim()) {
      alert('দয়া করে ছুটির কারণ বা বিবরণ লিখুন।');
      return;
    }

    if (editingHolidayId) {
      setHolidaysList(prev => prev.map(h => {
        if (h.id === editingHolidayId) {
          return {
            ...h,
            type: holidayType,
            name: holidayName.trim(),
            date: holidayType === 'direct' ? holidayDate : undefined,
            dayOfWeek: holidayType === 'general' ? holidayDayOfWeek : undefined
          };
        }
        return h;
      }));
      setEditingHolidayId(null);
    } else {
      const newHoliday: Holiday = {
        id: `HLD-${Math.floor(1000 + Math.random() * 9000)}-${Date.now().toString().slice(-4)}`,
        orgId: org.id,
        type: holidayType,
        name: holidayName.trim(),
        date: holidayType === 'direct' ? holidayDate : undefined,
        dayOfWeek: holidayType === 'general' ? holidayDayOfWeek : undefined,
        addDate: workingDay
      };
      setHolidaysList(prev => [newHoliday, ...prev]);
    }

    setHolidayName('');
    setIsHolidayModalOpen(false);
  };

  const handleEditHoliday = (holiday: Holiday) => {
    setEditingHolidayId(holiday.id);
    setHolidayType(holiday.type);
    setHolidayName(holiday.name);
    if (holiday.type === 'direct' && holiday.date) {
      setHolidayDate(holiday.date);
    }
    if (holiday.type === 'general' && holiday.dayOfWeek) {
      setHolidayDayOfWeek(holiday.dayOfWeek);
    }
    setIsHolidayModalOpen(true);
  };

  const handleDeleteHoliday = (id: string, name: string) => {
    showConfirm(`আপনি কি নিশ্চিতভাবে "${name}" ছুটিটি তালিকা থেকে ডিলিট করতে চান?`, () => {
      setHolidaysList(prev => prev.filter(h => h.id !== id));
    });
  };


  // Search filter implementation (Dynamic manager retrieval and filter)
  const filteredBranches = branchesList.filter(b => {
    const autoManager = staffList.find(s => s.branchId === b.id && s.designation === 'শাখা ব্যবস্থাপক')?.name || '(ব্যবস্থাপক অনির্ধারিত)';
    return (
      b.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      b.code.toLowerCase().includes(searchTerm.toLowerCase()) || 
      autoManager.toLowerCase().includes(searchTerm.toLowerCase()) || 
      b.phone.includes(searchTerm) ||
      b.address.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  const filteredStaff = staffList.filter(s => {
    const assignedBranchName = branchesList.find(b => b.id === s.branchId)?.name || 'প্রধান কার্যালয় / অনিযুক্ত';
    return (
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      s.phone.includes(searchTerm) || 
      s.designation.toLowerCase().includes(searchTerm.toLowerCase()) ||
      assignedBranchName.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orgName || !orgAddress || !orgPassword) {
      alert('দয়া করে সর্ম্পূর্ণ তথ্য পূরণ করুন');
      return;
    }
    if (onUpdateOrg) {
      onUpdateOrg({
        ...org,
        name: orgName,
        address: orgAddress,
        adminPassword: orgPassword
      });
    }
    
    // Legacy settings sync
    localStorage.setItem(`tanzil_min_savings_${org.id}`, savingsMinDeposit);
    localStorage.setItem(`tanzil_savings_interest_${org.id}`, savProfitGS); // using GS interest rate as legacy backfill
    localStorage.setItem(`tanzil_max_loan_${org.id}`, loanMaxAmount);
    localStorage.setItem(`tanzil_withdrawal_fee_${org.id}`, withdrawalFee);

    // General settings
    localStorage.setItem(`tanzil_phone_${org.id}`, orgPhone);
    localStorage.setItem(`tanzil_email_${org.id}`, orgEmail);
    localStorage.setItem(`tanzil_website_${org.id}`, orgWebsite);
    localStorage.setItem(`tanzil_trade_license_${org.id}`, orgTradeLicense);
    localStorage.setItem(`tanzil_logo_style_${org.id}`, orgLogoStyle);
    localStorage.setItem(`tanzil_logo_url_${org.id}`, orgLogoUrl);

    // Loan settings
    localStorage.setItem(`tanzil_loan_interest_${org.id}`, loanDefaultInterest);
    localStorage.setItem(`tanzil_loan_interest_type_${org.id}`, loanInterestType);
    localStorage.setItem(`tanzil_loan_min_${org.id}`, loanMinAmount);
    localStorage.setItem(`tanzil_loan_max_${org.id}`, loanMaxAmount);
    localStorage.setItem(`tanzil_loan_duration_${org.id}`, loanDuration);
    localStorage.setItem(`tanzil_loan_grace_${org.id}`, loanGracePeriod);
    localStorage.setItem(`tanzil_loan_late_fee_${org.id}`, loanLateFee);
    localStorage.setItem(`tanzil_loan_processing_fee_${org.id}`, loanProcessingFee);

    // Installment settings
    localStorage.setItem(`tanzil_inst_weekly_${org.id}`, String(instWeeklyActive));
    localStorage.setItem(`tanzil_inst_monthly_${org.id}`, String(instMonthlyActive));
    localStorage.setItem(`tanzil_inst_term_active_${org.id}`, String(instTermActive));
    localStorage.setItem(`tanzil_inst_biweekly_${org.id}`, String(instTermActive));
    localStorage.setItem(`tanzil_inst_day_${org.id}`, instCollectionDay);
    localStorage.setItem(`tanzil_inst_auto_${org.id}`, String(instAutoGeneration));
    localStorage.setItem(`tanzil_inst_rounding_${org.id}`, instRoundingRule);

    // Savings settings
    localStorage.setItem(`tanzil_sav_type_${org.id}`, savingsType);
    localStorage.setItem(`tanzil_sav_min_dep_${org.id}`, savingsMinDeposit);
    localStorage.setItem(`tanzil_sav_min_bal_${org.id}`, savingsMinBalance);
    localStorage.setItem(`tanzil_sav_profit_gs_${org.id}`, savProfitGS);
    localStorage.setItem(`tanzil_sav_profit_cbs_${org.id}`, savProfitCBS);
    localStorage.setItem(`tanzil_sav_profit_lts_${org.id}`, savProfitLTS);
    localStorage.setItem(`tanzil_sav_profit_fdr_${org.id}`, savProfitFDR);
    localStorage.setItem(`tanzil_sav_fdr_payout_${org.id}`, savFdrPayoutType);
    localStorage.setItem(`tanzil_sav_admission_fee_${org.id}`, savingsAdmissionFee);
    localStorage.setItem(`tanzil_sav_welfare_fee_${org.id}`, savingsWelfareFee);

    // Loan Insurance settings
    localStorage.setItem(`tanzil_loan_ins_percent_${org.id}`, loanInsurancePercent);
    localStorage.setItem(`tanzil_loan_ins_type_${org.id}`, loanInsuranceType);

    // Mandatory Savings settings
    localStorage.setItem(`tanzil_mandatory_sav_percent_${org.id}`, mandatorySavingsPercent);

    setConfigSuccessMsg('কনফিগারেশন সফলভাবে সংরক্ষণ করা হয়েছে!');
    setTimeout(() => {
      setConfigSuccessMsg('');
    }, 4000);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      
      {/* Software Brand Topbar / সবার উপরে সফটওয়্যারের নাম ও প্রাতিষ্ঠানিক তথ্য */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-800 to-violet-900 text-white py-4 px-4 sm:px-6 shadow-xl z-20">
        <div className="max-w-7xl mx-auto space-y-4">
          
          {/* Top Line: Software Name & Quick Control Actions */}
          <div className="flex flex-col sm:flex-row justify-between items-center gap-3 border-b border-white/10 pb-3">
            <div className="flex items-center gap-3 font-bold tracking-wide">
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
                <span className="text-sm font-extrabold text-white">তানজিল মাইক্রোক্রেডিট সফটওয়্যার</span>
              </div>
            </div>
            
            {/* Quick Actions */}
            <div className="flex items-center flex-wrap gap-2 text-[11px] font-medium">
              <button 
                onClick={() => {
                  setWorkingDayInput(workingDay);
                  setIsWorkingDayModalOpen(true);
                }}
                className="flex items-center gap-1.5 bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded-lg border border-white/20 text-white transition-all cursor-pointer"
              >
                <Clock size={12} className="text-amber-300" />
                <span>কর্মদিবস:</span>
                <span className="font-mono font-bold text-amber-200 text-[12px]">{workingDay}</span>
              </button>
            </div>
          </div>

          {/* Bottom Line: Org Details & Logged-in Person (Admin) Credentials */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3 text-xs text-white/90">
            {/* Left Portion: Organization Details */}
            <div className="flex items-center gap-4">
              <div className="p-2 bg-white/10 rounded-xl border border-white/20">
                <Building className="w-5 h-5 text-emerald-300" />
              </div>
              <div>
                <span className="text-[9px] text-white/60 font-bold block leading-none uppercase tracking-wider">প্রতিষ্ঠান</span>
                <span className="text-sm font-extrabold text-white">{org.name}</span>
              </div>
            </div>

            {/* Right Portion: Operator details, Password Change & Logout */}
            <div className="flex items-center gap-5 text-xs font-semibold text-white/90 border-t md:border-t-0 border-white/10 pt-3 md:pt-0 w-full justify-between md:justify-end">
              <div className="flex items-center gap-2">
                <span className="text-white/60">অ্যাডমিন আইডি:</span> 
                <span className="font-bold text-white tracking-wide font-mono bg-black/20 px-2 py-0.5 rounded">{org.adminId}</span>
              </div>
              
              <div className="flex items-center gap-3 border-l border-white/20 pl-5">
                <button
                  onClick={() => {
                    setNewPasswordVal('');
                    setConfirmPasswordVal('');
                    setPasswordChangeSuccess('');
                    setIsChangePasswordModalOpen(true);
                  }}
                  className="bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded-lg border border-white/20 text-white transition-all font-bold text-[10px] flex items-center gap-1.5"
                >
                  <Key size={11} />
                  <span>পাসওয়ার্ড পরিবর্তন</span>
                </button>
                <button 
                  onClick={onLogout}
                  className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg transition-colors font-bold text-[10px] flex items-center gap-1.5"
                >
                  <LogOut size={11} />
                  <span>লগআউট</span>
                </button>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Main Body Grid Container with sidebar & content area */}
      <div className="flex-1 max-w-7xl w-full mx-auto flex flex-col md:flex-row min-h-0 bg-white shadow-md border-x border-slate-200">
        
        {/* Sidebar Container */}
        <aside className="w-full md:w-64 bg-slate-50 border-b md:border-b-0 md:border-r border-slate-200 p-4 shrink-0 flex flex-col gap-1">
          <div className="px-3 py-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
            মেনু নেভিগেশন
          </div>
          
          {/* Tab 1: Branches */}
          <button
            onClick={() => { setActiveTab('branches'); setSearchTerm(''); }}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'branches'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-700 hover:bg-slate-200/50 hover:text-slate-900'
            }`}
          >
            <div className="flex items-center gap-2">
              <Building size={16} />
              <span>শাখা তালিকা (Branch List)</span>
            </div>
            <span className={`text-[10px] py-0.5 px-2 rounded-full font-bold ${
              activeTab === 'branches' ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-600'
            }`}>
              {branchesList.length}
            </span>
          </button>

          {/* Tab 2: Staff */}
          <button
            onClick={() => { setActiveTab('staff'); setSearchTerm(''); }}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'staff'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-700 hover:bg-slate-200/50 hover:text-slate-900'
            }`}
          >
            <div className="flex items-center gap-2">
              <UserCheck size={16} />
              <span>কর্মকর্তা / কর্মী লিস্ট</span>
            </div>
            <span className={`text-[10px] py-0.5 px-2 rounded-full font-bold ${
              activeTab === 'staff' ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-600'
            }`}>
              {staffList.length}
            </span>
          </button>

          {/* Tab 3: Configuration */}
          <button
            onClick={() => { setActiveTab('config'); setSearchTerm(''); }}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'config'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-700 hover:bg-slate-200/50 hover:text-slate-900'
            }`}
          >
            <div className="flex items-center gap-2">
              <Settings size={16} />
              <span>কনফিগারেশন (Configuration)</span>
            </div>
          </button>

          {/* Tab 4: Loan Disbursement & Calculator */}
          <button
            onClick={() => { setActiveTab('reports'); setSearchTerm(''); }}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'reports'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-700 hover:bg-slate-200/50 hover:text-slate-900'
            }`}
          >
            <div className="flex items-center gap-2">
              <FileText size={16} />
              <span>রিপোর্ট</span>
            </div>
            <span className={`text-[10px] py-0.5 px-2 rounded-full font-bold ${
              activeTab === 'reports' ? 'bg-white/20 text-white' : 'bg-rose-500 text-white'
            }`}>
              রিপোর্ট
            </span>
          </button>

          {/* Tab 5: Holiday Update / ছুটি হালনাগাদ */}
          <button
            onClick={() => { setActiveTab('holidays'); setSearchTerm(''); }}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'holidays'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-700 hover:bg-slate-200/50 hover:text-slate-900'
            }`}
          >
            <div className="flex items-center gap-2">
              <Calendar size={16} />
              <span>ছুটি হালনাগাদ (Holiday Update)</span>
            </div>
          </button>

          {/* Tab 6: Operations / অপারেশন */}
          <button
            onClick={() => { setActiveTab('operations'); setSearchTerm(''); }}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'operations'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-700 hover:bg-slate-200/50 hover:text-slate-900'
            }`}
          >
            <div className="flex items-center gap-2">
              <Layers size={16} />
              <span>অপারেশন (Operations)</span>
            </div>
            <span className={`text-[10px] py-0.5 px-2 rounded-full font-bold ${
              activeTab === 'operations' ? 'bg-white/25 text-white' : 'bg-slate-200 text-slate-500'
            }`}>
              অ্যাকশন
            </span>
          </button>


          {/* Sidebar Footer info */}
          <div className="mt-8 p-3.5 bg-slate-100/50 rounded-xl border border-slate-200/60 text-[11px] text-slate-500 leading-relaxed hidden md:block mt-auto">
            <p className="font-bold text-slate-700 mb-1">অর্গানাইজেশন তথ্য:</p>
            <p className="text-slate-500">
              আপনার প্রতিষ্ঠানের বিভিন্ন শাখা অফিস, কর্মরত কর্মকর্তা/মাঠ কর্মীদের তালিকা এবং ঋণ ও সঞ্চয়ের সাধারণ নীতিসমূহ পরিচালনা করুন।
            </p>
          </div>
        </aside>

        {/* Content Container */}
        <main className="flex-1 p-4 sm:p-6 overflow-y-auto">
          
          {/* VIEW 1: Branch Management / শাখা তালিকা */}
          {activeTab === 'branches' && (
            <div className="space-y-5">
              
              <div className="flex justify-between items-center flex-wrap gap-3 border-b border-slate-100 pb-4">
                <div>
                  <h3 className="text-lg font-bold text-slate-800 font-sans tracking-tight">নিবন্ধিত শাখা অফিসসমূহ (Branch List)</h3>
                  <p className="text-xs text-slate-400">এই লিমিটেডের আওতাধীন সকল সচল ও বন্ধ শাখা অফিসের বিবরণী।</p>
                </div>

                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2 text-slate-400" size={14} />
                    <input 
                      type="text" 
                      placeholder="শাখা খুঁজুন..."
                      className="pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs w-44 focus:outline-none focus:ring-1 focus:ring-blue-500"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  
                  <button 
                    onClick={() => {
                      setIsBranchEditMode(false);
                      setEditingBranchId(null);
                      setBranchName('');
                      setBranchCode('');
                      setBranchPhone('');
                      setBranchAddress('');
                      setBranchDate(new Date().toISOString().split('T')[0]);
                      setIsBranchModalOpen(true);
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition-colors shadow-xs cursor-pointer"
                  >
                    <Plus size={14} />
                    <span>নতুন শাখা যুক্ত করুন</span>
                  </button>
                </div>
              </div>

              {/* Branch list in a table layout (লিস্ট আকারে) */}
              {filteredBranches.length === 0 ? (
                <div className="bg-slate-50 rounded-2xl border border-dashed border-slate-200 p-12 text-center">
                  <Building className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-500 text-sm font-medium">কোনো শাখা অফিস ডাটাবেসে পাওয়া যায় নি।</p>
                  <p className="text-slate-400 text-xs mt-1 font-semibold">নতুন শাখা অফিস যুক্ত করতে "নতুন শাখা যুক্ত করুন" বাটনে ক্লিক করুন।</p>
                </div>
              ) : (
                <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                          <th className="px-4 py-3 text-center w-36">ইডিট/ডিলিট/বন্ধ (বামপাশে)</th>
                          <th className="px-4 py-3">শাখার নাম ও কোড</th>
                          <th className="px-4 py-3">শাখা ব্যবস্থাপক</th>
                          <th className="px-4 py-3">ঠিকানা</th>
                          <th className="px-4 py-3">মোবাইল নম্বর</th>
                          <th className="px-4 py-3">প্রতিষ্ঠার তারিখ</th>
                          <th className="px-4 py-3 text-right">অবস্থা (Status)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                        {filteredBranches.map((branch) => {
                          const currentManager = staffList.find(s => s.branchId === branch.id && s.designation === 'শাখা ব্যবস্থাপক');
                          const isClosed = branch.status === 'closed';
                          return (
                            <tr key={branch.id} className={`hover:bg-slate-50/75 transition-colors ${isClosed ? 'opacity-70 bg-slate-50/40 text-slate-500' : ''}`}>
                              {/* actions column - placement left (বামপাশে) as requested */}
                              <td className="px-4 py-3 whitespace-nowrap text-center">
                                <div className="flex items-center justify-center gap-1">
                                  {/* Edit button */}
                                  <button
                                    onClick={() => handleEditBranchClick(branch)}
                                    className="p-1 px-1.5 bg-blue-50 text-blue-600 hover:bg-blue-100 rounded-lg transition-all font-bold text-[10px] flex items-center gap-0.5 cursor-pointer border border-blue-100"
                                    title="শাখা সংশোধন করুন"
                                  >
                                    <Pencil size={11} />
                                    <span>ইডিট</span>
                                  </button>

                                  {/* Close/Deactivate toggler */}
                                  <button
                                    onClick={() => handleToggleBranchStatus(branch.id)}
                                    className={`p-1 px-1.5 rounded-lg transition-all font-bold text-[10px] flex items-center gap-0.5 cursor-pointer border ${
                                      isClosed 
                                        ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border-emerald-100' 
                                        : 'bg-amber-50 text-amber-700 hover:bg-amber-100 border-amber-100'
                                    }`}
                                    title={isClosed ? "শাখা সচল করুন" : "শাখা বন্ধ করুন"}
                                  >
                                    {isClosed ? <Check size={11} /> : <X size={11} />}
                                    <span>{isClosed ? 'সচল' : 'বন্ধ'}</span>
                                  </button>

                                  {/* Delete button */}
                                  <button
                                    onClick={() => handleDeleteBranch(branch.id, branch.name)}
                                    className="p-1 px-1.5 bg-rose-50 text-rose-600 hover:bg-rose-100 rounded-lg transition-all font-bold text-[10px] flex items-center gap-0.5 cursor-pointer border border-rose-100"
                                    title="শাখা ডিলিট করুন"
                                  >
                                    <Trash2 size={11} />
                                    <span>ডিলিট</span>
                                  </button>
                                </div>
                              </td>

                              {/* Branch details right next to actions */}
                              <td className="px-4 py-3 whitespace-nowrap">
                                <div className="flex items-center gap-2">
                                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${isClosed ? 'bg-slate-100 text-slate-400' : 'bg-blue-50 text-blue-600'}`}>
                                    <Building size={14} />
                                  </div>
                                  <div>
                                    <h4 className={`font-bold text-slate-800 text-sm ${isClosed ? 'line-through text-slate-400' : ''}`}>
                                      {branch.name}
                                    </h4>
                                    <span className="bg-slate-105 text-slate-600 text-[9px] px-1 rounded font-mono font-bold">
                                      কোড: {branch.code}
                                    </span>
                                  </div>
                                </div>
                              </td>

                              {/* Manager */}
                              <td className="px-4 py-3 whitespace-nowrap">
                                {currentManager ? (
                                  <span className="bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-lg text-[11px] font-bold">
                                    {currentManager.name}
                                  </span>
                                ) : (
                                  <span className="text-slate-400 italic text-[11px]">নিযুক্ত নয় (অটো সিলেক্ট)</span>
                                )}
                              </td>

                              {/* Address */}
                              <td className="px-4 py-3 max-w-[180px] truncate text-slate-600 font-medium" title={branch.address}>
                                {branch.address}
                              </td>

                              {/* Phone */}
                              <td className="px-4 py-3 whitespace-nowrap font-mono text-slate-600 font-medium">
                                {branch.phone}
                              </td>

                              {/* Joining Date */}
                              <td className="px-4 py-3 whitespace-nowrap font-mono text-slate-500">
                                {branch.addDate}
                              </td>

                              {/* Status Info */}
                              <td className="px-4 py-3 whitespace-nowrap text-right">
                                <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                  isClosed 
                                    ? 'bg-rose-50 text-rose-600 border border-rose-100' 
                                    : 'bg-emerald-50 text-emerald-600 border border-emerald-100'
                                }`}>
                                  <span className={`w-1.5 h-1.5 rounded-full ${isClosed ? 'bg-rose-500 animate-pulse' : 'bg-emerald-500'}`}></span>
                                  {isClosed ? 'বন্ধ (Closed)' : 'সচল (Active)'}
                                </span>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Branch Modal Form */}
              {isBranchModalOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
                  <div className="bg-white rounded-xl shadow-xl max-w-md w-full overflow-hidden border border-slate-100 animate-in fade-in zoom-in-95 duration-150">
                    <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
                      <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                        <Building size={16} className="text-blue-600" /> 
                        {isBranchEditMode ? 'শাখা অফিস তথ্য সংশোধন (Edit)' : 'নতুন শাখা অফিস নিবন্ধন'}
                      </h3>
                      <button onClick={() => setIsBranchModalOpen(false)} className="text-slate-400 hover:text-slate-600 p-0.5">
                        <X size={18} />
                      </button>
                    </div>
                    
                    <form onSubmit={handleAddBranch} className="p-5 space-y-3.5">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">শাখার নাম *</label>
                          <input 
                            type="text" 
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-bold" 
                            value={branchName} 
                            onChange={(e) => setBranchName(e.target.value)}
                            placeholder="যেমন, মিরপুর শাখা"
                            required
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">শাখা কোড *</label>
                          <input 
                            type="text" 
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-mono font-bold" 
                            value={branchCode} 
                            onChange={(e) => setBranchCode(e.target.value)}
                            placeholder="যেমন, MIR-01"
                            required
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1">যোগাযোগ ফোন *</label>
                        <input 
                          type="tel" 
                          className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-bold" 
                          value={branchPhone} 
                          onChange={(e) => setBranchPhone(e.target.value)}
                          placeholder="01XXXXXXXXX"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1">শাখার ঠিকানা *</label>
                        <input 
                          type="text" 
                          className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-bold" 
                          value={branchAddress} 
                          onChange={(e) => setBranchAddress(e.target.value)}
                          placeholder="পূর্ণ ঠিকানা লিখুন"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1">প্রতিষ্ঠার তারিখ</label>
                        <input 
                          type="date" 
                          className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-bold" 
                          value={branchDate} 
                          onChange={(e) => setBranchDate(e.target.value)}
                          required
                        />
                      </div>

                      <div className="flex gap-2.5 pt-3">
                        <button 
                          type="button" 
                          onClick={() => setIsBranchModalOpen(false)}
                          className="flex-1 py-1.5 text-xs font-bold text-slate-600 bg-slate-100 rounded-lg cursor-pointer"
                        >
                          বাতিল
                        </button>
                        <button 
                          type="submit"
                          className="flex-1 py-1.5 text-xs font-bold text-white bg-blue-600 rounded-lg hover:bg-blue-700 cursor-pointer"
                        >
                          {isBranchEditMode ? 'সংশোধন নিশ্চিত করুন' : 'নিশ্চিত করুন'}
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}

            </div>
          )}
          {/* VIEW 2: Staff Management / কর্মকর্তা / কর্মী তালিকা */}
          {activeTab === 'staff' && (
            <div className="space-y-5 animate-in fade-in duration-100">
              
              <div className="flex justify-between items-center flex-wrap gap-3 border-b border-slate-100 pb-4">
                <div>
                  <h3 className="text-lg font-bold text-slate-800">কর্মকর্তা ও মাঠ কর্মী তালিকা</h3>
                  <p className="text-xs text-slate-400">আপনার প্রতিষ্ঠানে নিয়োজিত সকল কর্মকর্তা ও মাঠ কর্মীদের ডাটাবেস।</p>
                </div>

                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2 text-slate-400" size={14} />
                    <input 
                      type="text" 
                      placeholder="কর্মী খুঁজুন..."
                      className="pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs w-44 focus:outline-none focus:ring-1 focus:ring-blue-500"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  
                  <button 
                    onClick={() => {
                      setIsStaffEditMode(false);
                      setEditingStaffId(null);
                      setStaffName('');
                      setStaffPhone('');
                      setStaffDesignation('মাঠ কর্মী');
                      setStaffBranchId('');
                      setStaffBranchJoiningDate(new Date().toISOString().split('T')[0]);
                      setIsStaffModalOpen(true);
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition-colors shadow-xs cursor-pointer"
                  >
                    <Plus size={14} />
                    <span>নতুন কর্মী যুক্ত করুন</span>
                  </button>
                </div>
              </div>

              {/* Staff List Table layout */}
              {filteredStaff.length === 0 ? (
                <div className="bg-slate-50 rounded-2xl border border-dashed border-slate-200 p-12 text-center">
                  <UserCheck className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-500 text-sm font-medium">কোনো কর্মকর্তা বা কর্মীর তথ্য পাওয়া যায়নি।</p>
                  <p className="text-slate-400 text-xs mt-1">নতুন কোনো কর্মকর্তা যুক্ত করতে "নতুন কর্মী যুক্ত করুন" বাটনে ক্লিক করুন।</p>
                </div>
              ) : (
                <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200">
                          <th className="py-3 px-4 text-xs font-bold text-slate-500 text-[11px] uppercase tracking-wider">নাম ও পদবী</th>
                          <th className="py-3 px-4 text-xs font-bold text-slate-500 text-[11px] uppercase tracking-wider">লগইন ক্রেডেনশিয়াল</th>
                          <th className="py-3 px-4 text-xs font-bold text-slate-500 text-[11px] uppercase tracking-wider">স্থলাভিষিক্ত শাখা</th>
                          <th className="py-3 px-4 text-xs font-bold text-slate-500 text-[11px] uppercase tracking-wider">যোগযোগ ও যোগদান</th>
                          <th className="py-3 px-4 text-xs font-bold text-slate-500 text-[11px] uppercase tracking-wider text-right">কার্যক্রম (Actions)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {filteredStaff.map((staff) => {
                          const assignedBranch = branchesList.find(b => b.id === staff.branchId);
                          return (
                            <tr key={staff.id} className="hover:bg-slate-50/50 transition-colors">
                              <td className="py-3.5 px-4">
                                <div className="flex items-center gap-3">
                                  <div className="w-9 h-9 bg-blue-50 text-blue-700 rounded-full flex items-center justify-center shrink-0 font-extrabold text-xs">
                                    {staff.name.charAt(0)}
                                  </div>
                                  <div>
                                    <h4 className="font-bold text-slate-800 text-xs sm:text-sm">{staff.name}</h4>
                                    <span className="inline-block px-2 py-0.5 bg-slate-100 text-slate-600 font-bold rounded text-[9px] mt-0.5">
                                      {staff.designation}
                                    </span>
                                  </div>
                                </div>
                              </td>
                              
                              <td className="py-3.5 px-4">
                                {(staff.staffId || staff.password) && (
                                  <div className="space-y-1 text-slate-600 font-mono text-[10px] bg-slate-50 p-2 rounded-lg border border-slate-100 inline-block min-w-[160px]">
                                    <div className="flex justify-between gap-3">
                                      <span className="text-slate-400">আইডি (UID):</span>
                                      <span className="font-bold text-blue-700 select-all">{staff.staffId}</span>
                                    </div>
                                    <div className="flex justify-between gap-3">
                                      <span className="text-slate-400">পাসওয়ার্ড:</span>
                                      <span className="font-bold text-slate-700 select-all">{staff.password}</span>
                                    </div>
                                  </div>
                                )}
                              </td>

                              <td className="py-3.5 px-4">
                                {assignedBranch ? (
                                  <div>
                                    <span className="inline-block text-blue-700 font-bold bg-blue-50 px-2 py-0.5 rounded text-[10px]">
                                      {assignedBranch.name}
                                    </span>
                                    {staff.branchJoiningDate && (
                                      <p className="text-[9px] text-slate-400 mt-0.5 font-mono">
                                        যোগদান: {staff.branchJoiningDate}
                                      </p>
                                    )}
                                  </div>
                                ) : (
                                  <span className="inline-block text-slate-500 bg-slate-100 px-2 py-0.5 rounded text-[10px]">
                                    প্রধান কার্যালয় / অনিযুক্ত
                                  </span>
                                )}
                              </td>

                              <td className="py-3.5 px-4 text-xs text-slate-600">
                                <div className="space-y-0.5">
                                  <p className="flex items-center gap-1 font-mono text-[11px]">
                                    <Phone size={11} className="text-slate-400" /> {staff.phone}
                                  </p>
                                  <p className="flex items-center gap-1 text-[10px] text-slate-400">
                                    <Calendar size={11} /> যোগদান: {staff.joiningDate}
                                  </p>
                                </div>
                              </td>

                              <td className="py-3.5 px-4 text-right">
                                <div className="flex items-center justify-end gap-1.5">
                                  {/* Edit button */}
                                  <button
                                    onClick={() => handleEditStaffClick(staff)}
                                    className="p-1.5 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                                    title="কর্মী তথ্য সংশোধন"
                                  >
                                    <Pencil size={13} />
                                  </button>

                                  {/* Delete button */}
                                  {!staff.staffId?.startsWith('ILO') && (
                                    <button
                                      onClick={() => handleDeleteStaff(staff.id, staff.name)}
                                      className="p-1.5 text-rose-500 hover:text-rose-750 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                                      title="কর্মী বাদ দিন"
                                    >
                                      <Trash2 size={13} />
                                    </button>
                                  )}
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Staff Edit / Add Modal */}
              {isStaffModalOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-100">
                  <div className="bg-white rounded-xl shadow-xl max-w-sm w-full overflow-hidden border border-slate-100 animate-in zoom-in-95 duration-150">
                    <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
                      <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                        <UserCheck size={16} className="text-blue-600" /> 
                        <span>{isStaffEditMode ? 'কর্মী তথ্য সম্পাদন করুন' : 'নতুন কর্মকর্তা বা কর্মী যুক্ত করুন'}</span>
                      </h3>
                      <button onClick={() => setIsStaffModalOpen(false)} className="text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer">
                        <X size={18} />
                      </button>
                    </div>
                    
                    <form onSubmit={handleAddStaff} className="p-5 space-y-3.5">
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1">কর্মকর্তা / কর্মীর নাম *</label>
                        <input 
                          type="text" 
                          className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs" 
                          value={staffName} 
                          onChange={(e) => setStaffName(e.target.value)}
                          placeholder="যেমন, মো: আরিফুল রহমান"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1">মোবাইল ফোন নম্বর *</label>
                        <input 
                          type="tel" 
                          className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-mono font-bold" 
                          value={staffPhone} 
                          onChange={(e) => setStaffPhone(e.target.value)}
                          placeholder="01XXXXXXXXX"
                          required
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">পদবী</label>
                          <select 
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs bg-white font-medium"
                            value={staffDesignation}
                            onChange={(e) => setStaffDesignation(e.target.value)}
                          >
                            <option value="মাঠ কর্মী">মাঠ কর্মী</option>
                            <option value="শাখা ব্যবস্থাপক">শাখা ব্যবস্থাপক</option>
                            <option value="সহকারী ব্যবস্থাপক">সহকারী ব্যবস্থাপক</option>
                            <option value="কো-অর্ডিনেটর">কো-অর্ডিনেটর</option>
                            <option value="অন্যান্য কর্মকর্তা">অন্যান্য কর্মকর্তা</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">যোগদানের তারিখ</label>
                          <input 
                            type="date" 
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-mono font-bold" 
                            value={staffDate} 
                            onChange={(e) => setStaffDate(e.target.value)}
                            required
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">কর্মরত শাখা (Branch)</label>
                          <select 
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs bg-white font-medium"
                            value={staffBranchId}
                            onChange={(e) => setStaffBranchId(e.target.value)}
                          >
                            <option value="">প্রধান কার্যালয় / অনিযুক্ত</option>
                            {branchesList.map(b => (
                              <option key={b.id} value={b.id}>{b.name}</option>
                            ))}
                          </select>
                        </div>

                        {staffBranchId && (
                          <div>
                            <label className="block text-xs font-semibold text-slate-500 mb-1">ব্রাঞ্চে যোগদানের তারিখ</label>
                            <input 
                              type="date" 
                              className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-mono font-bold" 
                              value={staffBranchJoiningDate} 
                              onChange={(e) => setStaffBranchJoiningDate(e.target.value)}
                              required
                            />
                          </div>
                        )}
                      </div>

                      <div className="flex gap-2.5 pt-3">
                        <button 
                          type="button" 
                          onClick={() => setIsStaffModalOpen(false)}
                          className="flex-1 py-1.5 text-xs font-bold text-slate-600 bg-slate-100 rounded-lg cursor-pointer"
                        >
                          বাতিল
                        </button>
                        <button 
                          type="submit"
                          className="flex-1 py-1.5 text-xs font-bold text-white bg-blue-600 rounded-lg hover:bg-blue-700 cursor-pointer"
                        >
                          {isStaffEditMode ? 'হালনাগাদ (Update)' : 'সংরক্ষণ করুন'}
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}

            </div>
          )}

          {/* VIEW 3: Configuration Panel / কনফিগারেশন */}
          {activeTab === 'config' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="border-b border-slate-100 pb-4">
                <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                  <Settings className="text-blue-600" size={20} />
                  <span>প্রতিষ্ঠান পলিসি ও লোগো কনফিগারেশন প্যানেল</span>
                </h3>
                <p className="text-xs text-slate-400">আপনার নিজস্ব প্রতিষ্ঠানের প্রোফাইল, লোগো স্টাইল এবং এমআরএ (MRA) সহায়িকা মোতাবেক সঞ্চয় ও ঋণ নীতি নির্ধারণ করুন।</p>
              </div>

              {configSuccessMsg && (
                <div id="config-success-toast" className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-bold animate-in fade-in slide-in-from-top-2 duration-200 flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></div>
                  <span>{configSuccessMsg}</span>
                </div>
              )}

              <form onSubmit={handleSaveConfig} className="space-y-6">
                <div className="grid gap-6 md:grid-cols-2">
                  
                  {/* --- SECTION 1: GENERAL INFO (সাধারণ তথ্য) --- */}
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                    <h4 className="text-[12px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5 border-b border-slate-100 pb-2.5">
                      <Shield size={14} className="text-blue-600" /> ১. সাধারণ ও লোগো সেটিংস
                    </h4>

                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-1">প্রতিষ্ঠানের নাম</label>
                          <input 
                            type="text"
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium focus:ring-1 focus:ring-blue-500 focus:outline-none"
                            value={orgName}
                            onChange={(e) => setOrgName(e.target.value)}
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-1">লোগো থিম / স্টাইল</label>
                          <select 
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium focus:ring-1 focus:ring-blue-500 focus:outline-none bg-white"
                            value={orgLogoStyle}
                            onChange={(e) => setOrgLogoStyle(e.target.value)}
                          >
                            <option value="shield">🛡️ সুরক্ষাকবচ (Shield)</option>
                            <option value="building">🏢 কর্পোরেট ভবন (Building)</option>
                            <option value="globe">🌐 আন্তর্জাতিক / গোলক (Globe)</option>
                            <option value="filetext">📄 রিপোর্টিং নথি (FileText)</option>
                            <option value="sliders">🎚️ কন্ট্রোল নব (Sliders)</option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-1">ঠিকানা (বিস্তারিত)</label>
                        <input 
                          type="text"
                          className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-medium focus:ring-1 focus:ring-blue-500 focus:outline-none"
                          value={orgAddress}
                          onChange={(e) => setOrgAddress(e.target.value)}
                          required
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-1">ফোন নম্বর</label>
                          <input 
                            type="text"
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium focus:ring-1 focus:ring-blue-500 focus:outline-none"
                            value={orgPhone}
                            onChange={(e) => setOrgPhone(e.target.value)}
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-1">ইমেইল ঠিকানা</label>
                          <input 
                            type="email"
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium focus:ring-1 focus:ring-blue-500 focus:outline-none"
                            value={orgEmail}
                            onChange={(e) => setOrgEmail(e.target.value)}
                            required
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-1">ওয়েবসাইট ইউআরএল</label>
                          <input 
                            type="text"
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-blue-500 focus:outline-none"
                            value={orgWebsite}
                            onChange={(e) => setOrgWebsite(e.target.value)}
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-1">ট্রেড লাইসেন্স / রেজি নম্বর</label>
                          <input 
                            type="text"
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-bold font-mono focus:ring-1 focus:ring-blue-500 focus:outline-none"
                            value={orgTradeLicense}
                            onChange={(e) => setOrgTradeLicense(e.target.value)}
                            required
                          />
                        </div>
                      </div>

                      <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 flex justify-between items-center text-xs">
                        <div>
                          <p className="font-bold text-slate-700">অ্যাডমিন পাসওয়ার্ড পরিবর্তন</p>
                          <p className="text-[10px] text-slate-400 mt-0.5">টপবারের পাসওয়ার্ড পরিবর্তন বাটন ব্যবহার করুন।</p>
                        </div>
                        <span className="font-mono bg-slate-200 px-2 py-0.5 rounded text-[10px] font-bold">ক্রিপ্ট-লক</span>
                      </div>
                    </div>
                  </div>

                  {/* --- SECTION 2: LOAN CONFIGURATION (ঋণ কনফিগারেশন) --- */}
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                    <h4 className="text-[12px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5 border-b border-slate-100 pb-2.5">
                      <Sliders size={14} className="text-indigo-600" /> ২. ঋণ নীতিমালা ও সুদ সেটিংস
                    </h4>

                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-1">ডিফল্ট সুদের হার (%)</label>
                          <div className="relative">
                            <span className="absolute right-3 top-1.5 text-xs text-slate-400 font-bold">%</span>
                            <input 
                              type="text"
                              className="w-full pl-3 pr-7 py-1.5 border border-slate-200 rounded-lg text-xs font-bold focus:ring-1 focus:ring-blue-500 focus:outline-none"
                              value={loanDefaultInterest}
                              onChange={(e) => setLoanDefaultInterest(e.target.value)}
                              required
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-1">সুদের হিসাব পদ্ধতি</label>
                          <select 
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium focus:ring-1 focus:ring-blue-500 focus:outline-none bg-white"
                            value={loanInterestType}
                            onChange={(e) => setLoanInterestType(e.target.value)}
                          >
                            <option value="Flat">সরল সুদ পদ্ধতি (Flat Interest)</option>
                            <option value="Declining">হ্রাসমান স্থিতি পদ্ধতি (Declining)</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-1">সর্বনিম্ন ঋণ অনুমোদন সীমা</label>
                          <div className="relative">
                            <span className="absolute left-3 top-1.5 text-xs text-slate-400 font-bold font-mono">৳</span>
                            <input 
                              type="text"
                              className="w-full pl-7 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs font-bold focus:ring-1 focus:ring-blue-500 focus:outline-none"
                              value={loanMinAmount}
                              onChange={(e) => setLoanMinAmount(e.target.value)}
                              required
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-1">সর্বোচ্চ ঋণ অনুমোদন সীমা</label>
                          <div className="relative">
                            <span className="absolute left-3 top-1.5 text-xs text-slate-400 font-bold font-mono">৳</span>
                            <input 
                              type="text"
                              className="w-full pl-7 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs font-bold focus:ring-1 focus:ring-blue-500 focus:outline-none"
                              value={loanMaxAmount}
                              onChange={(e) => setLoanMaxAmount(e.target.value)}
                              required
                            />
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-1">ঋণের মেয়াদ / কিস্তি সংখ্যা</label>
                          <input 
                            type="text"
                            placeholder="যেমন: ৪৫ সপ্তাহ"
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium focus:ring-1 focus:ring-blue-500 focus:outline-none"
                            value={loanDuration}
                            onChange={(e) => setLoanDuration(e.target.value)}
                            required
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-1">গ্রেস পিরিয়ড (Grace Period)</label>
                          <input 
                            type="text"
                            placeholder="যেমন: ২ সপ্তাহ"
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium focus:ring-1 focus:ring-blue-500 focus:outline-none"
                            value={loanGracePeriod}
                            onChange={(e) => setLoanGracePeriod(e.target.value)}
                            required
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-1">বিলম্ব জরিমানা (Late Fee)</label>
                          <div className="relative">
                            <span className="absolute left-3 top-1.5 text-xs text-slate-400 font-bold font-mono">৳</span>
                            <input 
                              type="text"
                              className="w-full pl-7 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs font-bold focus:ring-1 focus:ring-blue-500 focus:outline-none"
                              value={loanLateFee}
                              onChange={(e) => setLoanLateFee(e.target.value)}
                              required
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-1">ঋণ প্রসেসিং বা ফরম ফি</label>
                          <div className="relative">
                            <span className="absolute left-3 top-1.5 text-xs text-slate-400 font-bold font-mono">৳</span>
                            <input 
                              type="text"
                              className="w-full pl-7 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs font-bold focus:ring-1 focus:ring-blue-500 focus:outline-none"
                              value={loanProcessingFee}
                              onChange={(e) => setLoanProcessingFee(e.target.value)}
                              required
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* --- SECTION 3: INSTALLMENT CONFIGURATION (কিস্তি কনফিগারেশন) --- */}
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                    <h4 className="text-[12px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5 border-b border-slate-100 pb-2.5">
                      <Calendar size={14} className="text-emerald-600" /> ৩. কিস্তি গ্রহণ ও আদায় সময়সূচী সেটিংস
                    </h4>

                    <div className="space-y-3">
                      <div>
                        <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-2">সমর্থিত কিস্তির প্রকারভেদ সমূহ</label>
                        <div className="flex flex-wrap gap-4 p-3 bg-slate-50 border border-slate-150 rounded-xl">
                          <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-700">
                            <input 
                              type="checkbox"
                              className="w-4 h-4 text-blue-600 focus:ring-0 border-slate-300 rounded cursor-pointer"
                              checked={instWeeklyActive}
                              onChange={(e) => setInstWeeklyActive(e.target.checked)}
                            />
                            <span>সাপ্তাহিক কিস্তি</span>
                          </label>

                          <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-700">
                            <input 
                              type="checkbox"
                              className="w-4 h-4 text-blue-600 focus:ring-0 border-slate-300 rounded cursor-pointer"
                              checked={instMonthlyActive}
                              onChange={(e) => setInstMonthlyActive(e.target.checked)}
                            />
                            <span>মাসিক কিস্তি</span>
                          </label>

                          <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-700">
                            <input 
                              type="checkbox"
                              className="w-4 h-4 text-blue-600 focus:ring-0 border-slate-300 rounded cursor-pointer"
                              checked={instTermActive}
                              onChange={(e) => setInstTermActive(e.target.checked)}
                            />
                            <span>মেয়াদি কিস্তি (Term Installment)</span>
                          </label>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-1">ডিফল্ট কিস্তির দিন</label>
                          <select 
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium focus:ring-1 focus:ring-blue-500 focus:outline-none bg-white"
                            value={instCollectionDay}
                            onChange={(e) => setInstCollectionDay(e.target.value)}
                          >
                            <option value="সমিতির বার ভিত্তিক">সমিতির বার ভিত্তিক (বার ভিত্তিক কিস্তি)</option>
                            <option value="রবিবার">রবিবার (Sunday)</option>
                            <option value="সোমবার">সোমবার (Monday)</option>
                            <option value="মঙ্গলবার">মঙ্গলবার (Tuesday)</option>
                            <option value="বুধবার">বুধবার (Wednesday)</option>
                            <option value="বৃহস্পতিবার">বৃহস্পতিবার (Thursday)</option>
                            <option value="শুক্রবার">শুক্রবার (Friday)</option>
                            <option value="শনিবার">শনিবার (Saturday)</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-1">কিস্তি দশমিক রাউন্ডিং নিয়ম</label>
                          <select 
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-medium focus:ring-1 focus:ring-blue-500 focus:outline-none bg-white"
                            value={instRoundingRule}
                            onChange={(e) => setInstRoundingRule(e.target.value)}
                          >
                            <option value="Nearest 1">নিকটবর্তী ৳১ (যেমন: ৳৪৫১.৪ → ৳৪৫১)</option>
                            <option value="Nearest 5">নিকটবর্তী ৳৫ (যেমন: ৳৪৫৩ → ৳৪৫৫)</option>
                            <option value="Nearest 10">নিকটবর্তী ৳১০ (যেমন: ৳৪৫২ → ৳৪৫০)</option>
                            <option value="None">কোনো রাউন্ডিং নেই</option>
                          </select>
                        </div>
                      </div>

                      <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 flex justify-between items-center text-xs">
                        <div>
                          <p className="font-bold text-slate-700">স্বয়ংক্রিয় (Auto) কিস্তি জেনারেশন</p>
                          <p className="text-[10px] text-slate-400 mt-0.5">মঞ্জুরির পর অটো পরিশোধ সময়সূচী জেনারেট করুন।</p>
                        </div>
                        <input 
                          type="checkbox"
                          className="w-4 h-4 text-blue-600 focus:ring-0 border-slate-300 rounded cursor-pointer"
                          checked={instAutoGeneration}
                          onChange={(e) => setInstAutoGeneration(e.target.checked)}
                        />
                      </div>
                    </div>
                  </div>

                  {/* --- SECTION 4: SAVINGS CONFIGURATION (সঞ্চয় কনফিগারেশন) --- */}
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                    <h4 className="text-[12px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5 border-b border-slate-100 pb-2.5">
                      <Users size={14} className="text-amber-600" /> ৪. চার ধরণের সাধারণ সঞ্চয় পলিসি ও সদস্য ভর্তি সেটিংস
                    </h4>

                    <div className="space-y-4">
                      {/* Notice about Savings Withdraw Limits */}
                      <div className="p-3 bg-blue-50/50 border border-blue-105 rounded-xl text-[11px] text-blue-800 flex items-start gap-2">
                        <Info size={14} className="text-blue-500 shrink-0 mt-0.5" />
                        <div>
                          <strong>সঞ্চয় উত্তোলন প্রবিধান:</strong> তানজিল মাইক্রোক্রেডিট সিস্টেমে <strong>সঞ্চয় উত্তোলনের কোনো সীমা থাকবে না</strong> (সদস্যরা যেকোনো সময় তাদের সঞ্চয় থেকে উত্তোলন করতে পারবেন)।
                        </div>
                      </div>

                      {/* 4 Types of Savings Dividends */}
                      <div className="bg-slate-50 p-4 rounded-xl border border-slate-150 space-y-3">
                        <h5 className="text-[11px] font-extrabold text-slate-700 uppercase tracking-widest">চার ধরনের সঞ্চয় ও লভ্যাংশ হার (%)</h5>
                        
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                          <div>
                            <label className="block text-[10px] font-bold text-slate-600 mb-1">সাধারণ সঞ্চয় (GS)</label>
                            <div className="relative">
                              <span className="absolute right-2 top-1.5 text-[10px] text-slate-400 font-bold">%</span>
                              <input 
                                type="text"
                                className="w-full pl-2 pr-5 py-1.5 border border-slate-200 rounded-lg text-xs font-mono font-bold text-center"
                                value={savProfitGS}
                                onChange={(e) => setSavProfitGS(e.target.value)}
                                required
                              />
                            </div>
                          </div>

                          <div>
                            <label className="block text-[10px] font-bold text-slate-600 mb-1">মূলধন সঞ্চয় (CBS)</label>
                            <div className="relative">
                              <span className="absolute right-2 top-1.5 text-[10px] text-slate-400 font-bold">%</span>
                              <input 
                                type="text"
                                className="w-full pl-2 pr-5 py-1.5 border border-slate-200 rounded-lg text-xs font-mono font-bold text-center"
                                value={savProfitCBS}
                                onChange={(e) => setSavProfitCBS(e.target.value)}
                                required
                              />
                            </div>
                          </div>

                          <div>
                            <label className="block text-[10px] font-bold text-slate-600 mb-1">দীর্ঘমেয়াদী সঞ্চয় (LTS)</label>
                            <div className="relative">
                              <span className="absolute right-2 top-1.5 text-[10px] text-slate-400 font-bold">%</span>
                              <input 
                                type="text"
                                className="w-full pl-2 pr-5 py-1.5 border border-slate-200 rounded-lg text-xs font-mono font-bold text-center"
                                value={savProfitLTS}
                                onChange={(e) => setSavProfitLTS(e.target.value)}
                                required
                              />
                            </div>
                          </div>

                          <div>
                            <label className="block text-[10px] font-bold text-slate-600 mb-1">ফিক্সড ডিপোজিট (FDR)</label>
                            <div className="relative">
                              <span className="absolute right-2 top-1.5 text-[10px] text-slate-400 font-bold">%</span>
                              <input 
                                type="text"
                                className="w-full pl-2 pr-5 py-1.5 border border-slate-200 rounded-lg text-xs font-mono font-bold text-center"
                                value={savProfitFDR}
                                onChange={(e) => setSavProfitFDR(e.target.value)}
                                required
                              />
                            </div>
                          </div>
                        </div>

                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-white p-2.5 rounded-lg border border-slate-200 text-[11px] gap-2 mt-2">
                          <span className="font-semibold text-slate-600">Fixed Deposit (F FDR) এর লভ্যাংশ প্রদানের ধরন:</span>
                          <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-800 font-bold rounded-full text-[10px]">
                            {savFdrPayoutType} (фиксированный)
                          </span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-1">সর্বনিম্ন সঞ্চয় জমা (৳)</label>
                          <div className="relative">
                            <span className="absolute left-3 top-1.5 text-xs text-slate-400 font-bold font-mono">৳</span>
                            <input 
                              type="text"
                              className="w-full pl-7 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs font-bold focus:ring-1 focus:ring-blue-500 focus:outline-none"
                              value={savingsMinDeposit}
                              onChange={(e) => setSavingsMinDeposit(e.target.value)}
                              required
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-1">সদস্যের ন্যূনতম ব্যালেন্স (৳)</label>
                          <div className="relative">
                            <span className="absolute left-3 top-1.5 text-xs text-slate-400 font-bold font-mono">৳</span>
                            <input 
                              type="text"
                              className="w-full pl-7 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs font-bold focus:ring-1 focus:ring-blue-500 focus:outline-none"
                              value={savingsMinBalance}
                              onChange={(e) => setSavingsMinBalance(e.target.value)}
                              required
                            />
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-1">সদস্য ভর্তি ফি (নতুন ফরম ফি)</label>
                          <div className="relative">
                            <span className="absolute left-3 top-1.5 text-xs text-slate-400 font-bold font-mono">৳</span>
                            <input 
                              type="text"
                              className="w-full pl-7 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs font-bold focus:ring-1 focus:ring-blue-500 focus:outline-none"
                              value={savingsAdmissionFee}
                              onChange={(e) => setSavingsAdmissionFee(e.target.value)}
                              required
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-[10px] sm:text-xs font-bold text-slate-600 mb-1">সদস্য কল্যাণ তহবিল চাঁদা</label>
                          <div className="relative">
                            <span className="absolute left-3 top-1.5 text-xs text-slate-400 font-bold font-mono">৳</span>
                            <input 
                              type="text"
                              className="w-full pl-7 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs font-bold focus:ring-1 focus:ring-blue-500 focus:outline-none"
                              value={savingsWelfareFee}
                              onChange={(e) => setSavingsWelfareFee(e.target.value)}
                              required
                            />
                          </div>
                        </div>
                      </div>

                      {/* ঋণবীমা তহবিল ও বাধ্যতামূলক সঞ্চয় সেটিংস */}
                      <div className="p-4 bg-amber-50/50 rounded-xl border border-amber-100 space-y-3.5">
                        <h5 className="text-[11px] font-extrabold text-amber-900 uppercase tracking-widest">ঋণবীমা তহবিল ও বাধ্যতামূলক সঞ্চয় সেটিংস</h5>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[10px] font-bold text-slate-605 mb-1 text-amber-950">ঋণবীমা তহবিল যৌথ নির্ধারণ (% হিসেবে)</label>
                            <div className="relative">
                              <span className="absolute right-3 top-1.5 text-xs text-slate-400 font-bold">%</span>
                              <input 
                                type="text"
                                className="w-full pl-3 pr-8 py-1.5 border border-slate-200 rounded-lg text-xs font-bold bg-white"
                                value={loanInsurancePercent}
                                onChange={(e) => setLoanInsurancePercent(e.target.value)}
                                placeholder="যেমন: ১০"
                                required
                              />
                            </div>
                            <span className="text-[9px] text-amber-805 mt-1 block">যৌথ বীমার হার (ডিফল্ট ১০%) ও একক বীমা ০.৫%। এটি আসলের ওপর হিসাব করে নগদ প্রিমিয়াম হিসেবে আদায় হবে।</span>
                          </div>

                          <div>
                            <label className="block text-[10px] font-bold text-slate-605 mb-1 text-amber-950">বীমার ধরণ</label>
                            <select 
                              className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-bold bg-white"
                              value={loanInsuranceType}
                              onChange={(e) => setLoanInsuranceType(e.target.value)}
                            >
                              <option value="যৌথ বীমা">যৌথ বীমা</option>
                              <option value="একক বীমা">একক বীমা</option>
                            </select>
                            <span className="text-[9px] text-amber-800 mt-1 block">যৌথ/একক বীমা পলিসি ধরণ</span>
                          </div>
                        </div>

                        <div className="border-t border-amber-100/60 pt-3">
                          <label className="block text-[10px] font-bold text-slate-605 mb-1 text-amber-950">বাধ্যতামূলক সঞ্চয় (ঋণের আসলের %)</label>
                          <div className="relative">
                            <span className="absolute right-3 top-1.5 text-xs text-slate-400 font-bold">%</span>
                            <input 
                              type="text"
                              className="w-full pl-3 pr-8 py-1.5 border border-slate-200 rounded-lg text-xs font-bold bg-white"
                              value={mandatorySavingsPercent}
                              onChange={(e) => setMandatorySavingsPercent(e.target.value)}
                              placeholder="যেমন: ৫"
                              required
                            />
                          </div>
                          <span className="text-[9px] text-amber-800 mt-1 block">যা ঋণ চলাকালীন বাধ্যতামূলকভাবে সদস্যের জমা থাকতে হবে</span>
                        </div>
                      </div>

                    </div>
                  </div>

                </div>

                <div className="flex justify-end pt-3 border-t border-slate-100 gap-3">
                  <button 
                    type="submit"
                    className="flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-all shadow-md shadow-blue-500/10 cursor-pointer"
                  >
                    <Save size={14} />
                    <span>কনফিগারেশন সংরক্ষণ করুন</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* VIEW 4: Reports / রিপোর্ট প্যানেল */}
          {activeTab === 'reports' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              
              {/* Report Header Card with Dropdown and Print Actions */}
              <div className="bg-gradient-to-r from-blue-700 via-indigo-800 to-indigo-900 rounded-2xl p-5 text-white shadow-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <h3 className="text-lg font-extrabold flex items-center gap-2 tracking-tight">
                    <FileText className="text-emerald-350" size={22} />
                    <span>তানজিল প্রতিবেদন ও রিপোর্ট প্যানেল</span>
                  </h3>
                  <p className="text-[11px] text-indigo-100 mt-1">
                    আজকের অফিসিয়াল কর্মদিবসের সকল আর্থিক স্কিম, শাখা বিবরণী, কর্মী ডাটাবেজ এবং নীতিমালা বিবরণী রিপোর্ট ডাউনলোড বা প্রিন্ট করুন।
                  </p>
                </div>
                <div className="bg-white/10 px-3.5 py-1.5 rounded-xl border border-white/15 text-right shrink-0">
                  <span className="text-[9px] text-white/70 uppercase tracking-widest font-bold block">অফিসিয়াল কর্মদিবস:</span>
                  <span className="font-mono text-xs font-black text-amber-300">{workingDay}</span>
                </div>
              </div>

              {/* DROPDOWN SELECTOR - User Request Specific */}
              <div className="bg-slate-50 p-4 border border-slate-200 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-0.5">
                  <label htmlFor="report-dropdown" className="block text-[11px] font-black text-slate-550 uppercase tracking-widest">
                    রিপোর্ট ক্যাটাগরি ড্রপডাউন (Select Active Report Sheet)
                  </label>
                  <p className="text-[10px] text-slate-400 font-medium">নিচের ড্রপডাউন থেকে আপনার পছন্দসই রিপোর্ট পৃষ্ঠা নির্বাচন করুন</p>
                </div>
                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <select
                    id="report-dropdown"
                    value={selectedReportType}
                    onChange={(e) => setSelectedReportType(e.target.value)}
                    className="w-full sm:w-64 px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-700 min-w-[240px] focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-xs cursor-pointer"
                  >
                    <option value="loan_calc">১. ঋণের কিস্তি হিসাব ও বিতরণ এস্টিমেটর (Loan Calculator)</option>
                    <option value="branches">২. রেজিস্টার্ড শাখা অফিস বিবরণী রিপোর্ট (Branches)</option>
                    <option value="staff">৩. কর্মকর্তা ও কর্মী বিস্তারিত তালিকা রিপোর্ট (Staff List)</option>
                    <option value="holidays">৪. ঘোষিত ছুটির ক্যালেন্ডার বিবরণী (Holidays)</option>
                    <option value="policies">৫. প্রাতিষ্ঠানিক ক্ষুদ্রঋণ ও সঞ্চয় নীতিমালা বিবরণী</option>
                  </select>
                  <button
                    onClick={() => {
                      window.print();
                    }}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1 cursor-pointer whitespace-nowrap"
                  >
                    <span>প্রিন্ট</span>
                  </button>
                </div>
              </div>

              {/* Depending on report type, show specific section */}
              {selectedReportType === 'loan_calc' ? (
                /* RENDER EXISTING CALCULATOR SECTION */
                <div className="space-y-6">
                  <div className="border-b border-slate-100 pb-3 flex justify-between items-center">
                    <div>
                      <h4 className="font-extrabold text-slate-800 text-sm">১. মেম্বারশিপ ইন্টারেক্টিভ ক্যাস ক্যালকুলেশন (Disbursement Sandbox)</h4>
                      <p className="text-[10px] text-slate-400">বীমা পদ্ধতি, ক্যালকুলেশন পলিসি এবং এস্টিমেটে বিতরণ প্রক্রিয়া পর্যবেক্ষণ করুন</p>
                    </div>
                    {isDisbursedSuccess && (
                      <button 
                        onClick={() => {
                          setIsDisbursedSuccess(false);
                          setLastDisbursedSummary(null);
                        }}
                        className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-bold rounded-lg transition-colors cursor-pointer"
                      >
                        নতুন হিসাব করুন
                      </button>
                    )}
                  </div>

                  {isDisbursedSuccess && lastDisbursedSummary ? (
                /* Success Voucher Receipt Panel */
                <div className="bg-emerald-50/40 border border-emerald-200 rounded-2xl p-6 space-y-5 animate-in zoom-in-95 duration-200">
                  <div className="flex justify-between items-start border-b border-emerald-200/60 pb-4">
                    <div className="flex gap-3">
                      <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center font-extrabold text-lg">
                        ✓
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-800 text-sm">ঋণ বিতরণ সফলভাবে সম্পন্ন হয়েছে!</h4>
                        <p className="text-xs text-slate-500 font-mono mt-0.5">রসিদ নম্বর: TXN-{lastDisbursedSummary.txnId}</p>
                      </div>
                    </div>
                    <span className="bg-emerald-100 text-emerald-800 text-[10px] px-2.5 py-1 rounded-full font-bold">
                      বিতরণকৃত (Disbursed)
                    </span>
                  </div>

                  <div className="grid gap-5 md:grid-cols-2">
                    <div className="space-y-3 bg-white p-4 rounded-xl border border-emerald-100">
                      <h5 className="text-[11px] font-bold text-emerald-900 border-b border-emerald-50 pb-2">গ্রাহক ও শাখা বিবরণী</h5>
                      <div className="space-y-1.5 text-xs text-slate-600">
                        <p className="flex justify-between"><span className="text-slate-400">সদস্যের নাম:</span> <strong className="text-slate-800">{lastDisbursedSummary.memberName}</strong></p>
                        <p className="flex justify-between"><span className="text-slate-400">সদস্যের লিঙ্গ (Gender):</span> <strong className="text-slate-800">{lastDisbursedSummary.memberGender === 'female' ? 'মহিলা (Female)' : 'পুরুষ (Male)'}</strong></p>
                        <p className="flex justify-between"><span className="text-slate-400">মোবাইল নম্বর:</span> <strong className="font-mono text-slate-800">{lastDisbursedSummary.memberPhone}</strong></p>
                        <p className="flex justify-between"><span className="text-slate-400">বিতরণকারী শাখা:</span> <strong className="text-slate-800">{lastDisbursedSummary.branchName}</strong></p>
                        <p className="flex justify-between"><span className="text-slate-400">বিতরণের তারিখ:</span> <strong className="font-mono text-slate-800">{workingDay}</strong></p>
                      </div>
                    </div>

                    <div className="space-y-3 bg-white p-4 rounded-xl border border-emerald-100">
                      <h5 className="text-[11px] font-bold text-emerald-900 border-b border-emerald-50 pb-2">অর্থ ও কিস্তি বিবরণী</h5>
                      <div className="space-y-1.5 text-xs text-slate-600">
                        <p className="flex justify-between"><span className="text-slate-400">ঋণের আসল (Principal):</span> <strong className="text-slate-800 font-mono">৳{parseFloat(lastDisbursedSummary.principal).toLocaleString('bn-BD')}</strong></p>
                        <p className="flex justify-between"><span className="text-slate-400">মোট ধার্যকৃত সুদ ({lastDisbursedSummary.interestRate}%):</span> <strong className="text-slate-800 font-mono">৳{parseFloat(lastDisbursedSummary.interestAmount).toLocaleString('bn-BD')}</strong></p>
                        <p className="flex justify-between border-t border-slate-100 pt-1.5 font-bold text-slate-800"><span className="text-slate-500">মোট প্রদেয় (Payable):</span> <span className="font-mono text-blue-700">৳{parseFloat(lastDisbursedSummary.totalPayable).toLocaleString('bn-BD')}</span></p>
                        <p className="flex justify-between"><span className="text-slate-400">কিস্তির ধরন ও মেয়াদ:</span> <strong className="text-indigo-700">{lastDisbursedSummary.intervalLabel} ({lastDisbursedSummary.tenureLabel})</strong></p>
                        <p className="flex justify-between"><span className="text-slate-400">মোট কিস্তি সংখ্যা:</span> <strong className="font-mono text-slate-800">{lastDisbursedSummary.installmentCount} টি</strong></p>
                        <p className="flex justify-between text-amber-900 bg-amber-50 p-1.5 rounded font-bold"><span className="text-[11px]">প্রতি কিস্তির পরিমাণ (EMI):</span> <span className="font-mono">৳{parseFloat(lastDisbursedSummary.installmentAmount).toLocaleString('bn-BD')}</span></p>
                      </div>
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="bg-amber-50/50 p-4 rounded-xl border border-amber-100 text-xs space-y-2">
                      <h5 className="text-[11px] font-bold text-amber-900 flex items-center gap-1">
                        <span className="inline-block w-1.5 h-1.5 bg-amber-600 rounded-full"></span>
                        ঋণবীমা তথ্য ও নির্বাচিত পলিসি
                      </h5>
                      <div className="space-y-1.5 text-slate-600">
                        <p className="flex justify-between"><span className="text-slate-500">বীমা পদ্ধতি:</span> <strong>{lastDisbursedSummary.insuranceType}</strong></p>
                        <p className="flex justify-between"><span className="text-slate-500">নির্বাচিত পলিসি ও প্রিমিয়াম:</span> <strong className="text-amber-900">{lastDisbursedSummary.insuranceLabel}</strong></p>
                        <p className="flex justify-between font-bold border-t border-amber-200/60 pt-1"><span className="text-slate-500">প্রিমিয়াম আদায় (নগদ):</span> <span className="text-amber-950 font-mono">৳{parseFloat(lastDisbursedSummary.insurancePremium).toLocaleString('bn-BD')}</span></p>
                      </div>
                    </div>

                    <div className="bg-blue-50/50 p-4 rounded-xl border border-blue-100 text-xs space-y-2">
                      <h5 className="text-[11px] font-bold text-blue-900 flex items-center gap-1">
                        <span className="inline-block w-1.5 h-1.5 bg-blue-600 rounded-full"></span>
                        বাধ্যতামূলক সঞ্চয় বিবরণ
                      </h5>
                      <div className="space-y-1.5 text-slate-600">
                        <p className="flex justify-between"><span className="text-slate-500">বাধ্যতামূলক সঞ্চয় শতকরা হার:</span> <strong className="font-mono">{mandatorySavingsPercent}%</strong></p>
                        <p className="flex justify-between font-bold border-t border-blue-200/60 pt-1"><span className="text-slate-500">প্রয়োজনীয় ন্যূনতম সঞ্চয় স্থিতি:</span> <span className="text-blue-950 font-mono">৳{parseFloat(lastDisbursedSummary.mandatorySavings).toLocaleString('bn-BD')}</span></p>
                      </div>
                    </div>
                  </div>

                  {/* Generated Installments list for success audit */}
                  <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
                    <div className="bg-slate-50 px-4 py-2.5 border-b border-slate-200 flex justify-between items-center">
                      <h5 className="font-bold text-slate-700 text-xs">স্বয়ংক্রিয় কিস্তি পরিশোধের সময়সূচী ও আদায় রোডম্যাপ</h5>
                      <span className="text-[10px] text-slate-400 font-mono">প্রথম আদায় আরম্ভ হবে ১ সপ্তাহ/মাস গ্রেস পিরিয়ড পর</span>
                    </div>
                    <div className="max-h-72 overflow-y-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="bg-slate-100 border-b border-slate-200 text-slate-500 text-[10px] font-bold uppercase">
                            <th className="py-2 px-3">কিস্তি নং</th>
                            <th className="py-2 px-3">ঋণ পরিশোধের সম্ভব্য তারিখ</th>
                            <th className="py-2 px-3 text-right">আসল পরিশোধ</th>
                            <th className="py-2 px-3 text-right">সুদ পরিশোধ</th>
                            <th className="py-2 px-3 text-right">কিস্তির পরিমাণ</th>
                            <th className="py-2 px-3 text-right">অবশিষ্ট আসল</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-slate-600 text-xs">
                          {Array.from({ length: lastDisbursedSummary.installmentCount }).map((_, idx) => {
                            const instNo = idx + 1;
                            const instAmt = Math.round(lastDisbursedSummary.installmentAmount);
                            const totalPrin = parseFloat(lastDisbursedSummary.principal);
                            const totalInterest = parseFloat(lastDisbursedSummary.interestAmount);
                            const instCount = lastDisbursedSummary.installmentCount;
                            
                            const principalPerInst = Math.round(totalPrin / instCount);
                            const interestPerInst = instAmt - principalPerInst;
                            const balance = Math.max(0, totalPrin - (principalPerInst * instNo));

                            // Generate date
                            const tDate = new Date(workingDay);
                            const intervalDays = lastDisbursedSummary.intervalType === 'weekly' ? 7 : lastDisbursedSummary.intervalType === 'monthly' ? 30 : lastDisbursedSummary.intervalType === 'term' ? (lastDisbursedSummary.tenureLabel.includes('৩') ? 30 : 30) : 30;
                            tDate.setDate(tDate.getDate() + ((idx + 2) * intervalDays)); // include grace period
                            const dateStr = tDate.toISOString().split('T')[0];

                            return (
                              <tr key={idx} className="hover:bg-slate-50/60 font-medium">
                                <td className="py-2 px-3 text-slate-400 font-mono">#{String(instNo).padStart(2, '0')}</td>
                                <td className="py-2 px-3 font-mono">{dateStr}</td>
                                <td className="py-2 px-3 text-right font-mono text-slate-600">৳{principalPerInst}</td>
                                <td className="py-2 px-3 text-right font-mono text-amber-700">৳{interestPerInst}</td>
                                <td className="py-2 px-3 text-right font-mono text-slate-900 font-bold bg-amber-50/20">৳{instAmt}</td>
                                <td className="py-2 px-3 text-right font-mono text-slate-400">৳{balance}</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div className="flex gap-3 justify-end pt-2">
                    <button 
                      onClick={() => window.print()}
                      className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold rounded-lg transition-colors cursor-pointer"
                    >
                      রসিদ ও সূচী প্রিন্ট করুন
                    </button>
                    <button 
                      onClick={() => {
                        setIsDisbursedSuccess(false);
                        setLastDisbursedSummary(null);
                      }}
                      className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition-colors cursor-pointer"
                    >
                      আরেকটি ঋণ বিতরণ করুন
                    </button>
                  </div>
                </div>
              ) : (
                /* Primary Interactive Disbursement & Dynamic Calculator Sandbox Form */
                <div className="grid gap-6 md:grid-cols-12 items-start">
                  
                  {/* INPUT CONFIGURATOR - col-span-7 */}
                  <div className="md:col-span-7 space-y-4">
                    <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                      
                      <div className="flex items-center gap-2 border-b border-slate-100 pb-2.5">
                        <Users size={16} className="text-blue-600" />
                        <h4 className="font-bold text-slate-800 text-xs sm:text-sm">১. সদস্য ও সাধারণ তথ্য এন্ট্রি</h4>
                      </div>

                      <div className="grid gap-4 sm:grid-cols-2">
                        <div>
                          <label className="block text-xs font-bold text-slate-600 mb-1">সদস্যের নাম *</label>
                          <input 
                            type="text" 
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-semibold focus:ring-1 focus:ring-blue-500 focus:outline-none"
                            value={dispMemberName} 
                            onChange={(e) => setDispMemberName(e.target.value)}
                            placeholder="সদস্যের পূর্ণ নাম দিন"
                            required
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-slate-600 mb-1">সদস্যের লিঙ্গ (Gender) *</label>
                          <div className="flex gap-4 items-center h-9">
                            <label className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-700 cursor-pointer">
                              <input 
                                type="radio" 
                                name="memberGender" 
                                value="female"
                                checked={dispMemberGender === 'female'}
                                onChange={() => {
                                  setDispMemberGender('female');
                                  setDispInsuranceType('যৌথ বীমা');
                                }}
                                className="w-4 h-4 text-blue-600 focus:ring-0 cursor-pointer"
                              />
                              মহিলা (যৌথ বীমা ডিফল্ট)
                            </label>
                            <label className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-700 cursor-pointer">
                              <input 
                                type="radio" 
                                name="memberGender" 
                                value="male"
                                checked={dispMemberGender === 'male'}
                                onChange={() => {
                                  setDispMemberGender('male');
                                  setDispInsuranceType('একক বীমা');
                                }}
                                className="w-4 h-4 text-blue-600 focus:ring-0 cursor-pointer"
                              />
                              পুরুষ (একক বীমা ডিফল্ট)
                            </label>
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-slate-600 mb-1">মোবাইল ফোন নম্বর *</label>
                          <input 
                            type="tel" 
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-bold font-mono focus:ring-1 focus:ring-blue-500 focus:outline-none"
                            value={dispMemberPhone} 
                            onChange={(e) => setDispMemberPhone(e.target.value)}
                            placeholder="01XXXXXXXXX"
                            required
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-slate-600 mb-1">বিতরণকারী শাখা (Branch)</label>
                          <select 
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs bg-white font-semibold focus:ring-1 focus:ring-blue-500 focus:outline-none"
                            value={dispBranchId}
                            onChange={(e) => setDispBranchId(e.target.value)}
                          >
                            <option value="">প্রধান কার্যালয়</option>
                            {branchesList.map(b => (
                              <option key={b.id} value={b.id}>{b.name}</option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-slate-600 mb-1">সুদের বার্ষিক হার (%) *</label>
                          <div className="relative">
                            <span className="absolute right-3 top-1.5 text-xs text-slate-400 font-bold font-mono">%</span>
                            <input 
                              type="number" 
                              className="w-full pl-3 pr-8 py-1.5 border border-slate-200 rounded-lg text-xs font-bold font-mono focus:ring-1 focus:ring-blue-500 focus:outline-none"
                              value={dispInterestRate}
                              onChange={(e) => setDispInterestRate(e.target.value)}
                              required
                            />
                          </div>
                        </div>
                      </div>

                    </div>

                    <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                      
                      <div className="flex items-center gap-2 border-b border-slate-100 pb-2.5">
                        <Sliders size={16} className="text-blue-600" />
                        <h4 className="font-bold text-slate-800 text-xs sm:text-sm">২. কিস্তি প্রকারভেদ ও মেয়াদ সেটিংস</h4>
                      </div>

                      <div className="space-y-4">
                        
                        {/* Installment types selection based on organization capability */}
                        <div>
                          <label className="block text-xs font-bold text-slate-600 mb-1.5">কিস্তির প্রকারভেদ নির্বাচন করুন</label>
                          <div className="grid grid-cols-3 gap-2.5">
                            {instWeeklyActive && (
                              <label className={`flex flex-col items-center justify-center p-3 border-2 rounded-xl cursor-pointer transition text-center space-y-1 ${
                                dispIntervalType === 'weekly' 
                                  ? 'border-blue-600 bg-blue-50/50 text-blue-700' 
                                  : 'border-slate-200 hover:border-slate-350 bg-slate-50 text-slate-600'
                              }`}>
                                <input 
                                  type="radio" 
                                  name="intervalType" 
                                  className="sr-only" 
                                  checked={dispIntervalType === 'weekly'} 
                                  onChange={() => {
                                    setDispIntervalType('weekly');
                                    setDispTenure('1.0');
                                  }} 
                                />
                                <span className="font-bold text-xs">সাপ্তাহিক কিস্তি</span>
                                <span className="text-[9px] text-slate-400">১ বছর থেকে ২ বছর মেয়াদ</span>
                              </label>
                            )}

                            {instMonthlyActive && (
                              <label className={`flex flex-col items-center justify-center p-3 border-2 rounded-xl cursor-pointer transition text-center space-y-1 ${
                                dispIntervalType === 'monthly' 
                                  ? 'border-blue-600 bg-blue-50/50 text-blue-700' 
                                  : 'border-slate-200 hover:border-slate-350 bg-slate-50 text-slate-600'
                              }`}>
                                <input 
                                  type="radio" 
                                  name="intervalType" 
                                  className="sr-only" 
                                  checked={dispIntervalType === 'monthly'} 
                                  onChange={() => {
                                    setDispIntervalType('monthly');
                                    setDispTenure('1.0');
                                  }} 
                                />
                                <span className="font-bold text-xs">মাসিক কিস্তি</span>
                                <span className="text-[9px] text-slate-400">১ বছর থেকে ২ বছর মেয়াদ</span>
                              </label>
                            )}

                            {instTermActive && (
                              <label className={`flex flex-col items-center justify-center p-3 border-2 rounded-xl cursor-pointer transition text-center space-y-1 ${
                                dispIntervalType === 'term' 
                                  ? 'border-blue-600 bg-blue-50/50 text-blue-700' 
                                  : 'border-slate-200 hover:border-slate-350 bg-slate-50 text-slate-600'
                              }`}>
                                <input 
                                  type="radio" 
                                  name="intervalType" 
                                  className="sr-only" 
                                  checked={dispIntervalType === 'term'} 
                                  onChange={() => {
                                    setDispIntervalType('term');
                                  }} 
                                />
                                <span className="font-bold text-xs text-indigo-700">মেয়াদি কিস্তি</span>
                                <span className="text-[9px] text-slate-400">৩ মাস থেকে ৬ মাস মেয়াদ</span>
                              </label>
                            )}

                            {!instWeeklyActive && !instMonthlyActive && !instTermActive && (
                              <div className="col-span-3 text-center p-4 bg-amber-50 rounded-xl border border-dashed border-amber-200 text-xs text-amber-800">
                                * কনফিগারেশন প্যানেল থেকে অন্তত যেকোনো একটি কিস্তির প্রকারভেদ (সাপ্তাহিক, মাসিক বা মেয়াদি কিস্তি) অনুমোদন করুন।
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Tenure and automatic installment count calculation */}
                        <div className="grid gap-4 sm:grid-cols-2">
                          {/* 1. If Weekly or Monthly (১ বছর / ১২ মাস, ১.৫ বছর বা ১৮ মাস, ২ বছর বা ২৪ মাস) */}
                          {(dispIntervalType === 'weekly' || dispIntervalType === 'monthly') && (
                            <div>
                              <label className="block text-xs font-bold text-slate-600 mb-1">ঋণের মেয়াদ / কিস্তির সময়সীমা</label>
                              <select 
                                className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs bg-white font-semibold focus:ring-1 focus:ring-blue-500 focus:outline-none"
                                value={dispTenure}
                                onChange={(e) => setDispTenure(e.target.value)}
                              >
                                <option value="1.0">১ বছর বা ১২ মাস</option>
                                <option value="1.5">১.৫ বছর বা ১৮ মাস</option>
                                <option value="2.0">২ বছর বা ২৪ মাস</option>
                              </select>
                            </div>
                          )}

                          {/* 2. If Term (৩ মাস, ৬ মাস) */}
                          {dispIntervalType === 'term' && (
                            <div>
                              <label className="block text-xs font-bold text-slate-600 mb-1">ঋণের মেয়াদ (মেয়াদি কিস্তিতে)</label>
                              <select 
                                className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs bg-white font-semibold focus:ring-1 focus:ring-blue-500 focus:outline-none"
                                value={dispTermTenure}
                                onChange={(e) => setDispTermTenure(e.target.value)}
                              >
                                <option value="3_months">৩ মাস</option>
                                <option value="6_months">৬ মাস</option>
                              </select>
                            </div>
                          )}

                          {/* Dynamic Automated Installment Count box */}
                          <div>
                            <label className="block text-xs font-bold text-slate-600 mb-1">মোট কিস্তির সংখ্যা (স্বয়ংক্রিয় হিসাব)</label>
                            <input 
                              type="text" 
                              className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-bold font-mono bg-slate-50 text-blue-800 cursor-not-allowed border-dashed"
                              readOnly
                              disabled
                              value={
                                dispIntervalType === 'weekly' 
                                  ? (dispTenure === '1.0' ? '৫২ টি কিস্তি (১ বছর)' : dispTenure === '1.5' ? '৭৮ টি কিস্তি (১.৫ বছর)' : '১০৪ টি কিস্তি (২ বছর)')
                                  : dispIntervalType === 'monthly'
                                    ? (dispTenure === '1.0' ? '১২ টি কিস্তি (১ বছর)' : dispTenure === '1.5' ? '১৮ টি কিস্তি (১.৫ বছর)' : '২৪ টি কিস্তি (২ বছর)')
                                    : (dispTermTenure === '3_months' ? '৩ টি কিস্তি (৩ মাস)' : '৬ টি কিস্তি (৬ মাস)')
                              }
                            />
                          </div>
                        </div>

                      </div>

                    </div>

                    {/* INSURANCE POLICY SELECTOR */}
                    <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                      
                      <div className="flex items-center gap-2 border-b border-slate-100 pb-2.5">
                        <Shield size={16} className="text-amber-600" />
                        <h4 className="font-bold text-slate-800 text-xs sm:text-sm text-slate-850">
                          ৩. ঋণবীমা তহবিল পলিসি নির্বাচন
                        </h4>
                      </div>

                      {/* Interactive toggle for Insurance type right here! */}
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 mb-1.5 uppercase">মনোনীত বীমা পলিসি পদ্ধতি</label>
                        <div className="grid grid-cols-2 gap-2">
                          <button
                            type="button"
                            onClick={() => setDispInsuranceType('যৌথ বীমা')}
                            className={`py-2 px-3 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                              dispInsuranceType === 'যৌথ বীমা'
                                ? 'bg-amber-600 text-white border-amber-600 shadow-sm'
                                : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                            }`}
                          >
                            যৌথ বীমা ({loanInsurancePercent}%)
                          </button>
                          <button
                            type="button"
                            onClick={() => setDispInsuranceType('একক বীমা')}
                            className={`py-2 px-3 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                              dispInsuranceType === 'একক বীমা'
                                ? 'bg-amber-600 text-white border-amber-600 shadow-sm'
                                : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                            }`}
                          >
                            একক বীমা (০.৫% প্রিমিয়াম)
                          </button>
                        </div>
                      </div>

                      {dispInsuranceType === 'একক বীমা' ? (
                        <div className="space-y-3 bg-amber-50/20 p-4 rounded-xl border border-amber-100">
                          <p className="text-xs text-amber-900 leading-relaxed font-semibold">
                            ⚠️ বর্তমানে <strong>"একক বীমা"</strong> পদ্ধতি নির্বাচিত বা সচল রয়েছে। একক বীমার জন্য আলাদা বীমা পলিসি ড্রপডাউন দেওয়া হলো। পছন্দনীয় একটি পলিসি নির্বাচন করুন:
                          </p>
                          
                          <div>
                            <label className="block text-xs font-bold text-amber-950 mb-1">আলাদা একক বীমা পলিসি সমূহ *</label>
                            <select 
                              className="w-full px-3 py-1.5 border-2 border-amber-200 rounded-lg text-xs bg-white font-extrabold focus:ring-1 focus:ring-amber-500 focus:outline-none"
                              value={dispInsPolicy}
                              onChange={(e) => setDispInsPolicy(e.target.value)}
                            >
                              <option value="policy_a">বীমা পলিসি ক - ০.৫% প্রিমিয়াম (Standard Single)</option>
                              <option value="policy_b">বীমা পলিসি খ - ১.০% প্রিমিয়াম (Silver Premium Single)</option>
                              <option value="policy_c">বীমা পলিসি গ - ১.৫% প্রিমিয়াম (Gold Deluxe Single)</option>
                              <option value="policy_d">বীমা পলিসি ঘ - ২.০% প্রিমিয়াম (Gold Deluxe Double Single)</option>
                            </select>
                            <span className="text-[10px] text-amber-800 block mt-1.5">
                              * ঋন বিতরণের সময় গ্রাহকের সুবিধার্থে আলাদা পলিসি বাছাই করতে পারবেন। নির্বাচিত প্রিমিয়াম আসলের ওপর প্রযোজ্য হবে।
                            </span>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-3 bg-blue-50/20 p-4 rounded-xl border border-blue-100">
                          <p className="text-xs text-slate-600 leading-relaxed">
                            ✓ বর্তমানে <strong>"যৌথ বীমা"</strong> পদ্ধতি নির্বাচিত বা সচল রয়েছে।
                          </p>
                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <span className="block text-[10px] text-slate-400">বীমার ধরণ:</span>
                              <strong className="text-xs text-slate-800">যৌথ ঋণবীমা</strong>
                            </div>
                            <div>
                              <span className="block text-[10px] text-slate-400">নির্ধারিত প্রিমিয়াম রেট:</span>
                              <strong className="text-xs font-mono text-blue-700 bg-blue-50 px-2 py-0.5 rounded">{loanInsurancePercent}% (আসলের)</strong>
                            </div>
                          </div>
                          <span className="text-[9px] text-slate-400 block border-t border-slate-100/50 pt-1.5">
                            * যৌথ বীমার প্রিমিয়াম শতকরা হার কনফিগারেশন প্যানেলে ৩ নম্বর বিভাগে পরিবর্তনযোগ্য।
                          </span>
                        </div>
                      )}

                    </div>

                  </div>

                  {/* DYNAMIC CALCULATION OUTPUT - col-span-5 */}
                  <div className="md:col-span-5 space-y-4">
                    
                    <div className="bg-slate-900 text-slate-200 p-5 rounded-3xl border border-slate-850 shadow-lg space-y-5">
                      
                      <div className="border-b border-slate-800 pb-3">
                        <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest block mb-0.5">রিয়াল-টাইম হিসাব এস্টিমেট</span>
                        <h4 className="text-base font-extrabold text-white flex items-center gap-1.5">
                          ৳ ঋণ আসলের পরিমাণ (Principal)
                        </h4>
                        
                        <div className="relative mt-2">
                          <span className="absolute left-3 top-2.5 text-lg font-bold text-slate-400 font-mono">৳</span>
                          <input 
                            type="number" 
                            className="w-full pl-8 pr-3 py-2 bg-slate-800/80 border border-slate-700 text-white rounded-xl text-lg font-extrabold focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono"
                            value={dispAmount}
                            onChange={(e) => setDispAmount(e.target.value)}
                            min="1000"
                            placeholder="যেমন: ২০০০০"
                            required
                          />
                        </div>
                        <span className="text-[9px] text-slate-400 mt-1.5 block">
                          সীমা: ৳{parseFloat(loanMinAmount).toLocaleString('bn-BD')} থেকে ৳{parseFloat(loanMaxAmount).toLocaleString('bn-BD')}
                        </span>
                      </div>

                      {/* Display calculations list */}
                      {(() => {
                        const amount = Math.abs(parseFloat(dispAmount || '0'));
                        const interestRate = parseFloat(dispInterestRate || '12');
                        
                        // Calculate proportional interest factor
                        let yearsFactor = 1.0;
                        let count = 52;
                        let intervalLabel = 'সাপ্তাহিক';
                        let tenureLabel = '১ বছর';

                        if (dispIntervalType === 'weekly') {
                          intervalLabel = 'সাপ্তাহিক';
                          if (dispTenure === '1.0') {
                            yearsFactor = 1.0;
                            count = 45;
                            tenureLabel = '১ বছর';
                          } else if (dispTenure === '1.5') {
                            yearsFactor = 1.5;
                            count = 68;
                            tenureLabel = '১.৫ বছর';
                          } else {
                            yearsFactor = 2.0;
                            count = 90;
                            tenureLabel = '২ বছর';
                          }
                        } else if (dispIntervalType === 'monthly') {
                          intervalLabel = 'মাসিক';
                          if (dispTenure === '1.0') {
                            yearsFactor = 1.0;
                            count = 12;
                            tenureLabel = '১ বছর বা ১২ মাস';
                          } else if (dispTenure === '1.5') {
                            yearsFactor = 1.5;
                            count = 18;
                            tenureLabel = '১.৫ বছর বা ১৮ মাস';
                          } else {
                            yearsFactor = 2.0;
                            count = 24;
                            tenureLabel = '২ বছর বা ২৪ মাস';
                          }
                        } else if (dispIntervalType === 'term') {
                          intervalLabel = 'মেয়াদি কিস্তি';
                          if (dispTermTenure === '3_months') {
                            yearsFactor = 3 / 12;
                            count = 3;
                            tenureLabel = '৩ মাস মেয়াদ';
                          } else {
                            yearsFactor = 6 / 12;
                            count = 6;
                            tenureLabel = '৬ মাস মেয়াদ';
                          }
                        }

                        const intAmount = amount * (interestRate / 100) * yearsFactor;
                        const totalPayable = amount + intAmount;
                        
                        let roundedEMI = 0;
                        if (dispIntervalType === 'term') {
                            roundedEMI = intAmount / count; // Only service charge
                        } else {
                            const originalEMI = count > 0 ? totalPayable / count : 0;
                            
                            // Rounding rules based on org settings
                            if (instRoundingRule === 'Nearest 10') {
                              roundedEMI = Math.round(originalEMI / 10) * 10;
                            } else if (instRoundingRule === 'Always Up') {
                              roundedEMI = Math.ceil(originalEMI);
                            } else {
                              roundedEMI = Math.round(originalEMI);
                            }
                        }

                        // Insurance Calculation based on User input & Gender defaults (Single = 0.5%, Joint = 10%)
                        let insRate = 10.0;
                        let insLabel = "";
                        if (dispInsuranceType === 'যৌথ বীমা') {
                          const cleanPercent = (loanInsurancePercent || '১০').replace(/[০-৯]/g, d => '০১২৩৪৫৬৭৮৯'.indexOf(d).toString());
                          const parsedRate = parseFloat(cleanPercent);
                          insRate = isNaN(parsedRate) || parsedRate <= 0 ? 10.0 : parsedRate;
                          insLabel = `যৌথ বীমা (${insRate}% প্রিমিয়াম)`;
                        } else {
                          insRate = 0.5;
                          insLabel = `একক বীমা (${insRate}% প্রিমিয়াম)`;
                        }
                        const insPremium = amount * (insRate / 100);

                        // Mandatory Savings
                        const mandatorySavRate = parseFloat(mandatorySavingsPercent || '5');
                        const mandatorySavAmt = amount * (mandatorySavRate / 100);

                        const handleTriggerDisbursement = () => {
                          if (amount <= 0 || isNaN(amount)) {
                            alert('দয়া করে সঠিক ঋণের আসল পরিমাণ প্রদান করুন।');
                            return;
                          }
                          if (amount < parseFloat(loanMinAmount) || amount > parseFloat(loanMaxAmount)) {
                            alert(`ঋণের আসল অবশ্যই সর্বনিম্ন ৳${parseFloat(loanMinAmount).toLocaleString('bn-BD')} এবং সর্বোচ্চ ৳${parseFloat(loanMaxAmount).toLocaleString('bn-BD')} এর মধ্যে হতে হবে।`);
                            return;
                          }

                          const txnId = Math.floor(100000 + Math.random() * 900000);
                          const chosenBranch = branchesList.find(b => b.id === dispBranchId);
                          const disSummaryObj = {
                            txnId,
                            memberName: dispMemberName,
                            memberPhone: dispMemberPhone,
                            memberGender: dispMemberGender,
                            branchName: chosenBranch ? chosenBranch.name : 'প্রধান কার্যালয় / সাধারণ',
                            principal: amount,
                            interestRate,
                            interestAmount: intAmount,
                            totalPayable,
                            installmentCount: count,
                            installmentAmount: roundedEMI,
                            intervalType: dispIntervalType,
                            intervalLabel,
                            tenureLabel,
                            insurancePremium: insPremium,
                            insuranceLabel: insLabel,
                            insuranceType: dispInsuranceType,
                            mandatorySavings: mandatorySavAmt
                          };

                          setLastDisbursedSummary(disSummaryObj);
                          setIsDisbursedSuccess(true);
                        };

                        return (
                          <div className="space-y-4">
                            
                            <div className="space-y-2 bg-slate-800/40 p-4 rounded-2xl border border-slate-800/60 text-xs text-slate-300">
                              <div className="flex justify-between items-center pb-2 border-b border-slate-800/60 font-medium">
                                <span>কিস্তি প্রকারভেদ ও মেয়াদ:</span>
                                <strong className="text-blue-400 font-semibold">{intervalLabel} ({tenureLabel})</strong>
                              </div>

                              <div className="flex justify-between items-center py-1">
                                <span>মোট হিসাবকৃত সুদ ({interestRate}%):</span>
                                <strong className="font-mono text-white">৳{Math.round(intAmount).toLocaleString('bn-BD')}</strong>
                              </div>

                              <div className="flex justify-between items-center py-1">
                                <span>মোট প্রদেয় ঋণ (সুদসহ):</span>
                                <strong className="font-mono text-white">৳{Math.round(totalPayable).toLocaleString('bn-BD')}</strong>
                              </div>

                              <div className="flex justify-between items-center py-1">
                                <span>কিস্তির সংখ্যা:</span>
                                <strong className="font-mono text-white">{count} টি কিস্তি</strong>
                              </div>

                              <div className="flex justify-between items-center py-1.5 border-t border-slate-850 text-slate-400">
                                <span>বীমা প্রিমিয়াম পরিশোধ ({insRate}%):</span>
                                <strong className="font-mono text-amber-400">৳{Math.round(insPremium).toLocaleString('bn-BD')}</strong>
                              </div>

                              <div className="flex justify-between items-center py-1 text-slate-400">
                                <span>বাধ্যতামূলক সঞ্চয় ({mandatorySavRate}%):</span>
                                <strong className="font-mono text-indigo-400">৳{Math.round(mandatorySavAmt).toLocaleString('bn-BD')}</strong>
                              </div>
                            </div>

                            {/* EMI Card Banner */}
                            <div className="bg-amber-500 text-slate-950 p-4 rounded-2xl border border-amber-400 text-center space-y-1">
                              <span className="text-[10px] uppercase font-extrabold tracking-wider opacity-80 block">আদায়যোগ্য প্রতি কিস্তির পরিমাণ</span>
                              <div className="text-2xl font-black font-mono tracking-tight leading-none">
                                ৳{Math.round(roundedEMI).toLocaleString('bn-BD')}
                              </div>
                              <span className="text-[9px] font-bold block opacity-75">
                                (* রাউন্ডিং নিয়ম: {instRoundingRule} অনুযায়ী হিসাবকৃত)
                              </span>
                            </div>

                            {/* Action Button */}
                            <button 
                              type="button"
                              onClick={handleTriggerDisbursement}
                              className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs rounded-xl transition shadow-lg shadow-blue-500/20 active:scale-95 cursor-pointer flex items-center justify-center gap-2 uppercase tracking-wider"
                            >
                              <Check size={16} />
                              <span>ঋণ বিতরণ নিশ্চিত করুন (Disburse Loan)</span>
                            </button>

                          </div>
                        );
                      })()}

                    </div>

                  </div>

                </div>
                  )}
                </div>
              ) : (
                /* RENDER ADVANCED PRINTABLE REPORTS */
                <ReportViews
                  selectedReportType={selectedReportType}
                  branchesList={branchesList}
                  staffList={staffList}
                  holidaysList={holidaysList}
                  workingDay={workingDay}
                  orgName={orgName}
                  orgAddress={orgAddress}
                  orgTradeLicense={orgTradeLicense}
                  orgPhone={orgPhone}
                  orgEmail={orgEmail}
                  savingsAdmissionFee={savingsAdmissionFee}
                  savingsWelfareFee={savingsWelfareFee}
                  savingsMinBalance={savingsMinBalance}
                  savProfitGS={savProfitGS}
                  savProfitCBS={savProfitCBS}
                  savProfitLTS={savProfitLTS}
                  savProfitFDR={savProfitFDR}
                  savFdrPayoutType={savFdrPayoutType}
                  loanDefaultInterest={loanDefaultInterest}
                  loanInterestType={loanInterestType}
                  loanMinAmount={loanMinAmount}
                  loanMaxAmount={loanMaxAmount}
                  loanDuration={loanDuration}
                  loanGracePeriod={loanGracePeriod}
                  loanLateFee={loanLateFee}
                  loanProcessingFee={loanProcessingFee}
                  loanInsurancePercent={loanInsurancePercent}
                  loanInsuranceType={loanInsuranceType}
                  mandatorySavingsPercent={mandatorySavingsPercent}
                  instRoundingRule={instRoundingRule}
                />
              )}

            </div>
          )}

          {/* VIEW 5: Holiday Update / holiday_update_panel_placeholder */}
          {activeTab === 'holidays' && (
            <div className="space-y-6 animate-in fade-in duration-100">
              
              {/* Top Bar inside View */}
              <div className="flex justify-between items-center flex-wrap gap-4 border-b border-slate-100 pb-4">
                <div>
                  <h2 className="text-lg font-extrabold text-slate-800 tracking-tight flex items-center gap-2">
                    <Calendar size={20} className="text-blue-600" />
                    বছরের ছুটি হালনাগাদ ও ঘোষণা প্যানেল
                  </h2>
                  <p className="text-[11px] text-slate-500 font-semibold font-sans">
                    সংগঠনের আওতায় সরাসরি বিশেষ সরকারি ছুটি এবং নিয়মিত/সাধারণ ছুটির দিনসমূহ এক নজরে তদারকি করুন।
                  </p>
                </div>
                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => {
                      setEditingHolidayId(null);
                      setHolidayType('direct');
                      setHolidayName('');
                      setHolidayDate(workingDay || new Date().toISOString().split('T')[0]);
                      setHolidayDayOfWeek('শুক্রবার');
                      setIsHolidayModalOpen(true);
                    }}
                    className="px-4.5 py-2.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-extrabold text-xs rounded-xl flex items-center gap-1.5 transition duration-150 shadow-xs cursor-pointer text-center"
                  >
                    <Plus size={15} />
                    <span>নতুন ছুটি ঘোষণা</span>
                  </button>
                </div>
              </div>

              {/* Informative Guidance Callout about Pre-defined Government Holidays */}
              <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-4 flex gap-3 text-xs text-amber-900 leading-relaxed max-w-4xl">
                <Info size={18} className="text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-extrabold text-amber-950 mb-1">ক্যালেন্ডারে সরকারি ছুটির নির্দেশিকা ও পরামর্শ:</h4>
                  <p className="mb-1">
                    ১. <strong>স্বয়ংক্রিয় সরকারি ছুটিসমূহ:</strong> এই সিস্টেমে ২০২৬, ২০২৭ এবং ২০২৮ সালের সমস্ত প্রধান প্রধান সরকারি ও জাতীয় ছুটিসমূহ (যেমন: শহিদ দিবস, স্বাধীনতা দিবস, পহেলা বৈশাখ, ঈদ-উল-ফিতর, ঈদ-উল-আজহা ইত্যাদি) ইতোমধ্যে <strong>প্রাক-ঘোষিত (Pre-configured)</strong> রয়েছে।
                  </p>
                  <p className="mb-1">
                    ২. <strong>চলতি মাসের অবস্থা:</strong> বর্তমান সিস্টেম কাজের তারিখ অনুযায়ী এখন <strong>জুন ২০২৬</strong> চলতেছে। জুন ২০২৬ মাসে সাপ্তাহিক ছুটি (শুক্রবার) ব্যতীত কোনো বিশেষ জাতীয় সরকারি ছুটির দিন নেই। তাই জুন মাসের ক্যালেন্ডারে কোনো বাড়তি লাল চিহ্নিত দিন দেখা যাচ্ছে না।
                  </p>
                  <p>
                    ৩. <strong>পরীক্ষা করুন:</strong> পূর্ববর্তী বা পরবর্তী মাস যেমন—<strong>ফেব্রুয়ারি ২০২৬, মার্চ ২০২৬ বা মে ২০২৬</strong>-এ নেভিগেট করে দেখুন, ক্যালেন্ডার স্বয়ংক্রিয়ভাবে উক্ত প্রধান প্রধান সরকারি ছুটির দিনগুলোকে লাল রঙে প্রদর্শন করছে।
                  </p>
                </div>
              </div>

              {/* Holiday Summary KPIs at a Glance */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-4 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                    <Calendar size={18} />
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 font-bold block">২০২৬ সালের ছুটি</p>
                    <h5 className="text-base font-black text-slate-800">{holidaysList.filter(h => h.type === 'direct' && h.date?.startsWith('2026')).length} টি</h5>
                  </div>
                </div>

                <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-4 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-violet-50 text-violet-600 flex items-center justify-center font-bold">
                    <Calendar size={18} />
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 font-bold block">২০২৭ সালের ছুটি</p>
                    <h5 className="text-base font-black text-slate-800">{holidaysList.filter(h => h.type === 'direct' && h.date?.startsWith('2027')).length} টি</h5>
                  </div>
                </div>

                <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-4 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-fuchsia-50 text-fuchsia-600 flex items-center justify-center font-bold">
                    <Calendar size={18} />
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 font-bold block">২০২৮ সালের ছুটি</p>
                    <h5 className="text-base font-black text-slate-800">{holidaysList.filter(h => h.type === 'direct' && h.date?.startsWith('2028')).length} টি</h5>
                  </div>
                </div>

                <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-4 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center font-bold">
                    <Clock size={18} />
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 font-bold block">সাপ্তাহিক নিয়মিত ছুটি</p>
                    <h5 className="text-base font-black text-slate-800">{holidaysList.filter(h => h.type === 'general').length} দিন</h5>
                  </div>
                </div>
              </div>

              {/* View Mode Toggle Switch */}
              <div className="flex gap-2 bg-slate-100 p-1.5 rounded-2xl w-fit border border-slate-200">
                <button
                  type="button"
                  onClick={() => setHolidayViewMode('calendar')}
                  className={`px-4 py-2 font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer transition ${
                    holidayViewMode === 'calendar'
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-800'
                  }`}
                >
                  <Calendar size={14} />
                  <span>📅 ছুটির ক্যালেন্ডার ভিউ</span>
                </button>
                <button
                  type="button"
                  onClick={() => setHolidayViewMode('list')}
                  className={`px-4 py-2 font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer transition ${
                    holidayViewMode === 'list'
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-800'
                  }`}
                >
                  <Search size={14} />
                  <span>📋 ছুটির তালিকা ও অনুসন্ধান</span>
                </button>
              </div>

              {holidayViewMode === 'calendar' ? (
                <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 animate-in fade-in duration-200">
                  {/* Left Section: Graphical Calendar Component */}
                  <div className="xl:col-span-2 bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 space-y-4">
                    
                    {/* Month Year Navigator & Quick Picks */}
                    <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-50 border border-slate-150 p-3 rounded-2xl">
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            if (currentCalendarMonth === 0) {
                              setCurrentCalendarMonth(11);
                              setCurrentCalendarYear(prev => Math.max(2026, prev - 1));
                            } else {
                              setCurrentCalendarMonth(prev => prev - 1);
                            }
                          }}
                          className="p-1.5 hover:bg-slate-200 active:scale-90 text-slate-700 rounded-lg transition duration-150 cursor-pointer"
                          title="পূর্ববর্তী মাস"
                        >
                          <ChevronLeft size={16} />
                        </button>
                        
                        <span className="font-extrabold text-sm text-slate-800 tracking-tight min-w-[140px] text-center font-sans">
                          {['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'][currentCalendarMonth]} - {replaceNumbersWithBN(currentCalendarYear)}
                        </span>

                        <button
                          type="button"
                          onClick={() => {
                            if (currentCalendarMonth === 11) {
                              setCurrentCalendarMonth(0);
                              setCurrentCalendarYear(prev => Math.min(2028, prev + 1));
                            } else {
                              setCurrentCalendarMonth(prev => prev + 1);
                            }
                          }}
                          className="p-1.5 hover:bg-slate-200 active:scale-90 text-slate-700 rounded-lg transition duration-150 cursor-pointer"
                          title="পরবর্তী মাস"
                        >
                          <ChevronRight size={16} />
                        </button>
                      </div>

                      {/* Dropdown Selectors */}
                      <div className="flex items-center gap-2">
                        <select
                          value={currentCalendarMonth}
                          onChange={(e) => setCurrentCalendarMonth(parseInt(e.target.value, 10))}
                          className="px-2.5 py-1.5 border border-slate-200 rounded-xl text-xs bg-white font-semibold text-slate-800 focus:outline-blue-600 cursor-pointer"
                        >
                          {['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'].map((name, idx) => (
                            <option key={idx} value={idx}>{name}</option>
                          ))}
                        </select>

                        <select
                          value={currentCalendarYear}
                          onChange={(e) => setCurrentCalendarYear(parseInt(e.target.value, 10))}
                          className="px-2.5 py-1.5 border border-slate-200 rounded-xl text-xs bg-white font-semibold text-slate-800 focus:outline-blue-600 cursor-pointer"
                        >
                          <option value={2026}>২০২৬ সাল</option>
                          <option value={2027}>২০২৭ সাল</option>
                          <option value={2028}>২০২৮ সাল</option>
                        </select>
                      </div>
                    </div>

                    {/* Weekday Labels Grid */}
                    <div className="grid grid-cols-7 gap-2 text-center text-[11px] font-black text-slate-500 font-sans">
                      {['শনি', 'রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহস্পতি', 'শুক্র'].map((day, i) => (
                        <div key={i} className="py-2 bg-slate-50/70 border border-slate-100 rounded-lg">
                          {day}
                        </div>
                      ))}
                    </div>

                    {/* Day Grid representation */}
                    <div className="grid grid-cols-7 gap-2">
                      {(() => {
                        const daysInMonth = new Date(currentCalendarYear, currentCalendarMonth + 1, 0).getDate();
                        const firstDayIndex = new Date(currentCalendarYear, currentCalendarMonth, 1).getDay(); // 0 is Sun, 6 is Sat
                        const startOffset = (firstDayIndex + 1) % 7; // Align to Saturday as day 0
                        const cells = [];

                        // Render offset cells
                        for (let i = 0; i < startOffset; i++) {
                          cells.push(
                            <div key={`empty-${i}`} className="min-h-[85px] bg-slate-50/30 border border-dashed border-slate-100 rounded-xl"></div>
                          );
                        }

                        // Render actual day cells
                        for (let d = 1; d <= daysInMonth; d++) {
                          const dateStr = `${currentCalendarYear}-${(currentCalendarMonth + 1).toString().padStart(2, '0')}-${d.toString().padStart(2, '0')}`;
                          
                          // Look for Direct holiday
                          const directH = holidaysList.find(h => h.type === 'direct' && h.date === dateStr);
                          
                          // Look for General periodic holiday
                          const dayNum = new Date(currentCalendarYear, currentCalendarMonth, d).getDay();
                          const bnWeekDay = ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'][dayNum];
                          const generalH = holidaysList.find(h => h.type === 'general' && h.dayOfWeek === bnWeekDay);
                          
                          const hasH = !!directH || !!generalH;
                          const hName = directH ? directH.name : (generalH ? generalH.name : '');
                          const isToday = currentCalendarYear === 2026 && currentCalendarMonth === 5 && d === 13;

                          cells.push(
                            <div
                              key={`day-${d}`}
                              onClick={() => {
                                if (directH) {
                                  handleEditHoliday(directH);
                                } else if (generalH) {
                                  handleEditHoliday(generalH);
                                } else {
                                  setEditingHolidayId(null);
                                  setHolidayType('direct');
                                  setHolidayName('');
                                  setHolidayDate(dateStr);
                                  setIsHolidayModalOpen(true);
                                }
                              }}
                              className={`min-h-[90px] p-2 border rounded-2xl cursor-pointer transition-all flex flex-col justify-between group relative select-none ${
                                isToday
                                  ? 'bg-blue-50/50 border-blue-500 ring-2 ring-blue-500/20'
                                  : hasH
                                    ? directH
                                      ? 'bg-red-50/50 border-red-200 hover:bg-rose-100/40'
                                      : 'bg-indigo-50/40 border-indigo-100 hover:bg-indigo-100/40'
                                    : 'bg-white border-slate-150 hover:bg-slate-50'
                              }`}
                            >
                              <div className="flex justify-between items-start">
                                <span className={`text-[11px] font-black font-sans leading-none ${isToday ? 'text-blue-700 bg-blue-100 px-1.5 py-0.5 rounded-md' : hasH ? 'text-red-600' : 'text-slate-800'}`}>
                                  {replaceNumbersWithBN(d)}
                                </span>
                                {isToday && (
                                  <span className="text-[7px] bg-blue-600 font-extrabold text-white px-1 rounded-sm leading-tight">TODAY</span>
                                )}
                              </div>

                              {hName && (
                                <div className="mt-1 space-y-0.5 max-w-full">
                                  <span className={`text-[9.5px] font-black block truncate leading-tight ${directH ? 'text-rose-700 font-bold bg-rose-100/50 px-1 py-0.5 rounded' : 'text-indigo-800 bg-indigo-50/60 px-1 py-0.5 rounded'}`}>
                                    🎈 {hName}
                                  </span>
                                  <span className="text-[8px] text-slate-400 block font-semibold leading-tight font-sans">
                                    {directH ? 'ঘোষিত সরকারী ছুটি' : 'সাপ্তাহিক ছুটি'}
                                  </span>
                                </div>
                              )}

                              <div className="absolute inset-0 bg-slate-900/[0.02] opacity-0 group-hover:opacity-100 rounded-2xl flex items-center justify-center transition duration-150">
                                <span className="text-[8.5px] font-black text-slate-800 bg-white/95 shadow-md border border-slate-200/85 px-2 py-1 rounded-lg">
                                  {hasH ? '🔔 সম্পাদনা' : '➕ ছুটি ঘোষণা'}
                                </span>
                              </div>
                            </div>
                          );
                        }
                        return cells;
                      })()}
                    </div>

                  </div>

                  {/* Right Section: Details panel & Quick guideline */}
                  <div className="space-y-6">
                    {/* 1. Month specific schedule list */}
                    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 space-y-3">
                      <div className="flex items-center gap-2 border-b border-slate-100 pb-2.5">
                        <div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600 font-bold">
                          <Calendar size={15} />
                        </div>
                        <div>
                          <h4 className="font-extrabold text-slate-800 text-xs">
                            {['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'][currentCalendarMonth]} মাসের ছুটির তালিকা
                          </h4>
                          <p className="text-[9.5px] text-slate-400 font-bold font-sans">এই নির্দিষ্ট মাসে ঘোষিত প্রাক-নির্ধারিত ছুটির দিনসমূহ</p>
                        </div>
                      </div>

                      <div className="space-y-1.5 max-h-[200px] overflow-y-auto pr-1">
                        {(() => {
                          const monthStr = (currentCalendarMonth + 1).toString().padStart(2, '0');
                          const yearStr = currentCalendarYear.toString();
                          const activeDaysH = holidaysList.filter(h => h.type === 'direct' && h.date?.startsWith(`${yearStr}-${monthStr}`));
                          
                          if (activeDaysH.length === 0) {
                            return (
                              <div className="py-6 text-center text-slate-400 italic text-[11px] font-bold">
                                এই মাসে কোনো নির্দিষ্ট সরকারি বা বিশেষ ছুটি ঘোষিত নেই।
                              </div>
                            );
                          }

                          return activeDaysH.map(h => (
                            <div key={h.id} className="p-2.5 bg-slate-50 border border-slate-200/60 rounded-xl hover:bg-slate-100/50 flex items-center justify-between gap-2.5 group transition">
                              <div className="space-y-0.5">
                                <p className="text-slate-800 text-[11px] font-black">{h.name}</p>
                                <p className="text-[9px] text-indigo-700 font-semibold flex items-center gap-1 font-sans">
                                  📅 {h.date}
                                </p>
                              </div>
                              <div className="flex items-center gap-1 transition duration-150">
                                <button
                                  type="button"
                                  onClick={() => handleEditHoliday(h)}
                                  className="p-1 text-slate-500 hover:text-blue-600 rounded-lg cursor-pointer"
                                >
                                  <Edit2 size={11} />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteHoliday(h.id, h.name)}
                                  className="p-1 text-rose-500 hover:text-rose-700 rounded-lg cursor-pointer"
                                >
                                  <X size={11} />
                                </button>
                              </div>
                            </div>
                          ));
                        })()}
                      </div>
                    </div>

                    {/* 2. Quick user guideline panel */}
                    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 space-y-3">
                      <div className="flex items-center gap-2 border-b border-slate-100 pb-2.5">
                        <div className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-600 font-bold">
                          <Info size={15} />
                        </div>
                        <div>
                          <h4 className="font-extrabold text-slate-800 text-xs">ছুটি ও ক্যালেন্ডার গাইডলাইন</h4>
                          <p className="text-[9.5px] text-slate-400 font-bold font-sans">সমন্বয় প্যানেল সাহায্যকারী</p>
                        </div>
                      </div>

                      <div className="text-[11px] text-slate-600 space-y-2 font-bold font-sans leading-relaxed">
                        <div className="flex gap-2">
                          <span className="text-emerald-500">•</span>
                          <span><strong>ছুটি ঘোষণা:</strong> ক্যালেন্ডার গ্রিডের যেকোনো খালি তারিখে ক্লিক করে সরাসরি বিশেষ বা সরকারি ছুটি ঘোষণা করতে পারেন।</span>
                        </div>
                        <div className="flex gap-2">
                          <span className="text-emerald-500">•</span>
                          <span><strong>কার্যকারিতা:</strong> ছুটির দিনে শাখা ব্যবস্থাপক বা কর্মীরা কোনো ধরনের নিয়মিত লোন বিতরণ বা কিস্তি কালেকশন শিডিউল করতে পারবে না।</span>
                        </div>
                        <div className="flex gap-2">
                          <span className="text-emerald-500">•</span>
                          <span><strong>সাপ্তাহিক বন্ধ:</strong> প্রতি সপ্তাহের 'শুক্রবার' ও 'শনিবার' (যদি আপনার রুলসে থাকে) স্বয়ংক্রিয় বন্ধের দিন হিসেবে কার্যকর হয়।</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <>
                  {/* Filters and Search Bar */}
                  <div className="bg-white rounded-2xl border border-slate-200/85 p-4 flex flex-wrap gap-4 items-center justify-between shadow-xs">
                    {/* Year Select Tabs */}
                    <div className="flex gap-1 bg-slate-100 p-1.5 rounded-xl">
                      {['all', '2026', '2027', '2028'].map((year) => {
                        const lable = year === 'all' ? 'সকল বছর' : year + ' সাল';
                        return (
                          <button
                            key={year}
                            type="button"
                            onClick={() => setHolidayYearFilter(year)}
                            className={`px-3 py-1.5 rounded-lg font-bold text-xs cursor-pointer transition ${
                              holidayYearFilter === year 
                                ? 'bg-blue-600 text-white shadow-xs' 
                                : 'text-slate-600 hover:text-slate-800 hover:bg-slate-200/60'
                            }`}
                          >
                            {lable}
                          </button>
                        );
                      })}
                    </div>

                    {/* Search Bar */}
                    <div className="relative w-full sm:w-72">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400 pointer-events-none">
                        <Search size={14} />
                      </span>
                      <input
                        type="text"
                        value={holidaySearchQuery}
                        onChange={(e) => setHolidaySearchQuery(e.target.value)}
                        placeholder="ছুটির নাম বা কারণ খুঁজুন..."
                        className="w-full pl-9 pr-4 py-1.5 border border-slate-200 rounded-xl text-xs bg-slate-5 font-semibold text-slate-700 placeholder:text-slate-400 focus:outline-blue-600"
                      />
                      {holidaySearchQuery && (
                        <button 
                          type="button"
                          onClick={() => setHolidaySearchQuery('')} 
                          className="absolute inset-y-0 right-0 flex items-center pr-3 text-slate-400 hover:text-slate-600"
                        >
                          <X size={12} />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Main Contents Grid */}
                  <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                    
                    {/* Panel 1: Direct public holidays (At a glance grouped by month) */}
                    <div className="xl:col-span-2 bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 space-y-4">
                      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600">
                            <Calendar size={16} />
                          </div>
                          <div>
                            <h4 className="font-extrabold text-slate-800 text-sm">ঘোষিত নির্দিষ্ট সরকারি ছুটির দিনসমূহ (Direct Holidays)</h4>
                            <p className="text-[10px] text-slate-400">ছুটি সহজে তদারকির জন্য নিচে মাস ভিত্তিক সাজানো তালিকায় দেখানো হলো</p>
                          </div>
                        </div>
                      </div>

                      {/* Month group view helper */}
                      {(() => {
                        const monthsBN = [
                          { value: 1, name: 'জানুয়ারি' },
                          { value: 2, name: 'ফেব্রুয়ারি' },
                          { value: 3, name: 'মার্চ' },
                          { value: 4, name: 'এপ্রিল' },
                          { value: 5, name: 'মে' },
                          { value: 6, name: 'জুন' },
                          { value: 7, name: 'জুলাই' },
                          { value: 8, name: 'আগস্ট' },
                          { value: 9, name: 'সেপ্টেম্বর' },
                          { value: 10, name: 'অক্টোবর' },
                          { value: 11, name: 'নভেম্বর' },
                          { value: 12, name: 'ডিসেম্বর' },
                        ];

                        const filteredHolidays = holidaysList.filter(h => {
                          if (h.type !== 'direct') return false;
                          if (holidaySearchQuery) {
                            const q = holidaySearchQuery.toLowerCase();
                            if (!h.name.toLowerCase().includes(q) && !(h.date && h.date.includes(q))) return false;
                          }
                          if (holidayYearFilter !== 'all' && h.date) {
                            if (!h.date.startsWith(holidayYearFilter)) return false;
                          }
                          return true;
                        });

                        if (filteredHolidays.length === 0) {
                          return (
                            <div className="py-16 text-center text-slate-405 border-2 border-dashed border-slate-100 rounded-2xl">
                              <Calendar size={32} className="mx-auto text-slate-300 mb-2.5 stroke-1" />
                              <p className="text-xs font-bold text-slate-500">কোনো নির্দিষ্ট ছুটি সচল বা খুঁজে পাওয়া যায়নি।</p>
                              <p className="text-[10px] text-slate-400 mt-1">প্যাটার্ন বা সার্চ ফিল্ড পরিবর্তন করে পুনরায় চেষ্টা করুন।</p>
                            </div>
                          );
                        }

                        // Group by year, then month
                        const years = holidayYearFilter === 'all' ? ['2026', '2027', '2028'] : [holidayYearFilter];

                        return (
                          <div className="space-y-6 max-h-[600px] overflow-y-auto pr-1">
                            {years.map(yr => {
                              const yrHolidays = filteredHolidays.filter(h => h.date?.startsWith(yr));
                              if (yrHolidays.length === 0) return null;

                              return (
                                <div key={yr} className="space-y-3.5">
                                  <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-100">
                                    <span className="font-black text-xs text-blue-700 bg-blue-50 px-2 py-0.5 rounded-lg">{yr}</span>
                                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">বছরের নির্ধারিত ছুটির ক্যালেন্ডার</span>
                                  </div>

                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                                    {monthsBN.map(m => {
                                      const mHolidays = yrHolidays.filter(h => {
                                        if (!h.date) return false;
                                        const monthPart = parseInt(h.date.split('-')[1], 10);
                                        return monthPart === m.value;
                                      });

                                      if (mHolidays.length === 0) return null;

                                      return (
                                        <div key={m.value} className="bg-slate-50/40 rounded-xl p-3 border border-slate-150/50 space-y-2">
                                          <h5 className="text-xs font-black text-slate-700 border-b border-slate-150/50 pb-1.5 flex justify-between items-center font-sans">
                                            <span>📅 {m.name}</span>
                                            <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded">
                                              {mHolidays.length} টি
                                            </span>
                                          </h5>

                                          <div className="space-y-1.5">
                                            {mHolidays.map(h => (
                                              <div key={h.id} className="p-2 bg-white rounded-lg border border-slate-100 shadow-3xs flex items-center justify-between text-xs font-bold group font-sans">
                                                <div className="space-y-0.5">
                                                  <p className="text-slate-800 text-[11px] leading-tight font-extrabold">{h.name}</p>
                                                  <p className="text-[9px] text-indigo-700 font-semibold flex items-center gap-1">
                                                    <span>📅 {h.date}</span>
                                                    <span className="text-slate-350">•</span>
                                                    <span className="font-mono text-[8.5px] text-slate-400">ID: {h.id}</span>
                                                  </p>
                                                </div>

                                                {/* Action triggers */}
                                                <div className="flex items-center gap-1 transition duration-150 shrink-0 select-none">
                                                  <button
                                                    type="button"
                                                    onClick={() => handleEditHoliday(h)}
                                                    className="p-1 hover:bg-slate-100 text-slate-500 hover:text-blue-600 rounded-lg cursor-pointer"
                                                    title="সম্পাদনা করুন"
                                                  >
                                                    <Edit2 size={11} />
                                                  </button>
                                                  <button
                                                    type="button"
                                                    onClick={() => handleDeleteHoliday(h.id, h.name)}
                                                    className="p-1 hover:bg-rose-50 text-rose-500 hover:text-rose-700 rounded-lg cursor-pointer"
                                                    title="বাতিল করুন"
                                                  >
                                                    <X size={11} />
                                                  </button>
                                                </div>
                                              </div>
                                            ))}
                                          </div>
                                        </div>
                                      );
                                    })}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        );
                      })()}
                    </div>

                    {/* Panel 2: General/weekly holidays */}
                    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 space-y-4 h-fit">
                      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-600">
                            <Clock size={16} />
                          </div>
                          <div>
                            <h4 className="font-extrabold text-slate-800 text-sm">নিয়মিত সাপ্তাহিক ছুটিসমূহ (Weekly Holidays)</h4>
                            <p className="text-[10px] text-slate-400 font-semibold font-sans">প্রতি সপ্তাহের সাধারণ কর্মবিরতি</p>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
                        {holidaysList.filter(h => h.type === 'general').length === 0 ? (
                          <div className="py-12 text-center text-slate-400 border-2 border-dashed border-slate-100 rounded-2xl font-sans">
                            <Clock size={28} className="mx-auto text-slate-300 mb-2.5 stroke-1" />
                            <p className="text-xs font-semibold">কোনো সাধারণ বা সাপ্তাহিক ছুটি ঘোষিত নেই।</p>
                            <p className="text-[10px] text-slate-400 mt-1">যেমন: শুক্রবার স্থায়ী সাপ্তাহিক ছুটি সংরক্ষণ করুন।</p>
                          </div>
                        ) : (
                          holidaysList.filter(h => h.type === 'general').map((holiday) => (
                            <div 
                              key={holiday.id} 
                              className="p-3 bg-slate-50 border border-slate-205/50 rounded-xl hover:bg-slate-100/50 transition flex items-center justify-between gap-3 group font-sans font-semibold text-xs"
                            >
                              <div className="space-y-1">
                                <div className="flex items-center gap-1.5 font-bold text-slate-800 text-xs">
                                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                                  <span>{holiday.name}</span>
                                </div>
                                <p className="font-extrabold text-emerald-700 text-[10px] bg-emerald-50 px-2 py-0.5 rounded-md inline-block">
                                  প্রতি সপ্তাহের: <span className="underline">{holiday.dayOfWeek}</span>
                                </p>
                                <p className="text-[8.5px] text-slate-400 block pt-0.5 font-mono">
                                  আইডি: {holiday.id} • ঘোষিত: {new Date(holiday.addDate || '').toLocaleDateString('bn-BD')}
                                </p>
                              </div>
                              
                              <div className="flex items-center gap-1 transition duration-150">
                                <button
                                  type="button"
                                  onClick={() => handleEditHoliday(holiday)}
                                  className="p-1 hover:bg-slate-200 text-slate-500 hover:text-blue-600 rounded-lg cursor-pointer"
                                  title="সম্পাদনা করুন"
                                >
                                  <Edit2 size={11} />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteHoliday(holiday.id, holiday.name)}
                                  className="p-1 hover:bg-rose-100 text-rose-600 rounded-lg cursor-pointer"
                                  title="Holiday বাতিল করুন"
                                >
                                  <Trash2 size={11} />
                                </button>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>

                  </div>
                </>
              )}

            </div>
          )}

          {/* VIEW 6: Operations / অপারেশন প্যানেল */}
          {activeTab === 'operations' && (
            <div className="space-y-6 animate-in fade-in duration-100">
              
              {/* Top Bar */}
              <div className="border-b border-slate-100 pb-4">
                <h2 className="text-lg font-extrabold text-slate-800 tracking-tight flex items-center gap-2">
                  <Layers size={20} className="text-blue-600" />
                  অপারেশন প্যানেল ও কার্যবিধি (Operations Board)
                </h2>
                <p className="text-[11px] text-slate-500 font-medium mt-0.5">
                  প্রতিষ্ঠানের ব্যাকডপ প্রসেসিং, সিক্রেট অ্যাকশন মেকানিজম এবং অপারেশনাল কন্ট্রোলসমূহ।
                </p>
              </div>

              {/* Highlight Note */}
              <div className="bg-amber-50 rounded-2xl border border-amber-200/60 p-5 leading-relaxed text-xs text-amber-900 shadow-xs flex items-start gap-3">
                <Info size={18} className="text-amber-600 shrink-0 mt-0.5 animate-pulse" />
                <div className="space-y-1">
                  <span className="font-extrabold text-sm block">ব্যবহারকারী নোটিশ / Action Instructions:</span>
                  <p className="text-[11.5px] text-amber-950/80">
                    "অপারেশন" অপশনের কাস্টম ব্যাকএন্ড অ্যাকশন এবং ট্রিগার কি হবে তা আপনার নির্দেশনা অনুযায়ী পরবর্তীতে নির্ধারণ করা হবে। বর্তমানে প্যানেলটি প্রস্তুত করে রাখা হয়েছে এবং সচল করা হয়েছে।
                  </p>
                </div>
              </div>

              {/* Placeholder Operation Modules */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4.5">
                
                {/* Card 1: Day Closing */}
                <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3.5 relative overflow-hidden group hover:border-blue-500/55 transition duration-200">
                  <div className="w-9 h-9 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center font-bold">
                    <Clock size={18} />
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-bold text-slate-800 text-xs">অপারেশন ১: ডেইলি ডে-এন্ড ক্লোজিং (Day-end Processing)</h4>
                    <p className="text-[10px] text-slate-400 leading-relaxed">দিন শেষে ক্যাশ ব্যালেন্স ও সঞ্চয়-ঋণের রিকনসিলিয়েশন সম্পন্ন করুন। এটি পরবর্তী কর্মদিবস নির্ধারণ করতে সাহায্য করবে।</p>
                  </div>
                  <button 
                    type="button"
                    disabled 
                    className="w-full py-2 bg-slate-100 text-slate-400 font-bold text-[10px] rounded-lg cursor-not-allowed uppercase"
                  >
                    শীঘ্রই সচল হবে
                  </button>
                </div>

                {/* Card 2: Run Custom Scripts */}
                <div className="bg-white rounded-2xl border border-slate-205 p-5 space-y-3.5 relative overflow-hidden group hover:border-blue-500/55 transition duration-200">
                  <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                    <Sliders size={18} />
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-bold text-slate-800 text-xs">অপারেশন ২: কাস্টম স্ক্রিপ্ট ট্রিগার (Custom Script Triggers)</h4>
                    <p className="text-[10px] text-slate-400 leading-relaxed">ইন্টারেক্টিভ ক্যালকুলেশন স্ক্রিপ্ট রান করানো অথবা সংগঠনের নির্দিষ্ট ডাটাবেজ ফিক্স সেটিংস ম্যানুয়ালি ওভাররাইট অ্যাকশন।</p>
                  </div>
                  <button 
                    type="button"
                    disabled 
                    className="w-full py-2 bg-slate-100 text-slate-400 font-bold text-[10px] rounded-lg cursor-not-allowed uppercase"
                  >
                    শীঘ্রই সচল হবে
                  </button>
                </div>

                {/* Card 3: Secure Export */}
                <div className="bg-white rounded-2xl border border-slate-205 p-5 space-y-3.5 relative overflow-hidden group hover:border-blue-500/55 transition duration-200">
                  <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
                    <Shield size={18} />
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-bold text-slate-800 text-xs">অপারেশন ৩: ব্যাকআপ ও ইন্টিগ্রিটি চেক (Backup & Integrity Check)</h4>
                    <p className="text-[10px] text-slate-400 leading-relaxed">সংগঠন ডাটার ব্যাকআপ তৈরি করে লোকাল ফাইলে ডিক্রিপ্ট করা এবং সিকিউরিটি ইন্টিগ্রিটি লক সক্রিয় করা।</p>
                  </div>
                  <button 
                    type="button"
                    disabled 
                    className="w-full py-2 bg-slate-100 text-slate-400 font-bold text-[10px] rounded-lg cursor-not-allowed uppercase"
                  >
                    শীঘ্রই সচল হবে
                  </button>
                </div>

              </div>

            </div>
          )}

        </main>
      </div>

      {/* --- POPUPS & SECONDARY DIALOG MODALS --- */}
      
      {/* MODAL: Working Day Modification */}
      {isWorkingDayModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-100">
          <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-100 animate-in zoom-in-95 duration-150">
            <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200/80 flex justify-between items-center">
              <h3 className="font-bold text-slate-800 text-xs sm:text-sm flex items-center gap-1.5">
                <Clock size={16} className="text-blue-600" /> কর্মদিবস নির্ধারণ (Change Working Day)
              </h3>
              <button onClick={() => setIsWorkingDayModalOpen(false)} className="text-slate-400 hover:text-slate-600 p-0.5">
                <X size={18} />
              </button>
            </div>
            
            <form onSubmit={(e) => {
              e.preventDefault();
              if (workingDayInput) {
                setWorkingDay(workingDayInput);
                localStorage.setItem(`tanzil_working_day_${org.id}`, workingDayInput);
                setIsWorkingDayModalOpen(false);
              }
            }} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">নতুন কর্মদিবস নির্বাচন করুন</label>
                <input 
                  type="date" 
                  className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm font-medium focus:ring-1 focus:ring-blue-500 focus:outline-none" 
                  value={workingDayInput} 
                  onChange={(e) => setWorkingDayInput(e.target.value)}
                  required
                />
                <p className="text-[10px] text-slate-400 mt-1.5 leading-relaxed">
                  * তানজিল সিস্টেমে এই তারিখটি আজকের অফিসিয়াল ট্রানজেকশন ডে হিসেবে গৃহীত হবে।
                </p>
              </div>

              <div className="flex gap-2.5 pt-2">
                <button 
                  type="button" 
                  onClick={() => setIsWorkingDayModalOpen(false)}
                  className="flex-1 py-1.5 text-xs font-bold text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200"
                >
                  বাতিল
                </button>
                <button 
                  type="submit"
                  className="flex-1 py-1.5 text-xs font-bold text-white bg-blue-600 rounded-xl hover:bg-blue-700 transition"
                >
                  পরিবর্তন করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Change Admin Password */}
      {isChangePasswordModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-100">
          <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-100 animate-in zoom-in-95 duration-150">
            <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200/80 flex justify-between items-center">
              <h3 className="font-bold text-slate-800 text-xs sm:text-sm flex items-center gap-1.5">
                <Key size={16} className="text-indigo-600" /> প্রাতিষ্ঠানিক পাসওয়ার্ড পরিবর্তন
              </h3>
              <button onClick={() => setIsChangePasswordModalOpen(false)} className="text-slate-400 hover:text-slate-600 p-0.5">
                <X size={18} />
              </button>
            </div>
            
            <form onSubmit={(e) => {
              e.preventDefault();
              if (newPasswordVal.trim().length === 0) {
                alert('দয়া করে সঠিক পাসওয়ার্ড দিন');
                return;
              }
              if (newPasswordVal !== confirmPasswordVal) {
                alert('পাসওয়ার্ড দুটি মেলেনি!');
                return;
              }
              
              // Save
              setOrgPassword(newPasswordVal);
              if (onUpdateOrg) {
                onUpdateOrg({
                  ...org,
                  adminPassword: newPasswordVal
                });
              }
              
              setPasswordChangeSuccess('পাসওয়ার্ড সফলভাবে পরিবর্তন করা হয়েছে!');
              setTimeout(() => {
                setPasswordChangeSuccess('');
                setIsChangePasswordModalOpen(false);
              }, 2000);
            }} className="p-5 space-y-4">
              
              {passwordChangeSuccess ? (
                <div className="p-4 bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-xl text-center text-xs font-bold space-y-1">
                  <p>{passwordChangeSuccess}</p>
                </div>
              ) : (
                <>
                  <div className="space-y-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">নতুন পাসওয়ার্ড</label>
                      <input 
                        type="password" 
                        placeholder="নতুন পাসওয়ার্ড দিন"
                        className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm font-mono tracking-wide focus:ring-1 focus:ring-blue-500 focus:outline-none" 
                        value={newPasswordVal} 
                        onChange={(e) => setNewPasswordVal(e.target.value)}
                        required
                        minLength={4}
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">নতুন পাসওয়ার্ড নিশ্চিত করুন</label>
                      <input 
                        type="password" 
                        placeholder="পাসওয়ার্ড নিশ্চিত করুন"
                        className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm font-mono tracking-wide focus:ring-1 focus:ring-blue-500 focus:outline-none" 
                        value={confirmPasswordVal} 
                        onChange={(e) => setConfirmPasswordVal(e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  <div className="flex gap-2.5 pt-2">
                    <button 
                      type="button" 
                      onClick={() => setIsChangePasswordModalOpen(false)}
                      className="flex-1 py-1.5 text-xs font-bold text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-250"
                    >
                      বাতিল
                    </button>
                    <button 
                      type="submit"
                      className="flex-1 py-1.5 text-xs font-bold text-white bg-indigo-600 rounded-xl hover:bg-indigo-750"
                    >
                      পরিবর্তন নিশ্চিত করুন
                    </button>
                  </div>
                </>
              )}
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Declare New Holiday */}
      {isHolidayModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-100">
          <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-100 animate-in zoom-in-95 duration-150">
            <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200/80 flex justify-between items-center">
              <h3 className="font-bold text-slate-800 text-xs sm:text-sm flex items-center gap-1.5">
                <Calendar size={16} className="text-blue-600" /> নতুন ছুটি ঘোষণা (Declare Holiday)
              </h3>
              <button onClick={() => setIsHolidayModalOpen(false)} className="text-slate-400 hover:text-slate-600 p-0.5">
                <X size={18} />
              </button>
            </div>
            
            <form onSubmit={handleAddHoliday} className="p-5 space-y-4">
              
              {/* Holiday type selection radio segment */}
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">ছুটির ধরণ</label>
                <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setHolidayType('direct')}
                    className={`py-1.5 text-xs font-bold rounded-lg transition-all ${
                      holidayType === 'direct' ? 'bg-white text-slate-800 shadow-xs' : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    সরাসরি বিশেষ ছুটি
                  </button>
                  <button
                    type="button"
                    onClick={() => setHolidayType('general')}
                    className={`py-1.5 text-xs font-bold rounded-lg transition-all ${
                      holidayType === 'general' ? 'bg-white text-slate-800 shadow-xs' : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    সাধারণ / সাপ্তাহিক
                  </button>
                </div>
              </div>

              {/* Holiday Reason */}
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1">ছুটির নাম বা কারণ *</label>
                <input 
                  type="text" 
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none placeholder:text-slate-405" 
                  value={holidayName} 
                  onChange={(e) => setHolidayName(e.target.value)}
                  placeholder={holidayType === 'direct' ? 'যেমন: স্বাধীনতা দিবস, শবে বরাত ইত্যাদি' : 'যেমন: সাপ্তাহিক শুক্রবার ছুটি'}
                  required
                />
              </div>

              {/* Specific Date input if HolidayType === 'direct' */}
              {holidayType === 'direct' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">ছুটির নির্দিষ্ট তারিখ *</label>
                  <input 
                    type="date" 
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none" 
                    value={holidayDate} 
                    onChange={(e) => setHolidayDate(e.target.value)}
                    required
                  />
                </div>
              )}

              {/* Day of Week select dropdown if HolidayType === 'general' */}
              {holidayType === 'general' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">স্থায়ী সাপ্তাহিক সচল দিন *</label>
                  <select
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                    value={holidayDayOfWeek}
                    onChange={(e) => setHolidayDayOfWeek(e.target.value)}
                    required
                  >
                    <option value="শুক্রবার">শুক্রবার (Friday)</option>
                    <option value="শনিবার">শনিবার (Saturday)</option>
                    <option value="রবিবার">রবিবার (Sunday)</option>
                    <option value="সোমবার">সোমবার (Monday)</option>
                    <option value="মঙ্গলবার">মঙ্গলবার (Tuesday)</option>
                    <option value="বুধবার">বুধবার (Wednesday)</option>
                    <option value="বৃহস্পতিবার">বৃহস্পতিবার (Thursday)</option>
                  </select>
                </div>
              )}

              <div className="flex gap-2.5 pt-2">
                <button 
                  type="button" 
                  onClick={() => setIsHolidayModalOpen(false)}
                  className="flex-1 py-1.5 text-xs font-bold text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200"
                >
                  বাতিল
                </button>
                <button 
                  type="submit"
                  className="flex-1 py-1.5 text-xs font-bold text-white bg-blue-600 rounded-xl hover:bg-blue-700 transition"
                >
                  ছুটি ঘোষণা করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Custom Confirmation Modal */}
      {confirmModal && confirmModal.isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-100 text-left">
          <div className="bg-white rounded-2xl shadow-xl max-w-sm w-full overflow-hidden border border-slate-100 p-5 space-y-4">
            <h4 className="font-extrabold text-slate-900 text-sm flex items-center gap-1.5">
              ⚠️ {confirmModal.title}
            </h4>
            <p className="text-xs text-slate-600 font-semibold leading-relaxed">
              {confirmModal.message}
            </p>
            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setConfirmModal(null)}
                className="flex-1 py-2 text-xs font-bold text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200 cursor-pointer"
              >
                বাতিল (Cancel)
              </button>
              <button
                type="button"
                onClick={confirmModal.onConfirm}
                className="flex-1 py-2 text-xs font-bold text-white bg-blue-600 rounded-xl hover:bg-blue-700 transition cursor-pointer"
              >
                হ্যাঁ, নিশ্চিত (Confirm)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Custom Alert Modal */}
      {alertModal && alertModal.isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-100 text-left">
          <div className="bg-white rounded-2xl shadow-xl max-w-sm w-full overflow-hidden border border-slate-100 p-5 space-y-4">
            <h4 className="font-extrabold text-slate-900 text-sm flex items-center gap-1.5">
              📢 {alertModal.title}
            </h4>
            <p className="text-xs text-slate-600 font-semibold leading-relaxed">
              {alertModal.message}
            </p>
            <div className="flex pt-1.5">
              <button
                type="button"
                onClick={() => setAlertModal(null)}
                className="w-full py-2 text-xs font-bold text-white bg-blue-600 rounded-xl hover:bg-blue-700 transition cursor-pointer"
              >
                ঠিক আছে (OK)
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

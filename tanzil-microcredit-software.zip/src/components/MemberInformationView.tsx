/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Search, 
  User, 
  Phone, 
  CreditCard, 
  Layers, 
  MapPin, 
  Smile, 
  ShieldAlert,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  XCircle,
  TrendingUp,
  AlertCircle
} from 'lucide-react';

interface MemberInformationViewProps {
  onBack: () => void;
  groupMembers: any[];
  branchGroups: any[];
  selectedGroupId: string;
  onUpdateStatus: (memberId: string, newStatus: 'active' | 'inactive', reason?: string) => void;
}

export const MemberInformationView: React.FC<MemberInformationViewProps> = ({
  onBack,
  groupMembers,
  branchGroups,
  selectedGroupId,
  onUpdateStatus
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [expandedMemberId, setExpandedMemberId] = useState<string | null>(null);
  
  // Status editing sub-state
  const [editingStatusId, setEditingStatusId] = useState<string | null>(null);
  const [tempStatus, setTempStatus] = useState<'active' | 'inactive'>('active');
  const [tempReason, setTempReason] = useState('ভর্তি বাতিল');
  const [statusError, setStatusError] = useState<string | null>(null);

  // Filter members based on selected Group, Search query, and Status
  const filtered = groupMembers.filter((m) => {
    // Group filter: if selectedGroupId is set, match. Otherwise show all of this branch
    if (selectedGroupId && m.groupId !== selectedGroupId) return false;
    
    // Status filter
    if (statusFilter !== 'all' && m.status !== statusFilter) return false;

    // Search text constraint
    const query = searchTerm.toLowerCase();
    if (!query) return true;

    return (
      m.name.toLowerCase().includes(query) ||
      m.memberId.toLowerCase().includes(query) ||
      m.phone.includes(query) ||
      (m.nid && m.nid.includes(query))
    );
  });

  const getGroupName = (gId: string) => {
    const group = branchGroups.find((g) => g.id === gId);
    return group ? `${group.name} (${group.code})` : 'সাধারন গ্রাহক';
  };

  const handleToggleDetails = (id: string) => {
    setExpandedMemberId(expandedMemberId === id ? null : id);
  };

  const startEditStatus = (member: any) => {
    setEditingStatusId(member.id);
    setTempStatus(member.status || 'active');
    setTempReason(member.inactiveReason || 'ভর্তি বাতিল');
    setStatusError(null);
  };

  const saveStatusChange = (id: string) => {
    const targetMember = groupMembers.find(m => m.id === id);
    if (tempStatus === 'inactive' && targetMember) {
      const plOut = targetMember.plOutstanding || 0;
      const cbsBal = targetMember.cbsBalance || 0;
      const ltsBal = targetMember.ltsBalance || 0;
      const gsBal = targetMember.gsBalance || targetMember.savingsBalance || 0;

      if (plOut > 0 || cbsBal > 0 || ltsBal > 0 || gsBal > 0) {
        setStatusError("সদস্যের সক্রিয় অ্যাকাউন্ট (PL, CBS, LTS, GS) ও ব্যালেন্স থাকায় নিষ্ক্রিয় করা যাবে না!");
        return;
      }
    }

    onUpdateStatus(id, tempStatus, tempStatus === 'inactive' ? tempReason : '');
    setEditingStatusId(null);
    setStatusError(null);
  };

  return (
    <div className="bg-[#f4f6f9] text-slate-800 animate-in fade-in duration-300 rounded-3xl overflow-hidden border border-slate-300 max-w-md mx-auto shadow-2xl">
      {/* HEADER */}
      <div className="bg-[#2f6ce5] text-white px-5 py-4 flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          className="p-1 -ml-1 rounded-full hover:bg-white/10 active:scale-90 transition-all cursor-pointer flex items-center justify-center"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <div className="text-center">
          <h2 className="font-black text-sm sm:text-base tracking-wide flex items-center gap-1.5 justify-center">
            <User className="w-4 h-4 text-emerald-400" />
            সদস্য তথ্য ও KYC বিবরণী
          </h2>
          <p className="text-[10px] text-sky-100/95 font-bold mt-0.5">মোট সদস্য সংখ্যা: {filtered.length} জন</p>
        </div>
        <div className="w-7"></div>
      </div>

      {/* FILTER SEARCH BARS */}
      <div className="bg-white border-b border-slate-200 p-4 space-y-3 font-sans">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="নাম, মোবাইল বা মেম্বার আইডি খুঁজুন..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 rounded-xl pl-9 pr-4 py-2 text-xs font-bold text-slate-850 outline-none focus:ring-1 focus:ring-indigo-500 transition-all"
          />
        </div>

        {/* Status Filters */}
        <div className="flex gap-1.5 justify-between">
          <button
            type="button"
            onClick={() => setStatusFilter('all')}
            className={`flex-1 py-1.5 px-2 rounded-lg text-[11px] font-black transition-colors ${
              statusFilter === 'all' 
                ? 'bg-[#2f6ce5] text-white' 
                : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
            }`}
          >
            সবাই ({groupMembers.filter(m => !selectedGroupId || m.groupId === selectedGroupId).length})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('active')}
            className={`flex-1 py-1.5 px-2 rounded-lg text-[11px] font-black transition-colors flex items-center justify-center gap-1 ${
              statusFilter === 'active' 
                ? 'bg-emerald-600 text-white' 
                : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-100'
            }`}
          >
            সচল ({groupMembers.filter(m => (!selectedGroupId || m.groupId === selectedGroupId) && m.status === 'active').length})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('inactive')}
            className={`flex-1 py-1.5 px-2 rounded-lg text-[11px] font-black transition-colors flex items-center justify-center gap-1 ${
              statusFilter === 'inactive' 
                ? 'bg-rose-600 text-white' 
                : 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-100'
            }`}
          >
            নিষ্ক্রিয় ({groupMembers.filter(m => (!selectedGroupId || m.groupId === selectedGroupId) && m.status === 'inactive').length})
          </button>
        </div>
      </div>

      {/* MEMBER CARDS LIST AREA */}
      <div className="p-4 space-y-4 max-h-[60vh] overflow-y-auto">
        {filtered.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl border border-slate-200 p-6 space-y-3">
            <Smile className="w-10 h-10 text-amber-400 mx-auto animate-bounce" />
            <p className="text-slate-500 font-extrabold text-xs sm:text-sm">কোনো সদস্য তথ্য পাওয়া যায়নি</p>
            <p className="text-[10px] text-slate-400">এই সমিতি বা ফিল্টারে ভর্তি হওয়া কোনো গ্রাহক নেই। নতুন সদস্য ভর্তি করতে &apos;Member Admission&apos; ফর্মটি ব্যবহার করুন।</p>
          </div>
        ) : (
          filtered.map((member) => {
            const isExpanded = expandedMemberId === member.id;
            const isCurrentEditingStatus = editingStatusId === member.id;

            return (
              <div 
                key={member.id} 
                className={`bg-white rounded-2xl border transition-all duration-200 overflow-hidden ${
                  isExpanded ? 'border-indigo-400 shadow-md ring-1 ring-indigo-200' : 'border-slate-200 shadow-sm hover:border-slate-350'
                }`}
              >
                {/* SIMPLE DETAILS PANEL (Always visible) */}
                <div 
                  className="p-4 flex items-center justify-between cursor-pointer select-none"
                  onClick={() => handleToggleDetails(member.id)}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 border border-slate-200">
                      <User className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="font-extrabold text-slate-800 text-xs sm:text-sm">{member.name}</div>
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5 flex items-center gap-2">
                        <span>{member.memberId || 'MEM-N/A'}</span>
                        <span>•</span>
                        <span>{member.phone}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5">
                    {member.status === 'inactive' ? (
                      <span className="bg-rose-50 border border-rose-100 text-rose-700 text-[9px] px-2 py-0.5 rounded font-black uppercase">
                        নিষ্ক্রিয়
                      </span>
                    ) : (
                      <span className="bg-emerald-50 border border-emerald-100 text-emerald-700 text-[9px] px-2 py-0.5 rounded font-black uppercase">
                        সচল
                      </span>
                    )}
                    {isExpanded ? <ChevronUp size={14} className="text-slate-400" /> : <ChevronDown size={14} className="text-slate-400" />}
                  </div>
                </div>

                {/* EXPANDED KYC PROFILE DETAILS */}
                {isExpanded && (
                  <div className="bg-slate-50 border-t border-slate-100 p-4 space-y-4 text-[11px] animate-in slide-in-from-top-2 duration-150">
                    
                    {/* Samity Reference */}
                    <div className="bg-white p-2.5 rounded-xl border border-slate-200/80 flex justify-between items-center font-bold">
                      <span className="text-slate-400">সমিতি নাম:</span>
                      <span className="text-indigo-600 text-xs md:text-[11px] font-black">{getGroupName(member.groupId)}</span>
                    </div>

                    {/* Detailed Info Grid */}
                    <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-slate-650">
                      <div>
                        <div className="text-slate-400 font-bold mb-0.5">পিতা / স্বামীর নাম:</div>
                        <div className="text-slate-800 font-black">{member.fatherHusbandName || 'N/A'}</div>
                      </div>
                      <div>
                        <div className="text-slate-400 font-bold mb-0.5">মাতার নাম:</div>
                        <div className="text-slate-800 font-black">{member.motherName || 'N/A'}</div>
                      </div>
                      <div>
                        <div className="text-slate-400 font-bold mb-0.5">জাতীয় পরিচয় নম্বর:</div>
                        <div className="text-slate-800 font-mono font-black">{member.nid || 'N/A'}</div>
                      </div>
                      <div>
                        <div className="text-slate-400 font-bold mb-0.5">জন্ম তারিখ:</div>
                        <div className="text-slate-800 font-mono font-black">{member.dob || 'N/A'}</div>
                      </div>
                      <div>
                        <div className="text-slate-400 font-bold mb-0.5">ধর্ম / লিঙ্গ:</div>
                        <div className="text-slate-800 font-black">{member.religion || 'ইসলাম'} / {member.gender || 'মহিলা'}</div>
                      </div>
                      <div>
                        <div className="text-slate-400 font-bold mb-0.5">শিক্ষাগত যোগ্যতা:</div>
                        <div className="text-slate-800 font-black">{member.education || 'N/A'}</div>
                      </div>
                      <div>
                        <div className="text-slate-400 font-bold mb-0.5">পেশা / অভিভাবকের পেশা:</div>
                        <div className="text-slate-800 font-black">{member.profession || 'গৃহিণী'} / {member.guardianProfession || 'কৃষি'}</div>
                      </div>
                      <div>
                        <div className="text-slate-400 font-bold mb-0.5">ভর্তির তারিখ:</div>
                        <div className="text-slate-800 font-mono font-black">{member.admissionDate || member.addDate || 'N/A'}</div>
                      </div>
                    </div>

                    {/* Addresses */}
                    <div className="border-t border-slate-200/60 pt-2.5 space-y-1.5 col-span-2">
                      <div className="flex items-start gap-1">
                        <MapPin size={12} className="text-[#2f6ce5] shrink-0 mt-0.5" />
                        <div>
                          <span className="text-slate-400 font-bold">বর্তমান ঠিকানা: </span>
                          <span className="text-slate-800 font-extrabold">{member.address || 'N/A'}</span>
                        </div>
                      </div>
                    </div>

                    {/* Nominee details info */}
                    <div className="border-t border-slate-200/60 pt-2.5 space-y-1 bg-white p-2.5 rounded-xl border border-slate-150">
                      <div className="text-[10px] text-teal-600 font-black uppercase tracking-wide flex items-center gap-1">
                        <Smile className="w-3.5 h-3.5" />
                        নমিনী বিবরণী (Nominee Information)
                      </div>
                      <div className="grid grid-cols-2 gap-2 mt-1.5 text-slate-600">
                        <div>
                          <span className="text-slate-400">নমিনির নাম:</span>
                          <div className="font-black text-slate-800">{member.nomineeName || 'N/A'}</div>
                        </div>
                        <div>
                          <span className="text-slate-400">সম্পর্ক:</span>
                          <div className="font-black text-slate-800">{member.nomineeRelation || 'N/A'}</div>
                        </div>
                        {member.nomineeNid && (
                          <div className="col-span-2">
                            <span className="text-slate-400">নমিনির NID/জন্ম নিবন্ধন নং:</span>
                            <div className="font-mono font-black text-slate-800">{member.nomineeNid}</div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Savings Deposit */}
                    <div className="bg-indigo-50 border border-indigo-100 p-2.5 rounded-xl flex items-center justify-between">
                      <div className="flex items-center gap-1.5 text-indigo-700 font-bold">
                        <TrendingUp size={13} />
                        <span>প্রারম্ভিক সঞ্চয় ব্যালেন্স:</span>
                      </div>
                      <span className="text-indigo-800 font-extrabold">৳{(member.savingsBalance || 0).toLocaleString('bn-BD')}</span>
                    </div>

                    {/* STATUS EDITING PANEL (ASA NGO CONTROL) */}
                    <div className="border-t border-slate-200/60 pt-2.5">
                      {!isCurrentEditingStatus ? (
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-1 text-[10px] text-slate-400">
                            <AlertCircle size={12} />
                            <span>সদস্য স্ট্যাটাস পরিবর্তন</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => startEditStatus(member)}
                            className="text-[10px] font-black bg-slate-800 text-amber-500 hover:bg-slate-900 border border-slate-200 rounded-md py-1 px-2.5 transition active:scale-95"
                          >
                            স্ট্যাটাস পরিবর্তন (Change Status)
                          </button>
                        </div>
                      ) : (
                        <div className="bg-slate-200/70 p-3 rounded-xl border border-slate-250 space-y-3">
                          <div className="text-[10px] font-black text-slate-700 flex justify-between">
                            <span>স্ট্যাটাস পরিবর্তন করুন:</span>
                            <span className="font-mono">{member.memberId}</span>
                          </div>
                          
                          <div className="flex gap-4">
                            <label className="flex items-center gap-1.5 cursor-pointer text-xs font-bold">
                              <input
                                type="radio"
                                name={`status-${member.id}`}
                                checked={tempStatus === 'active'}
                                onChange={() => setTempStatus('active')}
                                className="w-3.5 h-3.5 text-emerald-600 focus:ring-emerald-500"
                              />
                              <span className="text-emerald-700 font-extrabold bg-emerald-50 px-2 py-0.5 rounded">সচল (Active)</span>
                            </label>
                            
                            <label className="flex items-center gap-1.5 cursor-pointer text-xs font-bold">
                              <input
                                type="radio"
                                name={`status-${member.id}`}
                                checked={tempStatus === 'inactive'}
                                onChange={() => setTempStatus('inactive')}
                                className="w-3.5 h-3.5 text-rose-600 focus:ring-rose-500"
                              />
                              <span className="text-rose-700 font-extrabold bg-rose-50 px-2 py-0.5 rounded">নিষ্ক্রিয় (Inactive)</span>
                            </label>
                          </div>

                          {tempStatus === 'inactive' && (
                            <div className="space-y-1 animate-in slide-in-from-top-1">
                              <span className="text-[10px] text-slate-500 font-bold block">নিষ্ক্রিয়করনের কারণ:</span>
                              <select
                                value={tempReason}
                                onChange={(e) => setTempReason(e.target.value)}
                                className="w-full text-[10px] font-bold py-1 px-2 border border-slate-350 rounded-md bg-white text-rose-800"
                              >
                                <option value="ভর্তি বাতিল">ভর্তি বাতিল (Admission Cancelled)</option>
                                <option value="ঋণ পরিশোধ পরবর্তী নিষ্ক্রিয়">ঋণ পরিশোধ পরবর্তী নিষ্ক্রিয় (Inactive after Loan Paid)</option>
                                <option value="স্বেচ্ছায় পদত্যাগ">স্বেচ্ছায় পদত্যাগ (Voluntary Resignation)</option>
                                <option value="স্থানান্তরিত">স্থানান্তরিত (Transferred)</option>
                                <option value="অন্যান্য সাময়িক অসচলতা">অন্যান্য সাময়িক অসচলতা</option>
                              </select>
                            </div>
                          )}

                          {statusError && (
                            <div className="bg-rose-50 text-rose-700 p-2 border border-rose-100 rounded-lg text-[10px] font-extrabold leading-tight">
                              {statusError}
                            </div>
                          )}

                          <div className="flex gap-2 pt-1">
                            <button
                              type="button"
                              onClick={() => setEditingStatusId(null)}
                              className="flex-1 py-1 bg-slate-300 rounded text-slate-700 font-bold text-[10px]"
                            >
                              বাতিল
                            </button>
                            <button
                              type="button"
                              onClick={() => saveStatusChange(member.id)}
                              className="flex-1 py-1 bg-indigo-600 text-white rounded font-bold text-[10px]"
                            >
                              হালনাগাদ (Update)
                            </button>
                          </div>
                        </div>
                      )}

                      {member.status === 'inactive' && member.inactiveReason && (
                        <div className="bg-rose-50/50 text-rose-800 p-2 border border-rose-100 rounded-lg mt-2 text-[10px] font-extrabold flex items-center gap-1 shrink-0">
                          <XCircle className="w-3.5 h-3.5 text-rose-500" />
                          <span>নিষ্ক্রিয় কারণ: {member.inactiveReason}</span>
                        </div>
                      )}
                    </div>

                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

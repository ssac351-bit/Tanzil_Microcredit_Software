import React, { useState, useEffect } from 'react';
import { Group, Member, Organization, Staff, Holiday } from '../types';
import { 
  Calendar, User, FileText, ArrowLeft, Save, Info, AlertTriangle, 
  Settings, Plus, Trash2, ListOrdered, ChevronDown, ChevronUp, CheckCircle2,
  Edit
} from 'lucide-react';

export interface LoanProductConfig {
  id: string;
  name: string;
  durationMonths: number;
  installmentsCount: number;
  serviceChargeRate: number; // e.g. 0.15 for 15%
  type: 'সাপ্তাহিক' | 'মাসিক' | 'মেয়াদি';
}

const DEFAULT_LOAN_PRODUCTS: LoanProductConfig[] = [
  { id: 'lp-jagoron', name: 'জাগরণ (ক্ষুদ্র ব্যবসা ঋণ)', durationMonths: 12, installmentsCount: 46, serviceChargeRate: 0.15, type: 'সাপ্তাহিক' },
  { id: 'lp-agroshor', name: 'অগ্রসর (উদ্যোক্তা ঋণ)', durationMonths: 12, installmentsCount: 46, serviceChargeRate: 0.15, type: 'সাপ্তাহিক' },
  { id: 'lp-sufolon', name: 'সুফলন (কৃষি চাষাবাদ ঋণ)', durationMonths: 6, installmentsCount: 24, serviceChargeRate: 0.12, type: 'সাপ্তাহিক' },
  { id: 'lp-buniad', name: 'বুনিয়াদ (অতিদরিদ্র ও দুস্থ সহায়তা)', durationMonths: 12, installmentsCount: 46, serviceChargeRate: 0.10, type: 'সাপ্তাহিক' },
  { id: 'lp-livestock', name: 'গাভী পালন ও মৎস্য ডেইরি', durationMonths: 12, installmentsCount: 46, serviceChargeRate: 0.15, type: 'সাপ্তাহিক' },
  { id: 'lp-monthly-special', name: 'মাসিক কিস্তি ঋণ স্কিম', durationMonths: 12, installmentsCount: 12, serviceChargeRate: 0.15, type: 'মাসিক' },
  { id: 'lp-term-3m', name: 'মেয়াদি ঋণ স্কিম (৩ মাস)', durationMonths: 3, installmentsCount: 1, serviceChargeRate: 0.04, type: 'মেয়াদি' },
  { id: 'lp-term-6m', name: 'মেয়াদি ঋণ স্কিম (৬ মাস)', durationMonths: 6, installmentsCount: 1, serviceChargeRate: 0.08, type: 'মেয়াদি' }
];

// Helper to parse workingDay to Date object safely
function parseWorkingDay(dayStr: string): Date {
  if (!dayStr) return new Date();
  const parts = dayStr.split('-');
  if (parts.length === 3) {
    if (parts[2].length === 4) {
      // DD-MM-YYYY
      return new Date(Number(parts[2]), Number(parts[1]) - 1, Number(parts[0]));
    } else if (parts[0].length === 4) {
      // YYYY-MM-DD
      return new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
    }
  }
  const timestamp = Date.parse(dayStr);
  return isNaN(timestamp) ? new Date() : new Date(timestamp);
}

// Helper to format Date to DD-MM-YYYY
function formatDateToDDMMYYYY(date: Date): string {
  const dd = String(date.getDate()).padStart(2, '0');
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const yyyy = date.getFullYear();
  return `${dd}-${mm}-${yyyy}`;
}

// Helper to format Date to YYYY-MM-DD for standard html inputs
function formatDateToYYYYMMDD(date: Date): string {
  const dd = String(date.getDate()).padStart(2, '0');
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const yyyy = date.getFullYear();
  return `${yyyy}-${mm}-${dd}`;
}

interface LoanProposalViewProps {
  onBack: () => void;
  branchGroups: Group[];
  groupMembers: Member[];
  workingDay: string;
  org: Organization;
  staff: Staff;
  defaultGroupId?: string;
  onSuccess: () => void;
  holidays: Holiday[];
}

export function LoanProposalView({
  onBack,
  branchGroups,
  groupMembers,
  workingDay,
  org,
  staff,
  defaultGroupId = '',
  onSuccess,
  holidays
}: LoanProposalViewProps) {
  const [selectedGroupId, setSelectedGroupId] = useState(defaultGroupId);
  const [selectedMemberId, setSelectedMemberId] = useState('');
  const [loanPurpose, setLoanPurpose] = useState('ক্ষুদ্র ব্যবসা');
  const [proposedAmount, setProposedAmount] = useState('');
  const [remarks, setRemarks] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // --- Dynamic Configuration State (loaded from localStorage with pre-filled fallbacks) ---
  const [productConfigs, setProductConfigs] = useState<LoanProductConfig[]>(() => {
    const saved = localStorage.getItem(`tanzil_loan_product_configs_${org.id}`);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return DEFAULT_LOAN_PRODUCTS;
  });

  const [selectedProductId, setSelectedProductId] = useState<string>(productConfigs[0]?.id || 'lp-jagoron');
  const selectedProduct = productConfigs.find((p) => p.id === selectedProductId) || productConfigs[0];

  // Specific variables auto-derived from selected config
  const [interestRate, setInterestRate] = useState(0.15);
  const [installmentsCount, setInstallmentsCount] = useState('46');
  const [loanDurationMonths, setLoanDurationMonths] = useState(12);
  const [loanType, setLoanType] = useState<'সাপ্তাহিক' | 'মাসিক' | 'মেয়াদি'>('সাপ্তাহিক');
  const [installmentAmount, setInstallmentAmount] = useState('0');
  const [interestMethod, setInterestMethod] = useState<'reducing' | 'flat'>('reducing');

  // Override config controls
  const [isCustomConfig, setIsCustomConfig] = useState(false);
  const [showConfigPanel, setShowConfigPanel] = useState(false);

  // New configuration creation inputs
  const [newProdName, setNewProdName] = useState('');
  const [newProdDuration, setNewProdDuration] = useState('12');
  const [newProdInstallments, setNewProdInstallments] = useState('46');
  const [newProdRate, setNewProdRate] = useState('15');
  const [newProdType, setNewProdType] = useState<'সাপ্তাহিক' | 'মাসিক' | 'মেয়াদি'>('সাপ্তাহিক');

  // --- Product Editing State ---
  const [editingProductId, setEditingProductId] = useState<string | null>(null);

  // --- Expected Disbursement Date ---
  const [expectedDisburseDate, setExpectedDisburseDate] = useState<string>(() => {
    const defaultDate = parseWorkingDay(workingDay);
    // Add 3 days as recommended default expected disbursement
    defaultDate.setDate(defaultDate.getDate() + 3);
    return formatDateToYYYYMMDD(defaultDate);
  });

  // --- Interactive Repayment Schedule Table ---
  const [calculatedSchedule, setCalculatedSchedule] = useState<any[] | null>(null);
  const [showScheduleResult, setShowScheduleResult] = useState(false);

  // Synchronize dynamic parameters when pre-set configurations are chosen (unless in custom mode)
  useEffect(() => {
    if (selectedProduct && !isCustomConfig) {
      setInterestRate(selectedProduct.serviceChargeRate);
      setInstallmentsCount(String(selectedProduct.installmentsCount));
      setLoanDurationMonths(selectedProduct.durationMonths);
      setLoanType(selectedProduct.type);
    }
  }, [selectedProductId, selectedProduct, isCustomConfig]);

  // Persist product configurations securely on catalog change
  useEffect(() => {
    localStorage.setItem(`tanzil_loan_product_configs_${org.id}`, JSON.stringify(productConfigs));
  }, [productConfigs, org.id]);

  // Real-time recalculation of installment and interest based on selected methods
  const principal = Number(proposedAmount) || 0;
  const count = Number(installmentsCount) || 46;

  // Compute actual periodic rate for reducing balance calculation
  let periodicRate = 0;
  if (loanType === 'সাপ্তাহিক') {
    const annualizedRate = interestRate * (12 / loanDurationMonths);
    periodicRate = annualizedRate / 52;
  } else if (loanType === 'মাসিক') {
    const annualizedRate = interestRate * (12 / loanDurationMonths);
    periodicRate = annualizedRate / 12;
  } else {
    periodicRate = interestRate; // মেয়াদি flat/simple period
  }

  // Calculate Amortized EMI installment
  let calculatedInstallment = 0;
  let totalPayable = 0;
  let simulatedInterest = 0;

  if (principal > 0 && count > 0) {
    if (interestMethod === 'reducing') {
      if (loanType === 'মেয়াদি' || count === 1) {
        simulatedInterest = Math.round(principal * periodicRate);
        totalPayable = principal + simulatedInterest;
        calculatedInstallment = totalPayable;
      } else {
        if (periodicRate > 0) {
          const x = Math.pow(1 + periodicRate, count);
          const rawInstallment = principal * (periodicRate * x) / (x - 1);
          calculatedInstallment = Math.round(rawInstallment);
        } else {
          calculatedInstallment = Math.round(principal / count);
        }

        let tempRemaining = principal;
        let cumulativeInterest = 0;
        for (let j = 1; j <= count; j++) {
          const stepInterest = Math.round(tempRemaining * periodicRate);
          let stepPrincipal = calculatedInstallment - stepInterest;
          if (j === count) {
            stepPrincipal = tempRemaining;
          }
          tempRemaining -= stepPrincipal;
          cumulativeInterest += stepInterest;
        }
        simulatedInterest = cumulativeInterest;
        totalPayable = principal + simulatedInterest;
      }
    } else {
      simulatedInterest = Math.round(principal * interestRate);
      totalPayable = principal + simulatedInterest;
      calculatedInstallment = count > 0 ? Math.round(totalPayable / count) : 0;
    }
  }

  useEffect(() => {
    setInstallmentAmount(String(calculatedInstallment));
    setCalculatedSchedule(null);
    setShowScheduleResult(false);
  }, [proposedAmount, installmentsCount, interestRate, calculatedInstallment, interestMethod, loanType]);

  // Sync selected group from default prop
  useEffect(() => {
    if (defaultGroupId) {
      setSelectedGroupId(defaultGroupId);
    }
  }, [defaultGroupId]);

  // Group and member bindings
  const selectedGroup = branchGroups.find((g) => g.id === selectedGroupId);
  const activeMembersInGroup = groupMembers.filter(
    (m) => m.groupId === selectedGroupId && (m.status === 'active' || !m.status)
  );
  const selectedMember = activeMembersInGroup.find((m) => m.id === selectedMemberId);

  // --- Dynamic Schedule Generator Engine ---
  const handleLoadSchedule = () => {
    if (principal <= 0) {
      setErrorMsg('দয়া করে প্রথমে প্রস্তাবিত ঋণের পরিমাণ ইনপুট করুন!');
      return;
    }
    setErrorMsg(null);

    const countVal = Number(installmentsCount) || 46;
    if (countVal <= 0) {
      setErrorMsg('কিস্তির সংখ্যা অবশ্যই শূন্য থেকে বেশি হতে হবে!');
      return;
    }

    const schedList = [];
    let remainingPrincipal = principal;
    const disburseBase = new Date(expectedDisburseDate);

    // Helper functions for Bengali Weekday & Holiday Determination
    const getBengaliDayOfWeek = (d: Date): string => {
      const dayNames = ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'];
      return dayNames[d.getDay()];
    };

    const checkIsHoliday = (d: Date, holidayList: Holiday[]): boolean => {
      if (!Array.isArray(holidayList)) return false;
      const dateStr = d.toISOString().split('T')[0];
      const bDay = getBengaliDayOfWeek(d);
      
      return holidayList.some(h => {
        if (h.type === 'direct') {
          return h.date === dateStr;
        } else if (h.type === 'general') {
          return h.dayOfWeek === bDay;
        }
        return false;
      });
    };

    // Adjusted holiday helper
    const getAdjustedDate = (baseDate: Date, i: number, loanType: 'সাপ্তাহিক' | 'মাসিক' | 'মেয়াদি', previousDate?: Date): Date => {
       if (loanType === 'সাপ্তাহিক') {
         // Weekly installments are computed sequentially from previous date
         let start = previousDate ? new Date(previousDate) : new Date(baseDate);
         let d = new Date(start);
         d.setDate(d.getDate() + 7);
         
         // If holiday, push by 7 days repeatedly to ensure "সাপ্তাহিক কিস্তি কিন্তু পিছিয়ে যায়" and "পরের সপ্তাহে কিন্তু ডাবল ধরবে না"
         // This means it pushes to the next week (and all subsequent dates push forward)
         while (checkIsHoliday(d, holidays)) {
           d.setDate(d.getDate() + 7);
         }
         return d;
       } else if (loanType === 'মাসিক') {
         // Monthly is calculated from baseDate + i months
         let d = new Date(baseDate);
         d.setMonth(d.getMonth() + i);
         
         if (checkIsHoliday(d, holidays)) {
           const origMonth = d.getMonth();
           // Try previous week (7 days before)
           const prevD = new Date(d);
           prevD.setDate(prevD.getDate() - 7);
           if (prevD.getMonth() === origMonth && !checkIsHoliday(prevD, holidays)) {
             return prevD;
           }
           
           // Try next week (7 days after)
           const nextD = new Date(d);
           nextD.setDate(nextD.getDate() + 7);
           if (nextD.getMonth() === origMonth && !checkIsHoliday(nextD, holidays)) {
             return nextD;
           }
           
           // If neither works, shift day-by-day until a non-holiday is found
           const fallbackD = new Date(d);
           while (checkIsHoliday(fallbackD, holidays)) {
             fallbackD.setDate(fallbackD.getDate() + 1);
           }
           return fallbackD;
         }
         return d;
       } else {
         // Term / মেয়াদি
         let d = new Date(baseDate);
         d.setMonth(d.getMonth() + i);
         while (checkIsHoliday(d, holidays)) {
           d.setDate(d.getDate() + 1);
         }
         return d;
       }
    };

    if (interestMethod === 'reducing') {
      if (loanType === 'মেয়াদি' || countVal === 1) {
        const stepInterest = Math.round(principal * periodicRate);
        const stepTotal = principal + stepInterest;
        const dueDate = getAdjustedDate(disburseBase, loanDurationMonths, loanType);
        
        schedList.push({
          installmentNo: 1,
          dueDate: formatDateToDDMMYYYY(dueDate),
          principal: principal,
          interest: stepInterest,
          total: stepTotal,
          remaining: 0
        });
      } else {
        let previousDueDate = new Date(disburseBase);
        for (let i = 1; i <= countVal; i++) {
          const dueDate = getAdjustedDate(disburseBase, i, loanType, previousDueDate);
          previousDueDate = dueDate;

          const stepInterest = Math.round(remainingPrincipal * periodicRate);
          let stepPrincipal = calculatedInstallment - stepInterest;
          let stepTotal = calculatedInstallment;

          if (i === countVal) {
            stepPrincipal = remainingPrincipal;
            stepTotal = stepPrincipal + stepInterest;
          }

          remainingPrincipal -= stepPrincipal;

          schedList.push({
            installmentNo: i,
            dueDate: formatDateToDDMMYYYY(dueDate),
            principal: stepPrincipal,
            interest: stepInterest,
            total: stepTotal,
            remaining: Math.max(0, remainingPrincipal)
          });
        }
      }
    } else {
      const basePrincipal = Math.floor(principal / countVal);
      const baseInterest = Math.floor(simulatedInterest / countVal);
      const baseInstallment = basePrincipal + baseInterest;

      let remainingTotalPayable = totalPayable;
      remainingPrincipal = principal;

      let previousDueDate = new Date(disburseBase);
      for (let i = 1; i <= countVal; i++) {
        const dueDate = getAdjustedDate(disburseBase, i, loanType, previousDueDate);
        previousDueDate = dueDate;

        let currentInstallmentAmount = baseInstallment;
        let currentPrincipalValue = basePrincipal;
        let currentInterestValue = baseInterest;

        if (i === countVal) {
          currentInstallmentAmount = remainingTotalPayable;
          currentPrincipalValue = remainingPrincipal;
          currentInterestValue = currentInstallmentAmount - currentPrincipalValue;
        }

        remainingPrincipal -= currentPrincipalValue;
        remainingTotalPayable -= currentInstallmentAmount;

        schedList.push({
          installmentNo: i,
          dueDate: formatDateToDDMMYYYY(dueDate),
          principal: currentPrincipalValue,
          interest: currentInterestValue,
          total: currentInstallmentAmount,
          remaining: Math.max(0, remainingPrincipal)
        });
      }
    }

    setCalculatedSchedule(schedList);
    setShowScheduleResult(true);
  };

  // --- Config Management Actions ---
  const handleAddNewProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProdName.trim()) return;

    const ratePct = Number(newProdRate) || 0;
    
    if (editingProductId) {
      // Edit existing product config
      const updated = productConfigs.map((p) => {
        if (p.id === editingProductId) {
          return {
            ...p,
            name: newProdName.trim(),
            durationMonths: Number(newProdDuration) || 12,
            installmentsCount: Number(newProdInstallments) || 46,
            serviceChargeRate: ratePct / 100,
            type: newProdType
          };
        }
        return p;
      });
      setProductConfigs(updated);
      setSelectedProductId(editingProductId);
      setEditingProductId(null);
    } else {
      // Add new product config
      const newProduct: LoanProductConfig = {
        id: `lp-custom-${Date.now()}`,
        name: newProdName.trim(),
        durationMonths: Number(newProdDuration) || 12,
        installmentsCount: Number(newProdInstallments) || 46,
        serviceChargeRate: ratePct / 100,
        type: newProdType
      };

      const updated = [...productConfigs, newProduct];
      setProductConfigs(updated);
      setSelectedProductId(newProduct.id);
    }

    setIsCustomConfig(false);

    // Reset fields
    setNewProdName('');
    setNewProdDuration('12');
    setNewProdInstallments('46');
    setNewProdRate('15');
    setNewProdType('সাপ্তাহিক');
  };

  const handleEditProduct = (cfg: LoanProductConfig) => {
    setEditingProductId(cfg.id);
    setNewProdName(cfg.name);
    setNewProdType(cfg.type);
    setNewProdDuration(String(cfg.durationMonths));
    setNewProdInstallments(String(cfg.installmentsCount));
    setNewProdRate(String(Math.round(cfg.serviceChargeRate * 100)));
  };

  const handleDeleteProduct = (idToDelete: string) => {
    if (productConfigs.length <= 1) {
      alert('সিস্টেমে নূন্যতম একটি কনফিগারেশন স্কিম অবশ্যই থাকতে হবে!');
      return;
    }
    const filtered = productConfigs.filter((p) => p.id !== idToDelete);
    setProductConfigs(filtered);
    if (selectedProductId === idToDelete) {
      setSelectedProductId(filtered[0].id);
    }
    if (editingProductId === idToDelete) {
      setEditingProductId(null);
    }
  };

  const handleResetToDefaultConfigs = () => {
    if (window.confirm('নিশ্চিত আপনি কি লোন স্কিম কনফিগারেশন ডিফল্ট অবস্থায় ফিরিয়ে নিতে চান?')) {
      setProductConfigs(DEFAULT_LOAN_PRODUCTS);
      setSelectedProductId(DEFAULT_LOAN_PRODUCTS[0].id);
      setIsCustomConfig(false);
    }
  };

  // --- Save Proposal ---
  const handleSaveProposal = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!selectedGroupId) {
      setErrorMsg('দয়া করে একটি সমিতি/গ্রুপ নির্বাচন করুন!');
      return;
    }
    if (!selectedMemberId || !selectedMember) {
      setErrorMsg('দয়া করে ঋণ গ্রহণের জন্য একজন সচল সদস্য নির্বাচন করুন!');
      return;
    }
    if (principal <= 0) {
      setErrorMsg('ঋণের পরিমাণ অবশ্যই ৫,০০০ টাকার বেশি হতে হবে!');
      return;
    }
    if (principal > 200000) {
      setErrorMsg('ঋণের সর্বোচ্চ সীমা ২,০০,০০০ টাকা!');
      return;
    }
    if (!expectedDisburseDate) {
      setErrorMsg('দয়া করে সম্ভাব্য ঋণ বিতরণের তারিখ সিলেক্ট করুন!');
      return;
    }

    // Get existing proposals to check if any pending proposal exists for this member
    const propKey = `tanzil_loan_proposals_${org.id}`;
    const savedProps = localStorage.getItem(propKey);
    const existingProps = savedProps ? JSON.parse(savedProps) : [];

    const hasPending = existingProps.some(
      (p: any) => p.memberId === selectedMember.id && p.status === 'pending'
    );

    if (hasPending) {
      setErrorMsg('এই সদস্যের একটি পূর্ববর্তী ঋণ প্রস্তাব ইতিমধ্যে শাখা ব্যবস্থাপকের অনুমোদনের জন্য অপেক্ষমাণ আছে!');
      return;
    }

    const formattedExpectedDate = formatDateToDDMMYYYY(new Date(expectedDisburseDate));

    const newProposal = {
      id: `prop-${Date.now()}`,
      orgId: org.id,
      branchId: staff.branchId || 'default-branch',
      memberId: selectedMember.id,
      memberName: selectedMember.name,
      memberIdText: selectedMember.memberId,
      memberPhone: selectedMember.phone,
      groupId: selectedGroupId,
      groupName: selectedGroup?.name || 'অজ্ঞাত গ্রুপ',
      groupCode: selectedGroup?.code || 'GRP',
      amount: principal,
      interestAmount: Math.round(principal * interestRate),
      totalPayable: totalPayable,
      installmentsCount: count,
      installmentAmount: Number(installmentAmount) || calculatedInstallment,
      purpose: loanPurpose,
      proposalDate: workingDay, // ওর্য়াকি ডে অনুযায়ী
      expectedDisburseDate: formattedExpectedDate,
      remarks: remarks.trim(),
      status: 'pending',
      createdBy: staff.name,
      createdById: staff.staffId || staff.id,
      loanSchemeName: selectedProduct?.name || 'কাস্টম',
      loanConfigType: loanType,
      loanDurationMonths: loanDurationMonths,
      serviceChargeRate: interestRate
    };

    const updatedProps = [newProposal, ...existingProps];
    localStorage.setItem(propKey, JSON.stringify(updatedProps));

    onSuccess();
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-4 sm:p-6 max-w-2xl mx-auto space-y-6">
      {/* Back button and Title */}
      <div className="flex justify-between items-center border-b border-slate-100 pb-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-amber-50 text-amber-600 rounded-lg">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-extrabold text-slate-800 text-sm sm:text-base">সদস্য ঋণ প্রস্তাব ফর্ম (Loan Proposal)</h3>
            <p className="text-[10px] text-slate-400 font-medium">কনফিগারেশন প্রোডাক্ট ক্যাটাগরি ও পেমেন্ট সিডিউল সেটআপ</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setShowConfigPanel(!showConfigPanel)}
            className="text-xs text-indigo-600 hover:text-indigo-800 font-bold flex items-center gap-1 cursor-pointer bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 px-3 py-1.5 rounded-xl transition-all"
          >
            <Settings size={14} /> কনফিগার সেটিংস  
          </button>
          <button
            type="button"
            onClick={onBack}
            className="text-xs text-slate-500 hover:text-slate-700 font-bold flex items-center gap-1 cursor-pointer bg-slate-50 hover:bg-slate-100 border border-slate-200 px-3 py-1.5 rounded-xl transition-all"
          >
            <ArrowLeft size={14} /> ফিরে যান
          </button>
        </div>
      </div>

      {/* Dynamic Loan Configurator Settings Drawer (localStorage CRUD) */}
      {showConfigPanel && (
        <div className="bg-slate-50 rounded-2xl border border-slate-200 p-4 space-y-4 animate-in slide-in-from-top duration-300">
          <div className="flex justify-between items-center border-b border-slate-200 pb-2">
            <h4 className="text-xs font-black text-slate-800 flex items-center gap-1.5 uppercase">
              <Settings className="w-4 h-4 text-indigo-500" />
              ঋণ প্রোডাক্ট গ্লোবাল কনফিগার তালিকা (Configurations)
            </h4>
            <button 
              type="button"
              onClick={handleResetToDefaultConfigs}
              className="text-[10px] bg-amber-100 hover:bg-amber-200 text-amber-800 font-bold px-2.5 py-1 rounded"
            >
              ডিফল্ট রিসেট করুন
            </button>
          </div>

          {/* Current Configs Table */}
          <div className="max-h-52 overflow-y-auto border border-slate-200 rounded-lg bg-white">
            <table className="w-full text-left border-collapse text-[11px]">
              <thead>
                <tr className="bg-slate-150 border-b border-slate-200 font-black text-slate-700">
                  <th className="p-2">প্রোডাক্ট নাম</th>
                  <th className="p-2 text-center">মেয়াদ (মাস)</th>
                  <th className="p-2 text-center">কিস্তি</th>
                  <th className="p-2 text-center">সার্ভিস ফি %</th>
                  <th className="p-2 text-center">ধরনের</th>
                  <th className="p-2 text-right">কার্যক্রম</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-bold text-slate-650">
                {productConfigs.map((cfg) => (
                  <tr key={cfg.id} className="hover:bg-slate-50">
                    <td className="p-2 text-slate-800">{cfg.name}</td>
                    <td className="p-2 text-center">{cfg.durationMonths} মাস</td>
                    <td className="p-2 text-center">{cfg.installmentsCount} টি</td>
                    <td className="p-2 text-center font-mono">{(cfg.serviceChargeRate * 100).toFixed(0)}%</td>
                    <td className="p-2 text-center text-indigo-600">{cfg.type}</td>
                    <td className="p-2 text-right space-x-1.5">
                      <button
                        type="button"
                        onClick={() => handleEditProduct(cfg)}
                        className="text-indigo-600 hover:text-indigo-800 cursor-pointer"
                        title="সম্পাদনা করুন"
                      >
                        <Edit size={13} className="inline" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteProduct(cfg.id)}
                        className="text-rose-600 hover:text-rose-800 cursor-pointer"
                        title="রিমুভ করুন"
                      >
                        <Trash2 size={13} className="inline" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Add / Edit custom configured option */}
          <form onSubmit={handleAddNewProduct} className="bg-white border border-slate-200 rounded-xl p-3 space-y-3">
            <div className="flex justify-between items-center">
              <h5 className="text-[10px] font-black text-[#2f6ce5] uppercase">
                {editingProductId ? 'লোন প্রোডাক্ট তথ্য সম্পাদনা করুন (সম্পাদনা মোড):' : 'নতুন ঋণ প্রোডাক্ট কনফিগার করুন:'}
              </h5>
              {editingProductId && (
                <button
                  type="button"
                  onClick={() => {
                    setEditingProductId(null);
                    setNewProdName('');
                    setNewProdType('সাপ্তাহিক');
                    setNewProdDuration('12');
                    setNewProdInstallments('46');
                    setNewProdRate('15');
                  }}
                  className="text-[9px] text-[#2f6ce5] hover:underline font-bold"
                >
                  সম্পাদনা বাতিল
                </button>
              )}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[9px] font-bold text-slate-500 uppercase mb-0.5">প্রোডাক্ট নাম *</label>
                <input
                  type="text"
                  placeholder="যেমন: অগ্রসর-বি (নারী উদোক্তা)"
                  value={newProdName}
                  onChange={(e) => setNewProdName(e.target.value)}
                  className="w-full px-2 py-1.5 border border-slate-250 rounded text-[11px] font-bold"
                  required
                />
              </div>
              <div>
                <label className="block text-[9px] font-bold text-slate-500 uppercase mb-0.5">কিস্তি ধরণ</label>
                <select
                  value={newProdType}
                  onChange={(e) => {
                    const val = e.target.value as any;
                    setNewProdType(val);
                    if (val === 'মেয়াদি') {
                      setNewProdDuration('3');
                      setNewProdInstallments('1');
                    } else if (val === 'মাসিক') {
                      setNewProdDuration('12');
                      setNewProdInstallments('12');
                    } else {
                      setNewProdDuration('12');
                      setNewProdInstallments('46');
                    }
                  }}
                  className="w-full px-2 py-1.5 border border-slate-250 rounded text-[11px] font-bold bg-white"
                >
                  <option value="সাপ্তাহিক">সাপ্তাহিক</option>
                  <option value="মাসিক">মাসিক</option>
                  <option value="মেয়াদি">মেয়াদি</option>
                </select>
              </div>
              <div>
                <label className="block text-[9px] font-bold text-slate-500 uppercase mb-0.5">মেয়াদকাল (মাস)</label>
                <select
                  value={newProdDuration}
                  onChange={(e) => {
                    const val = e.target.value;
                    setNewProdDuration(val);
                    const dur = Number(val);
                    if (newProdType === 'মেয়াদি') {
                      setNewProdInstallments('1');
                    } else if (newProdType === 'মাসিক') {
                      setNewProdInstallments(String(dur));
                    } else {
                      setNewProdInstallments(String(Math.round(dur * 4.34)));
                    }
                  }}
                  className="w-full px-2 py-1.5 border border-slate-250 rounded text-[11px] font-bold bg-white"
                >
                  {newProdType === 'মেয়াদি' ? (
                    <>
                      <option value="3">৩ মাস</option>
                      <option value="6">৬ মাস</option>
                    </>
                  ) : (
                    <>
                      <option value="3">৩ মাস</option>
                      <option value="6">৬ মাস</option>
                      <option value="12">১২ মাস</option>
                      <option value="18">১৮ মাস</option>
                      <option value="24">২৪ মাস</option>
                    </>
                  )}
                </select>
              </div>
              <div>
                <label className="block text-[9px] font-bold text-slate-500 uppercase mb-0.5">নির্দিষ্ট কিস্তি সংখ্যা</label>
                <input
                  type="number"
                  value={newProdInstallments}
                  onChange={(e) => setNewProdInstallments(e.target.value)}
                  className="w-full px-2 py-1.5 border border-slate-250 rounded text-[11px] font-bold"
                  min="1"
                  required
                />
              </div>
              <div>
                <label className="block text-[9px] font-bold text-slate-500 uppercase mb-0.5">সার্ভিস চার্জ হার (%)</label>
                <input
                  type="number"
                  placeholder="যেমন: 15"
                  value={newProdRate}
                  onChange={(e) => setNewProdRate(e.target.value)}
                  className="w-full px-2 py-1.5 border border-slate-250 rounded text-[11px] font-bold"
                  min="0"
                  max="100"
                  required
                />
              </div>
              <div className="flex items-end">
                <button
                  type="submit"
                  className="w-full py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded font-bold text-[10px] flex items-center justify-center gap-1 cursor-pointer"
                >
                  {editingProductId ? <Save size={12} /> : <Plus size={12} />}
                  {editingProductId ? 'তথ্য হালনাগাদ করুন' : 'কনফিগার যুক্ত করুন'}
                </button>
              </div>
            </div>
          </form>
        </div>
      )}

      <form onSubmit={handleSaveProposal} className="space-y-5">
        {errorMsg && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs sm:text-xs font-bold flex items-start gap-2 animate-in fade-in">
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{errorMsg}</span>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Section 1: Group Selection */}
          <div>
            <label className="block text-[11px] font-extrabold text-slate-500 uppercase mb-1">১. সমিতি / গ্রুপ নির্বাচন করুন *</label>
            <select
              value={selectedGroupId}
              onChange={(e) => {
                setSelectedGroupId(e.target.value);
                setSelectedMemberId('');
              }}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-250 hover:border-[#2f6ce5]/50 focus:border-[#2f6ce5] rounded-xl text-xs sm:text-xs font-bold focus:outline-none focus:ring-1 focus:ring-[#2f6ce5] bg-white transition-all cursor-pointer"
              required
            >
              <option value="">-- সমিতি নির্বাচন করুন --</option>
              {branchGroups.map((g) => (
                <option key={g.id} value={g.id}>
                  {g.name} ({g.code}) — বৈঠক বার: {g.meetingDay || 'শনিবার'}
                </option>
              ))}
            </select>
          </div>

          {/* Section 2: Member Selection */}
          <div>
            <label className="block text-[11px] font-extrabold text-slate-500 uppercase mb-1">২. সচল সদস্য নির্বাচন করুন *</label>
            <select
              value={selectedMemberId}
              onChange={(e) => setSelectedMemberId(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-250 hover:border-[#2f6ce5]/50 focus:border-[#2f6ce5] rounded-xl text-xs sm:text-xs font-bold focus:outline-none focus:ring-1 focus:ring-[#2f6ce5] bg-white transition-all cursor-pointer"
              disabled={!selectedGroupId}
              required
            >
              <option value="">-- সদস্য নির্বাচন করুন --</option>
              {activeMembersInGroup.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name} ({m.memberId}) {m.plOutstanding && m.plOutstanding > 0 ? `| বকেয়া: ${m.plOutstanding}৳` : ''}
                </option>
              ))}
            </select>
            {!selectedGroupId && (
              <span className="text-[10px] text-amber-600 font-semibold mt-1 block">প্রথমে একটি সমিতি সিলেক্ট করুন।</span>
            )}
          </div>
        </div>

        {/* Selected Member Mini-ledger Board */}
        {selectedMember && (
          <div className="bg-slate-50/60 rounded-2xl border border-slate-200/80 p-4 animate-in fade-in flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
            <div className="space-y-1">
              <div className="flex items-center gap-1.5">
                <User className="w-4 h-4 text-slate-500" />
                <span className="text-slate-800 font-black text-sm">{selectedMember.name}</span>
                <span className="text-[10px] bg-slate-200 border border-slate-300 text-slate-700 px-1.5 py-0.5 rounded-md font-mono font-bold">
                  {selectedMember.memberId}
                </span>
              </div>
              <div className="text-[11px] text-slate-500 font-bold space-y-0.5">
                <div>মোবাইল: <strong className="text-slate-700 font-mono">{selectedMember.phone || 'N/A'}</strong></div>
                <div>পিতা/স্বামী: <strong className="text-slate-700">{selectedMember.fatherHusbandName || 'N/A'}</strong></div>
                <div>ঠিকানা: <strong className="text-slate-700">{selectedMember.village || selectedMember.address || 'N/A'}</strong></div>
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-3 flex flex-wrap gap-4 text-center justify-center shrink-0 min-w-full md:min-w-[200px]">
              <div>
                <div className="text-[9px] text-slate-400 font-bold uppercase">পূর্বের ঋণ বকেয়া</div>
                <div className={`text-xs font-black font-mono mt-0.5 ${Number(selectedMember.plOutstanding) > 0 ? 'text-rose-600' : 'text-slate-600'}`}>
                  {selectedMember.plOutstanding || 0} BDT
                </div>
              </div>
              <div className="border-l border-slate-200 pl-4">
                <div className="text-[9px] text-slate-400 font-bold uppercase"> সঞ্চয় ব্যালেন্স (GS)</div>
                <div className="text-xs font-black font-mono text-emerald-600 mt-0.5">
                  {selectedMember.gsBalance ?? selectedMember.savingsBalance ?? 0} BDT
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Configuration Binding & Selection Section */}
        <div className="bg-indigo-50/50 border border-indigo-100 rounded-2xl p-4 space-y-3">
          <div className="flex justify-between items-center">
            <h4 className="text-[11px] font-extrabold text-indigo-800 uppercase tracking-wider flex items-center gap-1.5">
              <Settings className="w-3.5 h-3.5" />
              ঋণ প্রোডাক্ট ও পলিসি নির্বাচন (কনফিগারেশন থেকে):
            </h4>
            <label className="flex items-center gap-1 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={isCustomConfig}
                onChange={(e) => {
                  setIsCustomConfig(e.target.checked);
                  if (!e.target.checked && selectedProduct) {
                    setInterestRate(selectedProduct.serviceChargeRate);
                    setInstallmentsCount(String(selectedProduct.installmentsCount));
                    setLoanDurationMonths(selectedProduct.durationMonths);
                    setLoanType(selectedProduct.type);
                  }
                }}
                className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 h-3.5 w-3.5"
              />
              <span className="text-[10px] font-extrabold text-slate-600">ম্যানুয়াল এডিট করুন</span>
            </label>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Choose pre-configured Product category */}
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">প্রোডাক্ট ক্যাটাগরি *</label>
              <select
                value={selectedProductId}
                onChange={(e) => {
                  setSelectedProductId(e.target.value);
                  setIsCustomConfig(false);
                }}
                disabled={isCustomConfig}
                className="w-full px-3 py-2 bg-white border border-indigo-200 rounded-xl text-xs font-bold cursor-pointer disabled:bg-slate-100 disabled:cursor-not-allowed"
              >
                {productConfigs.map((cfg) => (
                  <option key={cfg.id} value={cfg.id}>
                    {cfg.name} ({(cfg.serviceChargeRate * 100).toFixed(0)}% SC · {cfg.type})
                  </option>
                ))}
              </select>
            </div>

            {/* Custom/Pre-filled Service Charge Rate */}
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">সার্ভিস চার্জ / সেবা ফি হাব *</label>
              <div className="relative">
                <input
                  type="number"
                  value={Math.round(interestRate * 100)}
                  onChange={(e) => setInterestRate((Number(e.target.value) || 0) / 100)}
                  disabled={!isCustomConfig}
                  className="w-full px-3 py-2 bg-white border border-slate-250 rounded-xl text-xs font-bold disabled:bg-slate-100 disabled:text-slate-605"
                  step="1"
                  min="0"
                />
                <span className="absolute right-3.5 top-2 text-xs font-bold text-slate-400">%</span>
              </div>
            </div>

            {/* Service Charge calculation model selector */}
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">সার্ভিস চার্জ হিসাব পদ্ধতি</label>
              <select
                value={interestMethod}
                onChange={(e) => setInterestMethod(e.target.value as any)}
                disabled={!isCustomConfig}
                className="w-full px-3 py-2 bg-white border border-slate-250 rounded-xl text-xs font-bold disabled:bg-slate-100 disabled:text-slate-605 bg-white"
              >
                <option value="reducing">ক্রমহ্রাসমান পদ্ধতি (Reducing Balance)</option>
                <option value="flat">ফ্ল্যাট পদ্ধতি (Flat Rate)</option>
              </select>
            </div>

            {/* Custom/Pre-filled Installment Type */}
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">পরিশোধের ধরণ ও ফ্রিকোয়েন্সি</label>
              <select
                value={loanType}
                onChange={(e) => {
                  const val = e.target.value as any;
                  setLoanType(val);
                  if (val === 'মেয়াদি') {
                    if (loanDurationMonths !== 3 && loanDurationMonths !== 6) {
                      setLoanDurationMonths(3);
                    }
                    setInstallmentsCount('1');
                  } else if (val === 'মাসিক') {
                    setInstallmentsCount(String(loanDurationMonths));
                  } else {
                    setInstallmentsCount(String(Math.round(loanDurationMonths * 4.34)));
                  }
                }}
                disabled={!isCustomConfig}
                className="w-full px-3 py-2 bg-white border border-slate-250 rounded-xl text-xs font-bold disabled:bg-slate-100 disabled:text-slate-605 bg-white"
              >
                <option value="সাপ্তাহিক">সাপ্তাহিক (Weekly)</option>
                <option value="মাসিক">মাসিক (Monthly)</option>
                <option value="মেয়াদি">মেয়াদি (Term Loan)</option>
              </select>
            </div>

            {/* Configured Limit of installments & period */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">মেয়াদ (মাস)</label>
                <select
                  value={loanDurationMonths}
                  onChange={(e) => {
                    const dur = Number(e.target.value);
                    setLoanDurationMonths(dur);
                    if (loanType === 'মেয়াদি') {
                      setInstallmentsCount('1');
                    } else if (loanType === 'মাসিক') {
                      setInstallmentsCount(String(dur));
                    } else {
                      setInstallmentsCount(String(Math.round(dur * 4.34)));
                    }
                  }}
                  disabled={!isCustomConfig}
                  className="w-full px-3 py-2 bg-white border border-slate-250 rounded-xl text-xs font-bold text-center disabled:bg-slate-100 disabled:text-slate-650 bg-white"
                >
                  {loanType === 'মেয়াদি' ? (
                    <>
                      <option value={3}>৩ মাস</option>
                      <option value={6}>৬ মাস</option>
                    </>
                  ) : (
                    <>
                      <option value={3}>৩ মাস</option>
                      <option value={6}>৬ মাস</option>
                      <option value={12}>১২ মাস</option>
                      <option value={18}>১৮ মাস</option>
                      <option value={24}>২৪ মাস</option>
                    </>
                  )}
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">কিস্তি সংখ্যা *</label>
                <input
                  type="number"
                  value={installmentsCount}
                  onChange={(e) => setInstallmentsCount(e.target.value)}
                  disabled={!isCustomConfig}
                  className="w-full px-3 py-2 bg-white border border-slate-250 rounded-xl text-xs font-bold text-center disabled:bg-slate-100 disabled:text-slate-605"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Inputs section: Scheme sector, amounts, disbursement dates */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
          {/* Loan Purpose */}
          <div>
            <label className="block text-[11px] font-extrabold text-slate-500 uppercase mb-1">৩. ঋণের উদ্দেশ্য / খাত *</label>
            <select
              value={loanPurpose}
              onChange={(e) => setLoanPurpose(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-250 hover:border-[#2f6ce5]/50 focus:border-[#2f6ce5] rounded-xl text-xs sm:text-xs font-bold focus:outline-none focus:ring-1 focus:ring-[#2f6ce5] bg-white transition-all cursor-pointer"
            >
              <option value="ক্ষুদ্র ব্যবসা">ক্ষুদ্র ব্যবসা (Retail / Small Business)</option>
              <option value="कृষি চাষাবাদ">কৃষি চাষাবাদ (Agriculture)</option>
              <option value="গাভী পালন">গাভী পালন (Cow / Livestock Rearing)</option>
              <option value="মৎস্য চাষ">মৎস্য চাষ (Fish Farming)</option>
              <option value="গৃহ সংস্কার">গৃহ সংস্কার (Home Improvement)</option>
              <option value="অন্যান্য">অন্যান্য (Others)</option>
            </select>
          </div>

          {/* Proposed Amount */}
          <div>
            <label className="block text-[11px] font-extrabold text-[#2f6ce5] uppercase mb-1 font-sans">৪. প্রস্তাবিত ঋণের পরিমাণ (টাকা) *</label>
            <input
              type="text"
              placeholder="যেমন: ২০০০০"
              value={proposedAmount}
              onChange={(e) => setProposedAmount(e.target.value.replace(/\D/g, ''))}
              className="w-full px-3.5 py-2.5 border-2 border-indigo-100 hover:border-indigo-300 focus:border-[#2f6ce5] rounded-xl text-xs font-bold outline-none font-mono focus:ring-1 focus:ring-[#2f6ce5] transition-all bg-white"
              required
            />
          </div>

          {/* Expected Disbursement Date */}
          <div>
            <label className="block text-[11px] font-extrabold text-amber-600 uppercase mb-1 flex items-center gap-1 font-sans">
              <Calendar className="w-3.5 h-3.5" />
              ৫. সম্ভাব্য বিতরণ তারিখ *
            </label>
            <input
              type="date"
              value={expectedDisburseDate}
              onChange={(e) => {
                setExpectedDisburseDate(e.target.value);
                // invalidate loaded schedule to force recalculation click
                setCalculatedSchedule(null);
                setShowScheduleResult(false);
              }}
              className="w-full px-3.5 py-2 bg-white border-2 border-amber-100 hover:border-amber-300 focus:border-amber-500 rounded-xl text-xs font-bold focus:outline-none transition-all cursor-pointer"
              required
            />
          </div>

          {/* Workspace working day info (view only) */}
          <div>
            <label className="block text-[11px] font-extrabold text-slate-500 uppercase mb-1 flex items-center gap-1">
              ৬. প্রস্তাবের তারিখ (ওর্য়াকি ডে)
              <Info className="w-3.5 h-3.5 text-[#2f6ce5]" title="বর্তমান সচল কর্মদিবস অনুযায়ী নির্ধারণ" />
            </label>
            <div className="flex items-center bg-slate-100 text-slate-600 border border-slate-200 rounded-xl px-3.5 py-2.5 font-bold select-none cursor-not-allowed">
              <Calendar className="w-4 h-4 text-slate-400 mr-2" />
              <span className="text-xs font-mono">{workingDay}</span>
            </div>
          </div>
        </div>

        {/* Calculation Panel & Interactive Schedule Trigger Info */}
        {principal > 0 && (
          <div className="bg-emerald-50/70 border border-emerald-100 rounded-2xl p-4 space-y-3.5 animate-in slide-in-from-top-2 duration-200">
            <div className="flex justify-between items-center border-b border-emerald-100 pb-2">
              <h4 className="text-[11px] font-extrabold text-emerald-800 uppercase tracking-wider">রিয়েল-টাইম ঋণ পরিশোধের হিসাব বিবরণী:</h4>
              
              {/* Load Schedule Interactive Button */}
              <button
                type="button"
                onClick={handleLoadSchedule}
                className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[11px] font-black tracking-wide cursor-pointer shadow-sm hover:shadow transition-all flex items-center gap-1 font-sans"
              >
                <ListOrdered size={13} /> লোড সিডিউল 
              </button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-center">
              <div className="bg-white p-2 rounded-xl border border-emerald-100">
                <span className="text-[9px] text-slate-400 font-bold block">ঋণের আসল</span>
                <strong className="text-xs text-slate-800 font-mono">{principal} ৳</strong>
              </div>
              <div className="bg-white p-2 rounded-xl border border-emerald-100">
                <span className="text-[9px] text-slate-400 font-bold block">
                  সেবা ফি ({(interestRate * 100).toFixed(0)}% {interestMethod === 'reducing' ? 'ক্রমহ্রাসমান' : 'ফ্ল্যাট'})
                </span>
                <strong className="text-xs text-[#2f6ce5] font-mono">{simulatedInterest} ৳</strong>
              </div>
              <div className="bg-white p-2 rounded-xl border border-emerald-100">
                <span className="text-[9px] text-slate-400 font-bold block">মোট পরিশোধযোগ্য</span>
                <strong className="text-xs text-emerald-700 font-mono">{totalPayable} ৳</strong>
              </div>
              <div className="bg-white p-2 rounded-xl border border-emerald-100">
                <span className="text-[9px] text-slate-400 font-bold block">কিস্তির পরিমাণ (গড়ে)</span>
                <strong className="text-xs text-amber-700 font-mono">{calculatedInstallment} ৳</strong>
              </div>
            </div>
          </div>
        )}

        {/* Loaded Repayment Schedule List (gorgeous grid table representation) */}
        {showScheduleResult && calculatedSchedule && (
          <div className="bg-[#2f6ce5]/5 rounded-2xl border border-sky-100 p-4 space-y-3 animate-in fade-in duration-300">
            <div className="flex justify-between items-center border-b border-sky-200/50 pb-2">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 size={16} className="text-[#2f6ce5]" />
                <h4 className="text-[11px] font-black text-slate-800 uppercase tracking-wide">
                  উৎপন্ন ঋণ পরিশোধের কিস্তি সময়সূচী (Amortization Schedule)
                </h4>
              </div>
              <button 
                type="button" 
                onClick={() => setShowScheduleResult(false)}
                className="text-[10px] text-slate-405 font-bold hover:text-slate-600 px-1 hover:underline"
              >
                হাইড করুন
              </button>
            </div>

            <div className="max-h-56 overflow-y-auto border border-sky-100 rounded-xl bg-white">
              <table className="w-full text-left border-collapse text-[10px] xs:text-[11px]">
                <thead>
                  <tr className="bg-slate-100/80 border-b border-slate-200 font-black text-slate-650 sticky top-0">
                    <th className="p-2.5 text-center">কিস্তি নং</th>
                    <th className="p-2.5">পরিশোধের তারিখ (Due Date)</th>
                    <th className="p-2.5 text-right font-sans">আসল কিস্তি</th>
                    <th className="p-2.5 text-right font-sans">সার্ভিস কিস্তি</th>
                    <th className="p-2.5 text-right font-sans bg-amber-50 text-amber-900 border-x border-amber-100">মোট কিস্তি</th>
                    <th className="p-2.5 text-right font-sans">অবশিষ্ট আসল</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-bold text-slate-600">
                  {calculatedSchedule.map((row) => (
                    <tr key={row.installmentNo} className="hover:bg-slate-50/55">
                      <td className="p-2 text-center text-slate-500 font-mono">{row.installmentNo}</td>
                      <td className="p-2">
                        <span className="bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded font-mono font-bold text-[9px] xs:text-[10px]">
                          {row.dueDate}
                        </span>
                      </td>
                      <td className="p-2 text-right font-mono text-slate-705">{row.principal} ৳</td>
                      <td className="p-2 text-right font-mono text-indigo-500">{row.interest} ৳</td>
                      <td className="p-2 text-right font-mono bg-amber-50/40 text-amber-800 border-x border-amber-100 font-extrabold">
                        {row.total} ৳
                      </td>
                      <td className="p-2 text-right font-mono text-slate-500">{row.remaining} ৳</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex justify-between items-center text-[10px] text-slate-400 font-semibold px-1 pt-1 select-none">
              <span>মোট কিস্তি সংখ্যা: <strong className="text-slate-600">{installmentsCount} টি</strong></span>
              <span>বিতরণ হতে প্রথম কিস্তি পরিশোধের ধরণ: <strong className="text-[#2f6ce5]">{loanType}</strong></span>
              <span>{interestMethod === 'reducing' ? 'ক্রমহ্রাসমান' : 'ফ্ল্যাট'} মোট পরিশোধযোগ্য ঋণ: <strong className="text-emerald-700">{totalPayable} BDT</strong></span>
            </div>
          </div>
        )}

        {/* Remarks */}
        <div className="pt-1">
          <label className="block text-[11px] font-extrabold text-slate-500 uppercase mb-1">মন্তব্য (Remarks)</label>
          <textarea
            placeholder="বিশেষ তথ্য বা মন্তব্য থাকলে এখানে উল্লেখ করুন..."
            value={remarks}
            onChange={(e) => setRemarks(e.target.value)}
            className="w-full px-3.5 py-2 border border-slate-250 hover:border-slate-350 focus:border-[#2f6ce5] rounded-xl text-xs sm:text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-[#2f6ce5] h-18 bg-white"
          />
        </div>

        {/* Action buttons */}
        <div className="flex gap-3 pt-3">
          <button
            type="button"
            onClick={onBack}
            className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 rounded-2xl text-xs font-bold text-slate-600 transition-colors cursor-pointer"
          >
            বাতিল
          </button>
          <button
            type="submit"
            className="flex-1 py-3 bg-[#2f6ce5] hover:bg-[#1d59d1] text-white font-extrabold rounded-2xl text-xs shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer hover:shadow-lg"
          >
            <Save className="w-4 h-4" /> ঋণ প্রস্তাব সাবমিট করুন
          </button>
        </div>
      </form>
    </div>
  );
}

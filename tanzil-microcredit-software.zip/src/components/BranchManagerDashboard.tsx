/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Users, 
  CreditCard, 
  Layers, 
  Plus, 
  Edit, 
  Trash2, 
  ArrowLeft, 
  RefreshCw, 
  Calendar, 
  Check, 
  AlertCircle, 
  LogOut, 
  CheckCircle2, 
  UserCheck, 
  ShieldAlert, 
  ArrowLeftRight, 
  HelpCircle,
  FileText,
  UserX,
  BookOpen,
  DollarSign,
  Clock,
  Key,
  Building,
  X,
  Search,
  Sliders,
  CalendarRange,
  FileSpreadsheet,
  Save,
  Download,
  Upload,
  Cloud,
  FileClock,
  Banknote,
  HandCoins,
  Power,
  UserPlus,
  Coins,
  PiggyBank,
  ClipboardList,
  ChevronLeft,
  RotateCcw,
  Info
} from 'lucide-react';
import { Organization, Staff, Group, Branch, Holiday } from '../types';
import { MemberAdmissionForm } from './MemberAdmissionForm';
import { MemberInformationView } from './MemberInformationView';
import { MemberTransactionView } from './MemberTransactionView';
import { LoanProposalView } from './LoanProposalView';
import { LoanDisburseView } from './LoanDisburseView';
import { getDefaultHolidays } from '../utils/holidayHelper';

interface BranchManagerDashboardProps {
  org: Organization;
  staff: Staff; // Logged-in Branch Manager details
  onLogout: () => void;
}

export default function BranchManagerDashboard({ org, staff, onLogout }: BranchManagerDashboardProps) {
  const isBM = staff.designation === 'শাখা ব্যবস্থাপক';
  // Navigation states
  const [activeTab, setActiveTab] = useState<'dashboard' | 'hrm' | 'account' | 'holidays'>('dashboard');
  const [isFullScreenOperation, setIsFullScreenOperation] = useState(false);
  const [selectedOperation, setSelectedOperation] = useState<'menu' | 'add_group' | 'group_operation' | 'move_group' | 'loan_proposal_requests'>('menu');

  // Working day retrieved from localStorage
  const [workingDay, setWorkingDay] = useState<string>(() => {
    return localStorage.getItem(`tanzil_working_day_${org.id}`) || new Date().toISOString().split('T')[0];
  });

  // Topbar Action Change Password dialogs
  const [isChangePasswordModalOpen, setIsChangePasswordModalOpen] = useState(false);
  const [newPasswordVal, setNewPasswordVal] = useState('');
  const [confirmPasswordVal, setConfirmPasswordVal] = useState('');
  const [passwordChangeSuccess, setPasswordChangeSuccess] = useState('');

  // Load branches
  const [branchesList] = useState<Branch[]>(() => {
    const saved = localStorage.getItem(`tanzil_branches_${org.id}`);
    return saved ? JSON.parse(saved) : [];
  });

  const currentBranch = branchesList.find(b => b.id === staff.branchId);
  const currentBranchCode = currentBranch?.code || staff.branchId?.slice(-4) || 'HO';

  // Staff and Groups records synced with the Organization database
  const [staffList, setStaffList] = useState<Staff[]>(() => {
    const saved = localStorage.getItem(`tanzil_staff_${org.id}`);
    if (!saved) return [];
    const parsed: Staff[] = JSON.parse(saved);
    
    const alreadyMigrated = parsed.every(s => s.staffId && s.password === '1234' && /^\d+$/.test(s.staffId));
    
    if (alreadyMigrated) return parsed;
    
    let humanStaffCounter = 9;
    const updated = parsed.map((s: Staff) => {
      if (s.staffId?.startsWith('ILO')) {
        return { ...s, password: '1234' };
      } else {
        const newId = humanStaffCounter.toString().padStart(3, '0');
        humanStaffCounter++;
        return { ...s, staffId: newId, password: '1234' };
      }
    });

    localStorage.setItem(`tanzil_staff_${org.id}`, JSON.stringify(updated));
    return updated;
  });

  const [groupList, setGroupList] = useState<Group[]>(() => {
    const saved = localStorage.getItem(`tanzil_groups_${org.id}`);
    const loaded = saved ? JSON.parse(saved) : [];
    // We filter out any seed groups to respect the "no demo data" (ডেমো ডাটা থাকবে না) instruction
    const filtered = loaded.filter((g: any) => !g.id.startsWith('grp-seed-'));
    return filtered;
  });

  // Simple branch expense/income transactions record
  const [transactions, setTransactions] = useState<any[]>(() => {
    const saved = localStorage.getItem(`tanzil_bm_tx_${org.id}_${staff.branchId}`);
    return saved ? JSON.parse(saved) : [];
  });

  // Ensure branch-specific 'ILO' exists by default in this branch
  useEffect(() => {
    const expectedIloId = `ILO-${currentBranchCode}`;
    const hasBranchIlo = staffList.some(s => s.staffId === expectedIloId);
    const hasLegacyIlo = staffList.some(s => s.staffId === 'ILO');
    const hasWrongIloPassword = staffList.some(s => s.staffId === expectedIloId && s.password !== '12345');

    if (!hasBranchIlo || hasLegacyIlo || hasWrongIloPassword) {
      let filtered = staffList.filter(s => s.staffId !== 'ILO');
      
      // Update any existing ILO account passwords to '12345'
      filtered = filtered.map(s => {
        if (s.staffId?.startsWith('ILO') && s.password !== '12345') {
          return { ...s, password: '12345' };
        }
        return s;
      });

      const branchIloExistsInFiltered = filtered.some(s => s.staffId === expectedIloId);
      
      let updated = [...filtered];
      if (!branchIloExistsInFiltered) {
        const defaultILO: Staff = {
          id: `ilo-branch-${staff.branchId}`,
          orgId: org.id,
          name: `ইন্টারন্যাশনাল লিয়াজোঁ অফিসার (${currentBranch?.name || 'ILO'})`,
          phone: currentBranch?.phone || '01712345678',
          designation: 'মাঠ কর্মী',
          joiningDate: new Date().toISOString().split('T')[0],
          branchId: staff.branchId,
          branchJoiningDate: new Date().toISOString().split('T')[0],
          staffId: expectedIloId,
          password: '12345'
        };
        updated.push(defaultILO);
      }
      
      // Deduplicate before saving
      const uniqueMap = new Map<string, Staff>();
      updated.forEach((s: Staff) => {
        if (s && s.id) uniqueMap.set(s.id, s);
      });
      const deduplicated = Array.from(uniqueMap.values());
      
      setStaffList(deduplicated);
      localStorage.setItem(`tanzil_staff_${org.id}`, JSON.stringify(deduplicated));
    }
  }, [staffList, org.id, staff.branchId, currentBranchCode, currentBranch]);

  // Sync state changes back to centralized local storage
  useEffect(() => {
    localStorage.setItem(`tanzil_staff_${org.id}`, JSON.stringify(staffList));
  }, [staffList, org.id]);

  useEffect(() => {
    localStorage.setItem(`tanzil_groups_${org.id}`, JSON.stringify(groupList));
  }, [groupList, org.id]);

  // Rich member accounts list
  const [groupMembers, setGroupMembers] = useState<any[]>(() => {
    const saved = localStorage.getItem(`tanzil_group_members_${org.id}`);
    return saved ? JSON.parse(saved) : [];
  });

  // Holiday management
  const [holidays, setHolidays] = useState<Holiday[]>(() => {
    try {
      const saved = localStorage.getItem(`tanzil_holidays_${org.id}`);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error("Error reading holidays", e);
    }
    const defaultHolidays = getDefaultHolidays(org.id);
    localStorage.setItem(`tanzil_holidays_${org.id}`, JSON.stringify(defaultHolidays));
    return defaultHolidays;
  });

  // Custom dialog confirmation & alert states (Iframe safe)
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  } | null>(null);

  const [alertModal, setAlertModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
  } | null>(null);

  const showConfirm = (message: string, onConfirm: () => void, title = "নিশ্চিত করুন") => {
    setConfirmModal({
      isOpen: true,
      title,
      message,
      onConfirm: () => {
        onConfirm();
        setConfirmModal(null);
      }
    });
  };

  const showAlert = (message: string, title = "বিজ্ঞপ্তি") => {
    setAlertModal({
      isOpen: true,
      title,
      message
    });
  };
  
  const [holidayYearFilter, setHolidayYearFilter] = useState('all');
  const [holidaySearchQuery, setHolidaySearchQuery] = useState('');

  // Holiday Modal & Form States
  const [isHolidayModalOpen, setIsHolidayModalOpen] = useState(false);
  const [editingHolidayId, setEditingHolidayId] = useState<string | null>(null);
  const [holidayType, setHolidayType] = useState<'direct' | 'general'>('direct');
  const [holidayName, setHolidayName] = useState('');
  const [holidayDate, setHolidayDate] = useState(() => workingDay || new Date().toISOString().split('T')[0]);
  const [holidayDayOfWeek, setHolidayDayOfWeek] = useState('শুক্রবার');

  const handleAddHoliday = (e: React.FormEvent) => {
    e.preventDefault();
    if (!holidayName.trim()) {
      alert('দয়া করে ছুটির কারণ বা বিবরণ লিখুন।');
      return;
    }

    let updatedHolidays;
    if (editingHolidayId) {
      updatedHolidays = holidays.map(h => {
        if (h.id === editingHolidayId) {
          return {
            ...h,
            type: holidayType,
            name: holidayName.trim(),
            date: holidayType === 'direct' ? holidayDate : undefined,
            dayOfWeek: holidayType === 'general' ? holidayDayOfWeek : undefined
          };
        }
        return h;
      });
      setEditingHolidayId(null);
    } else {
      const newHoliday: Holiday = {
        id: `HLD-${Math.floor(1000 + Math.random() * 9000)}-${Date.now().toString().slice(-4)}`,
        orgId: org.id,
        type: holidayType,
        name: holidayName.trim(),
        date: holidayType === 'direct' ? holidayDate : undefined,
        dayOfWeek: holidayType === 'general' ? holidayDayOfWeek : undefined,
        addDate: workingDay
      };
      updatedHolidays = [newHoliday, ...holidays];
    }

    setHolidays(updatedHolidays);
    localStorage.setItem(`tanzil_holidays_${org.id}`, JSON.stringify(updatedHolidays));
    setHolidayName('');
    setIsHolidayModalOpen(false);
  };

  const handleEditHoliday = (holiday: Holiday) => {
    setEditingHolidayId(holiday.id);
    setHolidayType(holiday.type);
    setHolidayName(holiday.name);
    if (holiday.type === 'direct' && holiday.date) {
      setHolidayDate(holiday.date);
    }
    if (holiday.type === 'general' && holiday.dayOfWeek) {
      setHolidayDayOfWeek(holiday.dayOfWeek);
    }
    setIsHolidayModalOpen(true);
  };

  const handleDeleteHoliday = (id: string, name: string) => {
    showConfirm(`আপনি কি নিশ্চিতভাবে "${name}" ছুটিটি ডিলিট করতে চান?`, () => {
      const updatedHolidays = holidays.filter(h => h.id !== id);
      setHolidays(updatedHolidays);
      localStorage.setItem(`tanzil_holidays_${org.id}`, JSON.stringify(updatedHolidays));
    });
  };

  // Sync state with Admin declared holidays when tab shifts
  useEffect(() => {
    if (activeTab === 'holidays') {
      try {
        const saved = localStorage.getItem(`tanzil_holidays_${org.id}`);
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) {
            setHolidays(parsed);
          }
        }
      } catch (e) {
        console.error("Error reading holidays for branch", e);
      }
    }
  }, [activeTab, org.id]);

  // Sync state changes back to centralized local storage for member accounts
  useEffect(() => {
    localStorage.setItem(`tanzil_group_members_${org.id}`, JSON.stringify(groupMembers));
  }, [groupMembers, org.id]);

  useEffect(() => {
    localStorage.setItem(`tanzil_bm_tx_${org.id}_${staff.branchId}`, JSON.stringify(transactions));
  }, [transactions, org.id, staff.branchId]);

  // Loan proposals state
  const [loanProposals, setLoanProposals] = useState<any[]>(() => {
    const saved = localStorage.getItem(`tanzil_loan_proposals_${org.id}`);
    return saved ? JSON.parse(saved) : [];
  });

  // Sync loan proposals state on change
  useEffect(() => {
    localStorage.setItem(`tanzil_loan_proposals_${org.id}`, JSON.stringify(loanProposals));
  }, [loanProposals, org.id]);

  // Filter staff that belongs to the logged-in BM's branch. If not BM, only show themselves.
  const branchStaff = staffList.filter(s => 
    s.branchId === staff.branchId && (isBM || s.id === staff.id)
  );

  // Filter groups that belongs to this branch. If not BM, only show assigned groups.
  const branchGroups = groupList.filter(g => 
    g.branchId === staff.branchId && 
    (isBM || g.assignedStaffId === staff.id || g.assignedStaffId === staff.staffId)
  );

  // --- HRM Modal & form states ---
  const [isStaffModalOpen, setIsStaffModalOpen] = useState(false);
  const [isStaffEditMode, setIsStaffEditMode] = useState(false);
  const [editingStaffId, setEditingStaffId] = useState<string | null>(null);
  
  const [staffNameInput, setStaffNameInput] = useState('');
  const [staffPhoneInput, setStaffPhoneInput] = useState('');
  const [staffDesignationInput, setStaffDesignationInput] = useState('মাঠ কর্মী');
  const [staffJoiningDateInput, setStaffJoiningDateInput] = useState(() => new Date().toISOString().split('T')[0]);

  // --- Leave Modal states ---
  const [isLeaveModalOpen, setIsLeaveModalOpen] = useState(false);
  const [leaveStaffTarget, setLeaveStaffTarget] = useState<Staff | null>(null);
  const [leaveReason, setLeaveReason] = useState('অসুস্থতা জনিত ছুটি');
  const [leaveStart, setLeaveStart] = useState(() => new Date().toISOString().split('T')[0]);
  const [leaveEnd, setLeaveEnd] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 7);
    return d.toISOString().split('T')[0];
  });
  const [alertMsg, setAlertMsg] = useState<{ type: 'success' | 'info'; text: string } | null>(null);

  // --- Add/Edit Group form states ---
  const [groupNameInput, setGroupNameInput] = useState('');
  const [groupCodeInput, setGroupCodeInput] = useState('');
  const [groupStaffSelect, setGroupStaffSelect] = useState(() => {
    return staff.designation === 'শাখা ব্যবস্থাপক' ? `ILO-${currentBranchCode}` : (staff.staffId || staff.id);
  });
  const [groupMeetingDayInput, setGroupMeetingDayInput] = useState('শনিবার');
  const [groupVillageInput, setGroupVillageInput] = useState('');
  const [isGroupEditMode, setIsGroupEditMode] = useState(false);
  const [editingGroupId, setEditingGroupId] = useState<string | null>(null);

  // --- Group Operation Member Search tab and control states ---
  const [activeCardView, setActiveCardView] = useState<'grid' | 'member_admission' | 'member_information' | 'member_transaction' | 'loan_proposal' | 'loan_disburse'>('grid');

  const handleMemberAdmissionSuccess = (newMember: any) => {
    setGroupMembers((prev: any[]) => [...prev, newMember]);
    setActiveCardView('grid');
    setAlertMsg({ 
      type: 'success', 
      text: `নতুন সদস্য ${newMember.name} (${newMember.memberId}) সফলভাবে ভর্তি করা হয়েছে!` 
    });
  };

  const handleLoanProposalSuccess = () => {
    // Reload dynamically from localStorage to stay perfectly in sync
    const saved = localStorage.getItem(`tanzil_loan_proposals_${org.id}`);
    if (saved) {
      setLoanProposals(JSON.parse(saved));
    }
    setActiveCardView('grid');
    setAlertMsg({
      type: 'success',
      text: 'নতুন ঋণ প্রস্তাবটি সফলভাবে দাখিল করা হয়েছে এবং অনুমোদনের জন্য শাখা ব্যবস্থাপকের অপেক্ষমাণ তদারকিতে রয়েছে!'
    });
  };

  const handleLoanDisburseSuccess = (updatedMembersList: any[], txDetails: any) => {
    setGroupMembers(updatedMembersList);
    
    // Add transaction to local BM records
    const newTx = {
      id: `tx-sys-${Date.now()}`,
      orgId: org.id,
      branchId: staff.branchId || 'default-branch',
      staffId: staff.id || staff.staffId || '009',
      staffName: staff.name,
      memberId: txDetails.memberId,
      memberName: txDetails.memberName,
      groupName: txDetails.groupName,
      type: 'disbursement',
      amount: txDetails.netAmount,
      date: txDetails.date,
      description: `ঋণ বিতরণ: ${txDetails.netAmount} BDT (খাত: ${txDetails.proposalDetail.purpose}) — সোর্স: ${txDetails.source}`
    };
    
    setTransactions((prev) => [newTx, ...prev]);

    // Reload proposals to update status to disbursed
    const saved = localStorage.getItem(`tanzil_loan_proposals_${org.id}`);
    if (saved) {
      setLoanProposals(JSON.parse(saved));
    }

    setActiveCardView('grid');
    setAlertMsg({
      type: 'success',
      text: `সদস্য ${txDetails.memberName} (${txDetails.memberId})-কে সফলভাবে ঋণ বিতরণ করা হয়েছে!`
    });
  };

  const handleUpdateMemberStatus = (memberId: string, newStatus: 'active' | 'inactive', reason?: string) => {
    setGroupMembers((prev: any[]) => prev.map((m: any) => 
      m.id === memberId ? { ...m, status: newStatus, inactiveReason: reason || '' } : m
    ));
    setAlertMsg({
      type: 'success',
      text: `সদস্যের স্ট্যাটাস সফলভাবে '${newStatus === 'active' ? 'সচল' : 'নিষ্ক্রিয়'}' করা হয়েছে!`
    });
  };

  const handleSaveTransactions = (updatedMembersList: any[], txDetails: any) => {
    setGroupMembers(updatedMembersList);
    
    // Add transaction to local BM records
    const newTx = {
      id: `tx-sys-${Date.now()}`,
      orgId: org.id,
      branchId: staff.branchId || 'default-branch',
      staffId: staff.id || staff.staffId || '009',
      staffName: staff.name,
      memberId: txDetails.memberId,
      memberName: txDetails.memberName,
      groupName: txDetails.groupName,
      type: 'collection',
      amount: txDetails.netAmount,
      date: txDetails.date,
      description: `Daily collection (PL: ${txDetails.collections.pl}, GS: ${txDetails.collections.gs}, CBS: ${txDetails.collections.cbs}, LTS: ${txDetails.collections.lts})`
    };
    
    setTransactions((prev) => [newTx, ...prev]);
    setActiveCardView('grid');
    setAlertMsg({
      type: 'success',
      text: `${txDetails.memberName} এর দৈনিক আদায়কৃত লেনদেন (আদায়: ৳${txDetails.netAmount}) সফলভাবে সংরক্ষণ করা হয়েছে!`
    });
  };

  const [groupOpActiveSubTab, setGroupOpActiveSubTab] = useState<'list' | 'search'>('list');
  const [selectedStaffIdForSearch, setSelectedStaffIdForSearch] = useState(() => {
    return staff.designation === 'শাখা ব্যবস্থাপক' ? 'all' : (staff.staffId || staff.id);
  });
  const [selectedGroupIdForSearch, setSelectedGroupIdForSearch] = useState('');
  const [selectedMemberIdForSearch, setSelectedMemberIdForSearch] = useState('');
  const [isAccountCardViewOpen, setIsAccountCardViewOpen] = useState(false);
  const [isAccountStatementOpen, setIsAccountStatementOpen] = useState(false);
  const [isLoanScheduleOpen, setIsLoanScheduleOpen] = useState(false);

  // --- Move Group states ---
  const [moveGroupTargetId, setMoveGroupTargetId] = useState('');
  const [moveGroupDestinationStaffId, setMoveGroupDestinationStaffId] = useState('');

  // --- Accounts form states ---
  const [isTxModalOpen, setIsTxModalOpen] = useState(false);
  const [txType, setTxType] = useState<'income' | 'expense'>('income');
  const [txCategory, setTxCategory] = useState('ভর্তিকরণ ফি');
  const [txAmount, setTxAmount] = useState('');
  const [txNote, setTxNote] = useState('');

  // Auto clean alert messages after 5 seconds
  useEffect(() => {
    if (alertMsg) {
      const t = setTimeout(() => setAlertMsg(null), 6000);
      return () => clearTimeout(t);
    }
  }, [alertMsg]);

  // Handle staff addition/editing
  const handleSaveStaff = (e: React.FormEvent) => {
    e.preventDefault();
    if (!staffNameInput || !staffPhoneInput) {
      alert('অনুগ্রহ করে নাম এবং মোবাইল নম্বর দিন।');
      return;
    }

    if (isStaffEditMode && editingStaffId) {
      setStaffList(prev => prev.map(s => s.id === editingStaffId ? {
        ...s,
        name: staffNameInput,
        phone: staffPhoneInput,
        designation: staffDesignationInput,
        joiningDate: staffJoiningDateInput
      } : s));
      setAlertMsg({ type: 'success', text: `কর্মকর্তা "${staffNameInput}" এর তথ্য সফলভাবে আপডেট করা হয়েছে।` });
    } else {
      // Generate unique numeric staff UID starting from 009
      let autoStaffId = '';
      let currentNum = 9;
      do {
        autoStaffId = currentNum.toString().padStart(3, '0');
        currentNum++;
      } while (staffList.some(s => s.staffId === autoStaffId));
      
      const generatedPassword = '1234';

      const newStaff: Staff = {
        id: Date.now().toString(),
        orgId: org.id,
        name: staffNameInput,
        phone: staffPhoneInput,
        designation: staffDesignationInput,
        joiningDate: staffJoiningDateInput,
        branchId: staff.branchId, // Assigned automatically to current BM's branch
        branchJoiningDate: new Date().toISOString().split('T')[0],
        staffId: autoStaffId,
        password: generatedPassword
      };

      setStaffList(prev => [...prev, newStaff]);
      setAlertMsg({ 
        type: 'success', 
        text: `নতুন কর্মী "${staffNameInput}" সফলভাবে যুক্ত হয়েছে! আইডি: ${autoStaffId}, পাসওয়ার্ড: ${generatedPassword}` 
      });
    }

    // Reset fields
    setStaffNameInput('');
    setStaffPhoneInput('');
    setStaffDesignationInput('মাঠ কর্মী');
    setIsStaffModalOpen(false);
  };

  // Open Edit Staff Modal
  const openEditStaff = (target: Staff) => {
    setIsStaffEditMode(true);
    setEditingStaffId(target.id);
    setStaffNameInput(target.name);
    setStaffPhoneInput(target.phone);
    setStaffDesignationInput(target.designation);
    setStaffJoiningDateInput(target.joiningDate || new Date().toISOString().split('T')[0]);
    setIsStaffModalOpen(true);
  };

  // Delete staff/officer
  const handleDeleteStaff = (target: Staff) => {
    if (target.staffId?.startsWith('ILO')) {
      alert('সিস্টেম ও ব্যাকআপ এও "ILO" কে ডিলেট করা যাবে না!');
      return;
    }
    
    // Prevent the logged-in Branch Manager from deleting themselves
    if (target.id === staff.id || (target.staffId && target.staffId === staff.staffId)) {
      alert('আপনি বর্তমানে এই ব্রাঞ্চ ম্যানেজার অ্যাকাউন্টে লগইন আছেন। লগইন থাকা অবস্থায় নিজেকে ডিলিট বা অপসারণ করা সম্ভব নয়!');
      return;
    }

    // Find groups assigned to this staff member
    const assignedGroups = groupList.filter(g => g.assignedStaffId === target.id || g.assignedStaffId === target.staffId);
    
    let confirmMsg = `আপনি কি নিশ্চিতভাবে "${target.name}" কে কর্মী তালিকা থেকে বাদ দিতে চান?`;
    if (assignedGroups.length > 0) {
      confirmMsg = `কর্মী "${target.name}" বর্তমানে ${assignedGroups.length} টি গ্রুপ/সমিতির দায়িত্বে আছেন (যেমন: ${assignedGroups.map(g => g.name).join(', ')})।\n\nডিলিট করার পর তার দায়ীত্বাধীন গ্রুপগুলো স্বয়ংক্রিয়ভাবে আপনার শাখার ডেক্স ব্যাকআপ কর্মকর্তা "ILO-${currentBranchCode}" তে স্থানান্তরিত হবে।\n\nআপনি কি নিশ্চিতভাবে তাকে কর্মী তালিকা থেকে বাদ দিতে চান?`;
    }

    if (confirm(confirmMsg)) {
      if (assignedGroups.length > 0) {
        const updatedGroups = groupList.map(g => {
          if (g.assignedStaffId === target.id || g.assignedStaffId === target.staffId) {
            return { ...g, assignedStaffId: `ILO-${currentBranchCode}` };
          }
          return g;
        });
        setGroupList(updatedGroups);
      }
      const newStaffList = staffList.filter(s => s.id !== target.id);
      setStaffList(newStaffList);
      localStorage.setItem(`tanzil_staff_${org.id}`, JSON.stringify(newStaffList));
      setAlertMsg({ type: 'success', text: `কর্মী "${target.name}" বাদ দেয়া হয়েছে এবং তার দায়িত্বাধীন গ্রুপ ও সমিতিগুলো স্বয়ংক্রিয়ভাবে ILO-তে স্থানান্তরিত হয়েছে।` });
    }
  };

  // Handle granting leave to a staff and automatically transfer all assigned groups to ILO!
  const handleGrantLeave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!leaveStaffTarget) return;

    // 1. Mark staff as on leave
    const targetId = leaveStaffTarget.id;
    const targetUid = leaveStaffTarget.staffId || '';
    const name = leaveStaffTarget.name;

    setStaffList(prev => prev.map(s => s.id === targetId ? {
      ...s,
      onLeave: true,
      leaveStart,
      leaveEnd,
      leaveReason
    } as any : s));

    // 2. Identify groups and migrate to ILO
    // Note: We check if group is assigned to this staff (using UID or DB ID)
    let movedCount = 0;
    const updatedGroups = groupList.map(g => {
      if (g.branchId === staff.branchId && (g.assignedStaffId === targetId || g.assignedStaffId === targetUid)) {
        movedCount++;
        return { ...g, assignedStaffId: `ILO-${currentBranchCode}` }; // Transfer to branch-specific ILO target
      }
      return g;
    });

    if (movedCount > 0) {
      setGroupList(updatedGroups);
      setAlertMsg({ 
        type: 'info', 
        text: `কর্মী "${name}" কে ছুটিতে পাঠানো হয়েছে। দ্বায়িত্বরত ${movedCount} টি গ্রুপ সফলভাবে সিস্টেম ব্যাকআপ অফিসার "ILO-${currentBranchCode}" তে স্থানান্তর করা হয়েছে!` 
      });
    } else {
      setAlertMsg({ 
        type: 'success', 
        text: `কর্মী "${name}" কে সফলভাবে ছুটিতে পাঠানো হয়েছে। (কোনো গ্রুপ বরাদ্দ ছিল না)` 
      });
    }

    setIsLeaveModalOpen(false);
    setLeaveStaffTarget(null);
  };

  // Cancel/Rescind Leave (Restore Staff to Active State)
  const handleCancelLeave = (srv: Staff) => {
    setStaffList(prev => prev.map(s => s.id === srv.id ? {
      ...s,
      onLeave: false,
      leaveStart: undefined,
      leaveEnd: undefined,
      leaveReason: undefined
    } as any : s));
    setAlertMsg({ type: 'success', text: `কর্মী "${srv.name}" এর ছুটি বাতিল করে পুনরায় দায়িত্বে ফিরিয়ে আনা হয়েছে।` });
  };

  // --- Group Operations logic ---
  const handleSaveGroup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupNameInput || !groupCodeInput) {
      alert('গ্রুপের নাম এবং কোড পূরণ করুন।');
      return;
    }

    if (isGroupEditMode && editingGroupId) {
      setGroupList(prev => prev.map(g => g.id === editingGroupId ? {
        ...g,
        name: groupNameInput,
        code: groupCodeInput,
        assignedStaffId: groupStaffSelect,
        meetingDay: groupMeetingDayInput,
        village: groupVillageInput
      } : g));
      setAlertMsg({ type: 'success', text: `গ্রুপ "${groupNameInput}" সফলভাবে আপডেট করা হয়েছে।` });
    } else {
      // Add new group
      const newGroup: Group = {
        id: Date.now().toString(),
        orgId: org.id,
        branchId: staff.branchId || '',
        name: groupNameInput,
        code: groupCodeInput,
        assignedStaffId: groupStaffSelect,
        meetingDay: groupMeetingDayInput,
        village: groupVillageInput,
        addDate: new Date().toISOString().split('T')[0]
      };
      setGroupList(prev => [...prev, newGroup]);
      setAlertMsg({ type: 'success', text: `নতুন গ্রুপ "${groupNameInput}" সফলভাবে যুক্ত করা হয়েছে।` });
    }

    // Reset inputs
    setGroupNameInput('');
    setGroupCodeInput('');
    setGroupStaffSelect(`ILO-${currentBranchCode}`);
    setGroupMeetingDayInput('শনিবার');
    setGroupVillageInput('');
    setIsGroupEditMode(false);
    setEditingGroupId(null);
    setSelectedOperation('group_operation'); // Switch back to group list view
  };

  const openEditGroup = (g: Group) => {
    setIsGroupEditMode(true);
    setEditingGroupId(g.id);
    setGroupNameInput(g.name);
    setGroupCodeInput(g.code);
    setGroupStaffSelect(g.assignedStaffId);
    setGroupMeetingDayInput(g.meetingDay || 'শনিবার');
    setGroupVillageInput(g.village || '');
    setSelectedOperation('add_group');
  };

  const handleDeleteGroup = (g: Group) => {
    if (confirm(`আপনি কি নিশ্চিতভাবে "${g.name}" গ্রুপটি ডিলিট করতে চান?`)) {
      setGroupList(prev => prev.filter(x => x.id !== g.id));
      setAlertMsg({ type: 'success', text: `গ্রুপ "${g.name}" মুছে ফেলা হয়েছে।` });
    }
  };

  // Handle manual Move Group reassignment
  const handleMoveGroupAction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!moveGroupTargetId || !moveGroupDestinationStaffId) {
      alert('সবগুলো অপশন নির্বাচন করুন।');
      return;
    }

    const matchedGroup = groupList.find(g => g.id === moveGroupTargetId);
    const matchedStaff = staffList.find(s => s.staffId === moveGroupDestinationStaffId || s.id === moveGroupDestinationStaffId);
    
    if (!matchedGroup || !matchedStaff) {
      alert('গ্রুপ বা কর্মী খুঁজে পাওয়া যায়নি।');
      return;
    }

    setGroupList(prev => prev.map(g => g.id === moveGroupTargetId ? {
      ...g,
      assignedStaffId: moveGroupDestinationStaffId
    } : g));

    setAlertMsg({ 
      type: 'success', 
      text: `গ্রুপ "${matchedGroup.name}" সফলভাবে কর্মকর্তা "${matchedStaff.name}" এর দায়িত্বে স্থানান্তর করা হয়েছে।` 
    });

    setMoveGroupTargetId('');
    setMoveGroupDestinationStaffId('');
    setSelectedOperation('group_operation');
  };

  // Adding random financial operations/ledgers for branch
  const handleSaveTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!txAmount || isNaN(Number(txAmount))) {
      alert('সঠিক পরিমাণ দিন।');
      return;
    }

    const newTx = {
      id: Date.now().toString(),
      type: txType,
      category: txCategory,
      amount: Number(txAmount),
      note: txNote || 'কোনো মন্তব্য নেই',
      addDate: new Date().toISOString().split('T')[0]
    };

    setTransactions(prev => [newTx, ...prev]);
    setIsTxModalOpen(false);
    setTxAmount('');
    setTxNote('');
    setAlertMsg({ type: 'success', text: `লেনদেন বিবরণী সফলভাবে একাউন্ট খাতায় যুক্ত করা হয়েছে।` });
  };

  // Change BM/Staff Password
  const handleBMChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPasswordVal.trim().length === 0) {
      alert('দয়া করে সঠিক পাসওয়ার্ড দিন');
      return;
    }
    if (newPasswordVal !== confirmPasswordVal) {
      alert('পাসওয়ার্ড দুটি মেলেনি!');
      return;
    }

    setStaffList(prev => prev.map(s => {
      if (s.id === staff.id || (s.staffId && s.staffId.toLowerCase() === staff.staffId.toLowerCase())) {
        return { ...s, password: newPasswordVal };
      }
      return s;
    }));

    setPasswordChangeSuccess('পাসওয়ার্ড সফলভাবে পরিবর্তন করা হয়েছে!');
    setTimeout(() => {
      setPasswordChangeSuccess('');
      setIsChangePasswordModalOpen(false);
    }, 2000);
  };

  // Branch statistics calculations
  const totalStaffCount = branchStaff.length;
  const staffOnLeaveCount = branchStaff.filter((s: any) => s.onLeave === true).length;
  const activeStaffCount = totalStaffCount - staffOnLeaveCount;
  const totalGroupsCount = branchGroups.length;

  const totalIncome = transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
  const totalExpense = transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
  const netBalance = totalIncome - totalExpense;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-800">
      
      {/* Software Brand Topbar / সবার উপরে সফটওয়্যারের নাম ও প্রাতিষ্ঠানিক তথ্য */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-800 to-violet-900 text-white py-4 px-4 sm:px-6 shadow-xl z-20">
        <div className="max-w-7xl mx-auto space-y-4">
          
          {/* Top Line: Software Name & Quick Control Actions */}
          <div className="flex flex-col sm:flex-row justify-between items-center gap-3 border-b border-white/10 pb-3">
            <div className="flex items-center gap-3 font-bold tracking-wide">
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
                <span className="text-sm font-extrabold text-white">তানজিল মাইক্রোক্রেডিট সফটওয়্যার</span>
              </div>
            </div>
            
            {/* Quick Actions */}
            <div className="flex items-center flex-wrap gap-2 text-[11px] font-medium">
              <div className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-lg border border-white/20 text-white font-bold animate-in fade-in duration-300">
                <Clock size={12} className="text-amber-300 animate-pulse" />
                <span>কর্মদিবস:</span>
                <span className="font-mono font-bold text-amber-200 text-[12px]">{workingDay}</span>
              </div>
            </div>
          </div>

          {/* Bottom Line: Org Details & Logged-in Branch Manager Credentials */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3 text-xs text-white/90">
            {/* Left Portion: Organization Details */}
            <div className="flex items-center gap-4">
              <div className="p-2 bg-white/10 rounded-xl border border-white/20">
                <Building className="w-5 h-5 text-emerald-300" />
              </div>
              <div>
                <span className="text-[9px] text-white/60 font-bold block leading-none uppercase tracking-wider">প্রতিষ্ঠান এবং শাখা</span>
                <div className="flex flex-col mt-0.5">
                  <span className="text-sm font-extrabold text-white">{org.name}</span>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <span className="text-xs font-extrabold text-emerald-300">
                      শাখা: {currentBranch?.name || 'প্রধান কার্যালয়'}
                    </span>
                    <span className="text-[10px] bg-white/15 border border-white/25 px-2 py-0.5 rounded font-extrabold text-emerald-100 tracking-wider">
                      শাখা কোড: {currentBranchCode}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Portion: Operator details, Password Change & Logout */}
            <div className="flex items-center gap-5 text-xs font-semibold text-white/90 border-t md:border-t-0 border-white/10 pt-3 md:pt-0 w-full justify-between md:justify-end">
              <div className="flex items-center gap-2">
                <span className="text-white/60">
                  {isBM ? 'ব্যবস্থাপক আইডি:' : 'কর্মী আইডি:'}
                </span> 
                <span className="font-bold text-white tracking-wide font-mono bg-black/20 px-2 py-0.5 rounded">{staff.staffId}</span>
                <span className="text-emerald-300 ml-1">({staff.name}) - <span className="text-amber-300">{staff.designation}</span></span>
              </div>
              
              <div className="flex items-center gap-3 border-l border-white/20 pl-5">
                <button
                  type="button"
                  onClick={() => {
                    setNewPasswordVal('');
                    setConfirmPasswordVal('');
                    setPasswordChangeSuccess('');
                    setIsChangePasswordModalOpen(true);
                  }}
                  className="bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded-lg border border-white/20 text-white transition-all font-bold text-[10px] flex items-center gap-1.5 cursor-pointer"
                >
                  <Key size={11} />
                  <span>পাসওয়ার্ড পরিবর্তন</span>
                </button>
                <button 
                  type="button"
                  onClick={onLogout}
                  className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg transition-colors font-bold text-[10px] flex items-center gap-1.5 cursor-pointer"
                >
                  <LogOut size={11} />
                  <span>লগআউট</span>
                </button>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Main Body Grid Container with sidebar & content area */}
      <div className="flex-1 max-w-7xl w-full mx-auto flex flex-col md:flex-row min-h-0 bg-white shadow-md border-x border-slate-200">
        
        {/* SIDEBAR - Hidden during Full Screen Operations for both BM and FO */}
        {!isFullScreenOperation && (
          <aside id="bm_dashboard_sidebar" className="w-full md:w-64 bg-slate-50 border-b md:border-b-0 md:border-r border-slate-200 p-4 shrink-0 flex flex-col gap-1 transition-all duration-300">
            <div className="px-3 py-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">
              মেনু নেভিগেশন
            </div>

            <nav className="flex-1 space-y-1">
              {isBM ? (
                <>
                  <button
                    id="bm_tab_dashboard"
                    onClick={() => { setActiveTab('dashboard'); setIsFullScreenOperation(false); }}
                    className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      activeTab === 'dashboard' && !isFullScreenOperation
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-700 hover:bg-slate-200/50 hover:text-slate-900'
                    }`}
                  >
                    <LayoutDashboard size={15} />
                    <span>ড্যাশবোর্ড (Dashboard)</span>
                  </button>

                  <button
                    id="bm_tab_hrm"
                    onClick={() => { setActiveTab('hrm'); setIsFullScreenOperation(false); }}
                    className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      activeTab === 'hrm' && !isFullScreenOperation
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-700 hover:bg-slate-200/50 hover:text-slate-900'
                    }`}
                  >
                    <Users size={15} />
                    <span>এইচআরএম (HRM)</span>
                  </button>

                  <button
                    id="bm_tab_holidays"
                    onClick={() => { setActiveTab('holidays'); setIsFullScreenOperation(false); }}
                    className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      activeTab === 'holidays' && !isFullScreenOperation
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-700 hover:bg-slate-200/50 hover:text-slate-900'
                    }`}
                  >
                    <Calendar size={15} />
                    <span>ছুটি ক্যালেন্ডার (Holidays)</span>
                  </button>

                  <button
                    id="bm_tab_account"
                    onClick={() => { setActiveTab('account'); setIsFullScreenOperation(false); }}
                    className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      activeTab === 'account' && !isFullScreenOperation
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-700 hover:bg-slate-200/50 hover:text-slate-900'
                    }`}
                  >
                    <CreditCard size={15} />
                    <span>একাউন্ট (Account)</span>
                  </button>

                  {/* OPERATION TAB - Opens Full-screen, Hides Sidebar */}
                  <button
                    id="bm_tab_operation"
                    onClick={() => { 
                      setIsFullScreenOperation(true); 
                      setSelectedOperation('menu'); 
                    }}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all border border-dashed cursor-pointer mt-4 ${
                      isFullScreenOperation
                        ? 'bg-amber-600 text-white border-amber-500 shadow-xs'
                        : 'text-amber-600 bg-amber-500/5 hover:bg-amber-500/10 border-amber-500/20'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Layers size={15} className={isFullScreenOperation ? 'text-white' : 'text-amber-500'} />
                      <span>অপারেশন (Operation)</span>
                    </div>
                    {!isFullScreenOperation && (
                      <span className="text-[10px] bg-amber-500/10 text-amber-700 border border-amber-500/20 px-1.5 py-0.5 rounded-md font-mono font-bold">
                        PRO
                      </span>
                    )}
                  </button>
                </>
              ) : (
                <>
                  {/* STAFF (FO) NAVIGATION - Dashboard and FO অপারেশন */}
                  <button
                    id="bm_tab_dashboard_staff"
                    onClick={() => { setActiveTab('dashboard'); setIsFullScreenOperation(false); }}
                    className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      activeTab === 'dashboard' && !isFullScreenOperation
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-700 hover:bg-slate-200/50 hover:text-slate-900'
                    }`}
                  >
                    <LayoutDashboard size={15} />
                    <span>ড্যাশবোর্ড (Dashboard)</span>
                  </button>

                  <button
                    id="bm_tab_operation_staff"
                    onClick={() => { 
                      setIsFullScreenOperation(true); 
                      setSelectedOperation('menu'); 
                    }}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all border border-dashed cursor-pointer mt-4 ${
                      isFullScreenOperation
                        ? 'bg-emerald-600 text-white border-emerald-500 shadow-xs'
                        : 'text-emerald-600 bg-emerald-500/5 hover:bg-emerald-500/10 border-emerald-500/20'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Layers size={15} className={isFullScreenOperation ? 'text-white' : 'text-emerald-500'} />
                      <span>FO অপারেশন</span>
                    </div>
                    {!isFullScreenOperation && (
                      <span className="text-[10px] bg-emerald-105 text-emerald-800 border border-emerald-250 px-1.5 py-0.5 rounded-md font-bold">
                        সক্রিয়
                      </span>
                    )}
                  </button>
                </>
              )}
            </nav>
          </aside>
        )}

        {/* MAIN CONTAINER CONTENT */}
        <main className="flex-1 flex flex-col min-w-0 bg-white">
          
          {/* Full Screen operation warning bar if running operations */}
          {isFullScreenOperation && (
            <div className="bg-amber-50/70 border-b border-amber-200/50 p-3.5 flex justify-between items-center px-6">
              <span className="text-[11px] font-bold text-amber-800 flex items-center gap-2">
                <span className="w-2 h-2 bg-amber-500 rounded-full animate-ping"></span>
                {isBM ? 'শাখা অপারেশন ফুল স্ক্রিন মোড সক্রিয় আছে' : 'মাঠকর্মী অপারেশন মোড সক্রিয় আছে'}
              </span>
              <button
                id="bm_full_exit_btn"
                onClick={() => setIsFullScreenOperation(false)}
                className="px-3.5 py-1.5 bg-slate-900 text-white hover:bg-slate-800 text-[10px] font-extrabold rounded-lg shadow-xs transition flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowLeft size={12} />
                <span>অপারেশন থেকে ফিরে যান</span>
              </button>
            </div>
          )}
          {/* Sub Header (replaces the old head with the dates) */}
          {!isFullScreenOperation && (
            <div className="border-b border-slate-100 p-3.5 px-6 shrink-0 flex items-center justify-between bg-slate-50/50 text-[11px] text-slate-500 font-bold">
              <span className="text-slate-500 font-medium">
                আজকের তারিখ: {new Date().toLocaleDateString('bn-BD', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              </span>
              <span className="text-[10px] bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded font-extrabold tracking-wide">
                {isBM ? 'শাখা ব্যবস্থাপক ড্যাশবোর্ড' : 'মাঠ কর্মী ড্যাশবোর্ড (বিএম এর মত)'}
              </span>
            </div>
          )}

        {/* CONTAINER VIEWPORTS */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto">
          
          {/* TOASTER ALERTS */}
          {alertMsg && (
            <div className={`mb-6 p-4 rounded-xl shadow-xs border transition duration-300 flex items-start gap-3 animate-in slide-in-from-top-4 ${
              alertMsg.type === 'success' 
                ? 'bg-emerald-50 border-emerald-100 text-emerald-800' 
                : 'bg-blue-50 border-blue-100 text-blue-800'
            }`}>
              <CheckCircle2 size={18} className="shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-extrabold">{alertMsg.text}</p>
              </div>
            </div>
          )}

          {/* -------------------- DYNAMIC RENDER START -------------------- */}

          {/* 1. FULL SCREEN OPERATION VIEW */}
          {isFullScreenOperation ? (
            <div id="bm_operation_fullscreen_panel" className="max-w-5xl mx-auto space-y-6">
              
              {/* OPERATION HEADER AND SELECTOR CARDS */}
              {selectedOperation !== 'group_operation' && (
                <div className="bg-gradient-to-r from-amber-500 to-amber-700 rounded-2xl text-white p-6 shadow-md relative overflow-hidden">
                  <div className="relative z-10">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">ফুল স্ক্রিন সিস্টেম</span>
                      <span className="text-[10px] bg-amber-400 text-slate-950 px-2 py-0.5 rounded-full font-bold">
                        {isBM ? 'শাখা অপারেশন প্যানেল' : 'মাঠকর্মী অপারেশন প্যানেল'}
                      </span>
                    </div>
                    <h2 className="text-xl sm:text-2xl font-black">
                      {isBM ? 'ইউজার ম্যানু অপারেশনস' : 'মাঠকর্মী (FO) অপারেশনস'}
                    </h2>
                    <p className="text-xs text-amber-50/80 font-medium max-w-xl mt-1">
                      {isBM 
                        ? 'কর্মী স্থানান্তর, নতুন গ্রুপ তৈরি ও পরিচালনা, এবং গ্রুপের দৈনিক আদায়/বিতরণ কার্যক্রম এখানে সম্পন্ন করুন।'
                        : 'আপনার দায়িত্বপ্রাপ্ত গ্রুপের দৈনিক আদায় ও বিতরণ কার্যক্রম এখানে সম্পন্ন করুন।'
                      }
                    </p>
                  </div>
                  <div className="absolute right-0 bottom-0 top-0 translate-x-12 opacity-15 text-[140px] pointer-events-none font-black text-white select-none">
                    {isBM ? 'BM' : 'FO'}
                  </div>
                </div>
              )}

              {/* THREE MAIN ICON ACTIONS */}
              {selectedOperation === 'menu' && isBM && (
                <div className="grid grid-cols-1 md:grid-cols-2 md:max-w-4xl mx-auto gap-6 pt-2">
                  
                  {/* ICON CARD 1: ADD GROUP */}
                  {isBM && (
                    <button
                      id="bm_op_add_group_btn"
                      onClick={() => {
                        setIsGroupEditMode(false);
                        setEditingGroupId(null);
                        setGroupNameInput('');
                        setGroupCodeInput('');
                        setSelectedOperation('add_group');
                      }}
                      className="p-6 bg-white hover:bg-slate-50 border border-slate-200 hover:border-amber-500 rounded-2xl shadow-sm text-left transition group relative overflow-hidden"
                    >
                      <div className="w-12 h-12 bg-amber-100 text-amber-700 rounded-xl flex items-center justify-center mb-4 transition-transform group-hover:scale-105">
                        <Plus size={24} />
                      </div>
                      <h3 className="font-extrabold text-slate-800 text-base">এড গ্রুপ (Add Group)</h3>
                      <p className="text-xs text-slate-400 mt-2 font-medium">আপনার ব্রাঞ্চের জন্য নতুন ঋণ ও সঞ্চয় দাতা দল/সমিতি গ্রুপ তৈরি করুন।</p>
                      <span className="text-[10px] text-amber-600 font-bold block mt-4 underline group-hover:text-amber-700">জমা করুন →</span>
                    </button>
                  )}

                  {/* ICON CARD 2: GROUP OPERATION */}
                  <button
                    id="bm_op_list_group_btn"
                    onClick={() => setSelectedOperation('group_operation')}
                    className="p-6 bg-white hover:bg-slate-50 border border-slate-200 hover:border-amber-500 rounded-2xl shadow-sm text-left transition group relative overflow-hidden"
                  >
                    <div className="w-12 h-12 bg-amber-100 text-amber-700 rounded-xl flex items-center justify-center mb-4 transition-transform group-hover:scale-105">
                      <Layers size={24} />
                    </div>
                    <h3 className="font-extrabold text-slate-800 text-base">গ্রুপ অপারেশন (Group Operation)</h3>
                    <p className="text-xs text-slate-400 mt-2 font-medium">ব্রাঞ্চের গ্রুপসমূহ পরীক্ষা করুন, সভার তালিকা দেখুন এবং আদায় পরিচালনা করুন।</p>
                    <span className="text-[10px] text-amber-600 font-bold block mt-4 underline group-hover:text-amber-700">অংশগ্রহণ করুন →</span>
                  </button>

                  {/* ICON CARD 3: MOVE GROUP */}
                  {isBM && (
                    <button
                      id="bm_op_move_group_btn"
                      onClick={() => {
                        setMoveGroupTargetId('');
                        setMoveGroupDestinationStaffId('');
                        setSelectedOperation('move_group');
                      }}
                      className="p-6 bg-white hover:bg-slate-50 border border-slate-200 hover:border-amber-500 rounded-2xl shadow-sm text-left transition group relative overflow-hidden"
                    >
                      <div className="w-12 h-12 bg-amber-100 text-amber-700 rounded-xl flex items-center justify-center mb-4 transition-transform group-hover:scale-105">
                        <ArrowLeftRight size={24} />
                      </div>
                      <h3 className="font-extrabold text-slate-800 text-base">মুভ গ্রুপ (Move Group)</h3>
                      <p className="text-xs text-slate-400 mt-2 font-medium">এক মাঠ কর্মীর আওতাভুক্ত গ্রুপ বা সমিতি অন্য মাঠ কর্মীর দায়িত্বে স্থানান্তর করুন।</p>
                      <span className="text-[10px] text-amber-600 font-bold block mt-4 underline group-hover:text-amber-700">স্থানান্তর করুন →</span>
                    </button>
                  )}

                  {/* ICON CARD 4: LOAN PROPOSAL REQUESTS */}
                  {isBM && (
                    <button
                      id="bm_op_loan_proposal_btn"
                      onClick={() => {
                        setSelectedOperation('loan_proposal_requests');
                      }}
                      className="p-6 bg-white hover:bg-slate-50 border border-slate-200 hover:border-indigo-500 rounded-2xl shadow-sm text-left transition group relative overflow-hidden"
                    >
                      <div className="w-12 h-12 bg-indigo-100 text-[#2f6ce5] rounded-xl flex items-center justify-center mb-4 transition-transform group-hover:scale-105">
                        <ClipboardList size={24} />
                      </div>
                      <h3 className="font-extrabold text-slate-800 text-base">লোন প্রপোজাল রিকুয়েষ্ট (Loan Proposal Requests)</h3>
                      <p className="text-xs text-slate-400 mt-2 font-medium">মাঠ কর্মীদের প্রেরিত নতুন ঋণ প্রস্তাব তদারকি করে অনুমোদন বা বাতিল করুন।</p>
                      <span className="text-[10px] text-indigo-600 font-bold block mt-4 underline group-hover:text-indigo-750 font-sans">আবেদন সমূহ দেখুন →</span>
                    </button>
                  )}

                </div>
              )}

              {/* FOR FIELD OFFICER (FO) OPERATIONS - User Action Menus */}
              {selectedOperation === 'menu' && !isBM && (
                <div className="max-w-4xl mx-auto bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200">
                  
                  {/* Title Banner (User Action Menus) */}
                  <div className="relative mb-8 border-b-2 border-[#2f6ce5] pb-2">
                    <span className="inline-block bg-[#2f6ce5] text-white font-bold text-xs sm:text-xs px-4 py-1.5 uppercase select-none tracking-wide">
                      User Action Menus
                    </span>
                    <button 
                      type="button"
                      onClick={() => {
                        setAlertMsg({ type: 'info', text: 'ডাটা সংরক্ষণ স্ট্যাটাস: সিস্টেম সক্রিয় এবং প্রস্তুত।' });
                      }}
                      className="absolute right-1 bottom-1 text-slate-400 hover:text-slate-600 transition-colors"
                      title="সংরক্ষণ করুন"
                    >
                      <Save className="w-6 h-6 stroke-[1.5]" />
                    </button>
                  </div>

                  {/* 8-Button Grid matching the screenshot */}
                  <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-3 gap-6 sm:gap-8">
                    
                    {/* 1. Group Operation */}
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedOperation('group_operation');
                        setGroupOpActiveSubTab('list');
                      }}
                      className="flex flex-col rounded-2xl overflow-hidden transition-all duration-200 cursor-pointer active:scale-95 group border border-amber-200 hover:border-amber-400 hover:shadow-xl shadow-[0_4px_12px_rgba(0,0,0,0.1)] bg-white h-44 sm:h-48"
                    >
                      <div className="bg-[#2f6ce5] py-5 sm:py-6 flex items-center justify-center w-full transition-colors group-hover:bg-[#1d59d1]">
                        <Banknote className="w-10 h-10 sm:w-11 sm:h-11 text-white stroke-[1.5]" />
                      </div>
                      <div className="bg-[#eaeaea] flex-1 px-3 flex items-center justify-center text-slate-800 font-extrabold text-sm sm:text-base leading-tight">
                        Group Operation
                      </div>
                    </button>

                    {/* 2. Member Balance */}
                    <button
                      type="button"
                      onClick={() => {
                        setAlertMsg({ type: 'info', text: 'সದস্য ব্যালেন্স মডিউলটি পরবর্তীতে সক্রিয় করা হবে।' });
                      }}
                      className="flex flex-col rounded-2xl overflow-hidden transition-all duration-200 cursor-pointer active:scale-95 group border border-amber-200 hover:border-amber-400 hover:shadow-xl shadow-[0_4px_12px_rgba(0,0,0,0.1)] bg-white h-44 sm:h-48"
                    >
                      <div className="bg-[#2f6ce5] py-5 sm:py-6 flex items-center justify-center w-full transition-colors group-hover:bg-[#1d59d1]">
                        <FileText className="w-10 h-10 sm:w-11 sm:h-11 text-white stroke-[1.5]" />
                      </div>
                      <div className="bg-[#eaeaea] flex-1 px-3 flex items-center justify-center text-slate-800 font-extrabold text-sm sm:text-base leading-tight">
                        Member Balance
                      </div>
                    </button>

                    {/* 3. Realized Information */}
                    <button
                      type="button"
                      onClick={() => {
                        setAlertMsg({ type: 'info', text: 'আদায়কৃত তথ্যের মডিউলটি পরবর্তীতে সক্রিয় করা হবে।' });
                      }}
                      className="flex flex-col rounded-2xl overflow-hidden transition-all duration-200 cursor-pointer active:scale-95 group border border-amber-200 hover:border-amber-400 hover:shadow-xl shadow-[0_4px_12px_rgba(0,0,0,0.1)] bg-white h-44 sm:h-48"
                    >
                      <div className="bg-[#2f6ce5] py-5 sm:py-6 flex items-center justify-center w-full transition-colors group-hover:bg-[#1d59d1]">
                        <HandCoins className="w-10 h-10 sm:w-11 sm:h-11 text-white stroke-[1.5]" />
                      </div>
                      <div className="bg-[#eaeaea] flex-1 px-3 flex items-center justify-center text-slate-800 font-extrabold text-sm sm:text-base leading-tight">
                        Realized Information
                      </div>
                    </button>

                    {/* 4. Search Member */}
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedOperation('group_operation');
                        setGroupOpActiveSubTab('search');
                      }}
                      className="flex flex-col rounded-2xl overflow-hidden transition-all duration-200 cursor-pointer active:scale-95 group border border-amber-200 hover:border-amber-400 hover:shadow-xl shadow-[0_4px_12px_rgba(0,0,0,0.1)] bg-white h-44 sm:h-48"
                    >
                      <div className="bg-[#2f6ce5] py-5 sm:py-6 flex items-center justify-center w-full transition-colors group-hover:bg-[#1d59d1]">
                        <Search className="w-10 h-10 sm:w-11 sm:h-11 text-white stroke-[1.5]" />
                      </div>
                      <div className="bg-[#eaeaea] flex-1 px-3 flex items-center justify-center text-slate-800 font-extrabold text-sm sm:text-base leading-tight">
                        Search Member
                      </div>
                    </button>

                    {/* 5. Import Data */}
                    <button
                      type="button"
                      onClick={() => {
                        setAlertMsg({ type: 'info', text: 'ইম্পোর্ট ডাটা মডিউলটি পরবর্তীতে সক্রিয় করা হবে।' });
                      }}
                      className="flex flex-col rounded-2xl overflow-hidden transition-all duration-200 cursor-pointer active:scale-95 group border border-amber-100 shadow-[0_4px_10px_rgba(0,0,0,0.06)] bg-white/95 h-44 sm:h-48 opacity-75 hover:opacity-90"
                    >
                      <div className="bg-[#85a1e0] py-5 sm:py-6 flex items-center justify-center w-full">
                        <Download className="w-10 h-10 sm:w-11 sm:h-11 text-white/95 stroke-[1.5]" />
                      </div>
                      <div className="bg-[#eaeaea] flex-1 px-3 flex items-center justify-center text-slate-500 font-extrabold text-sm sm:text-base leading-tight">
                        Import Data
                      </div>
                    </button>

                    {/* 6. Overdue Members */}
                    <button
                      type="button"
                      onClick={() => {
                        setAlertMsg({ type: 'info', text: 'ওভারডিউ সদস্য মডিউলটি পরবর্তীতে সক্রিয় করা হবে।' });
                      }}
                      className="flex flex-col rounded-2xl overflow-hidden transition-all duration-200 cursor-pointer active:scale-95 group border border-amber-200 hover:border-amber-400 hover:shadow-xl shadow-[0_4px_12px_rgba(0,0,0,0.1)] bg-white h-44 sm:h-48"
                    >
                      <div className="bg-[#2f6ce5] py-5 sm:py-6 flex items-center justify-center w-full transition-colors group-hover:bg-[#1d59d1]">
                        <FileClock className="w-10 h-10 sm:w-11 sm:h-11 text-white stroke-[1.5]" />
                      </div>
                      <div className="bg-[#eaeaea] flex-1 px-3 flex items-center justify-center text-slate-800 font-extrabold text-sm sm:text-base leading-tight">
                        Overdue Members
                      </div>
                    </button>

                    {/* 7. Export Data */}
                    <button
                      type="button"
                      onClick={() => {
                        setAlertMsg({ type: 'info', text: 'এক্সপোর্ট ডাটা মডিউলটি পরবর্তীতে সক্রিয় করা হবে।' });
                      }}
                      className="flex flex-col rounded-2xl overflow-hidden transition-all duration-200 cursor-pointer active:scale-95 group border border-amber-200 hover:border-amber-400 hover:shadow-xl shadow-[0_4px_12px_rgba(0,0,0,0.1)] bg-white h-44 sm:h-48"
                    >
                      <div className="bg-[#2f6ce5] py-5 sm:py-6 flex items-center justify-center w-full transition-colors group-hover:bg-[#1d59d1]">
                        <Upload className="w-10 h-10 sm:w-11 sm:h-11 text-white stroke-[1.5]" />
                      </div>
                      <div className="bg-[#eaeaea] flex-1 px-3 flex items-center justify-center text-slate-800 font-extrabold text-sm sm:text-base leading-tight">
                        Export Data
                      </div>
                    </button>

                    {/* 8. Export Online */}
                    <button
                      type="button"
                      onClick={() => {
                        setAlertMsg({ type: 'info', text: 'অনলাইন এক্সপোর্ট মডিউলটি পরবর্তীতে সক্রিয় করা হবে।' });
                      }}
                      className="flex flex-col rounded-2xl overflow-hidden transition-all duration-200 cursor-pointer active:scale-95 group border border-amber-200 hover:border-amber-400 hover:shadow-xl shadow-[0_4px_12px_rgba(0,0,0,0.1)] bg-white h-44 sm:h-48"
                    >
                      <div className="bg-[#2f6ce5] py-5 sm:py-6 flex items-center justify-center w-full transition-colors group-hover:bg-[#1d59d1]">
                        <div className="relative flex items-center justify-center">
                          <Cloud className="w-10 h-10 sm:w-11 sm:h-11 text-white stroke-[1.5]" />
                          <RefreshCw className="absolute w-3.5 h-3.5 text-white/95 animate-spin [animation-duration:12s] translate-y-0.5" />
                        </div>
                      </div>
                      <div className="bg-[#eaeaea] flex-1 px-3 flex items-center justify-center text-slate-800 font-extrabold text-sm sm:text-base leading-tight">
                        Export Online
                      </div>
                    </button>

                  </div>
                </div>
              )}

              {/* SECTION: ADD GROUP FORM */}
              {selectedOperation === 'add_group' && (
                <>
                  <div id="bm_sub_add_group" className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 max-w-lg mx-auto">
                  <div className="flex justify-between items-center border-b border-slate-100 pb-3 mb-4">
                    <h3 className="font-extrabold text-slate-800 text-sm">
                      {isGroupEditMode ? 'গ্রুপ তথ্য সংশোধন করুন' : 'নতুন গ্রুপ যুক্ত করুন'}
                    </h3>
                    <button 
                      onClick={() => setSelectedOperation('menu')}
                      className="text-xs text-slate-400 hover:text-slate-600 font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <ArrowLeft size={12} /> অপারেশন মেনু
                    </button>
                  </div>

                  <form onSubmit={handleSaveGroup} className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 mb-1">গ্রুপের নাম *</label>
                      <input 
                        type="text"
                        placeholder="যেমন: পদ্মা সমিতি"
                        value={groupNameInput}
                        onChange={(e) => setGroupNameInput(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs sm:text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-500 mb-1">গ্রুপ কোড *</label>
                      <input 
                        type="text"
                        placeholder="যেমন: PAD-01"
                        value={groupCodeInput}
                        onChange={(e) => setGroupCodeInput(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs sm:text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-500 mb-1">দায়িত্বপ্রাপ্ত মাঠ কর্মকর্তা *</label>
                      <select
                        value={groupStaffSelect}
                        onChange={(e) => setGroupStaffSelect(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs sm:text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500 bg-white"
                      >
                        {staffList
                          .filter((s) => s.branchId === staff.branchId)
                          .map((s) => (
                            <option key={s.id} value={s.staffId}>
                              {s.name} ({s.designation || 'মাঠ কর্মী'})
                            </option>
                          ))}
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-bold text-slate-500 mb-1">বৈঠকের দিন *</label>
                        <select
                          value={groupMeetingDayInput}
                          onChange={(e) => setGroupMeetingDayInput(e.target.value)}
                          className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs sm:text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500 bg-white"
                        >
                          <option value="শনিবার">শনিবার</option>
                          <option value="রবিবার">রবিবার</option>
                          <option value="সোমবার">সোমবার</option>
                          <option value="মঙ্গলবার">মঙ্গলবার</option>
                          <option value="বুধবার">বুধবার</option>
                          <option value="বৃহস্পতিবার">বৃহস্পতিবার</option>
                          <option value="শুক্রবার">শুক্রবার</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-500 mb-1">গ্রাম / এলাকা</label>
                        <input 
                          type="text"
                          placeholder="যেমন: চাঁদপুর"
                          value={groupVillageInput}
                          onChange={(e) => setGroupVillageInput(e.target.value)}
                          className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs sm:text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500"
                        />
                      </div>
                    </div>

                    <div className="flex gap-2 pt-2">
                      <button 
                        type="button" 
                        onClick={() => setSelectedOperation('menu')}
                        className="flex-1 py-2 bg-slate-200 rounded-xl text-xs font-bold text-slate-600"
                      >
                        বাতিল
                      </button>
                      <button 
                        type="submit" 
                        className="flex-1 py-2 bg-[#2f6ce5] hover:bg-[#1d59d1] text-white font-bold rounded-xl text-xs shadow-sm"
                      >
                        {isGroupEditMode ? 'হালনাগাদ করুন' : 'নিশ্চিত করুন'}
                      </button>
                    </div>
                  </form>
                </div>

                {/* Group List Table View - Requested by user */}
                <div className="mt-8 bg-white rounded-2xl border border-slate-200 shadow-sm p-6 max-w-4xl mx-auto">
                    <h3 className="font-extrabold text-slate-800 text-sm mb-4">গ্রুপ তালিকা (Group List)</h3>
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs text-left">
                        <thead className="text-slate-500 border-b border-slate-100">
                          <tr>
                            <th className="py-2 px-3">নাম</th>
                            <th className="py-2 px-3">কোড</th>
                            <th className="py-2 px-3">কর্মকর্তা</th>
                            <th className="py-2 px-3 text-center">অবস্থা</th>
                            <th className="py-2 px-3 text-center">অ্যাকশন</th>
                          </tr>
                        </thead>
                        <tbody className="text-slate-700 divide-y divide-slate-100">
                          {groupList.filter(g => g.branchId === staff.branchId).map((group) => {
                            const officer = staffList.find(s => s.id === group.assignedStaffId || s.staffId === group.assignedStaffId);
                            return (
                              <tr key={group.id} className="hover:bg-slate-50">
                                <td className="py-3 px-3 font-bold">{group.name}</td>
                                <td className="py-3 px-3">{group.code}</td>
                                <td className="py-3 px-3">{officer?.name || 'অনির্ধারিত'}</td>
                                <td className="py-3 px-3 text-center">
                                  <button
                                    onClick={() => {
                                      const updatedGroups = groupList.map(g => 
                                        g.id === group.id ? { ...g, isActive: g.isActive === false ? true : false } : g
                                      );
                                      setGroupList(updatedGroups);
                                    }}
                                    className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${group.isActive === false ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-700'}`}
                                  >
                                    {group.isActive === false ? 'নিষ্ক্রিয়' : 'সক্রিয়'}
                                  </button>
                                </td>
                                <td className="py-3 px-3 text-center">
                                  <div className="flex items-center justify-center gap-2">
                                    <button 
                                      onClick={() => openEditGroup(group)}
                                      className="text-blue-600 hover:text-blue-800"
                                      title="ইডিট"
                                    >
                                      <Edit size={14} />
                                    </button>
                                    <button 
                                      onClick={() => handleDeleteGroup(group)}
                                      className="text-rose-600 hover:text-rose-800"
                                      title="ডিলিট"
                                    >
                                      <Trash2 size={14} />
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </>
              )}

              {/* SECTION: GROUP OPERATION (LIST AND ACTIONS) - STYLED TO MATCH MOBILE MOCKUP */}
              {selectedOperation === 'group_operation' && (
                <div id="bm_sub_group_op" className="max-w-md mx-auto bg-[#f4f6f9] rounded-3xl overflow-hidden shadow-2xl border border-slate-300 animate-in fade-in duration-300">
                  
                  {/* 1. SOLID BLUE HEADER BAR WITH DATE & BRANCH */}
                  <div className="bg-[#2f6ce5] text-white px-5 py-4 flex items-center justify-between select-none">
                    <button
                      type="button"
                      onClick={() => setSelectedOperation('menu')}
                      className="p-1 -ml-1 rounded-full hover:bg-white/10 active:scale-90 transition-all cursor-pointer"
                      title="ফিরে যান"
                    >
                      <ChevronLeft className="w-6 h-6 text-white stroke-[2.5]" />
                    </button>
                    
                    <div className="text-center flex-1 flex flex-col items-center">
                      <span className="text-white font-extrabold text-sm sm:text-base leading-tight tracking-wide">
                        {new Date(workingDay).toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' })} {new Date(workingDay).toLocaleDateString('en-US', { weekday: 'short' })}
                      </span>
                      <span className="text-sky-100/90 text-[10px] sm:text-xs font-bold leading-tight tracking-snug mt-0.5">
                        {currentBranch?.name || 'প্রধান কার্যালয়'}
                      </span>
                    </div>

                    <div className="flex items-center gap-2.5 text-right font-sans">
                      <span className="text-[9px] text-[#93c5fd] font-extrabold select-none opacity-80">v: 4.0.42</span>
                      <button
                        type="button"
                        onClick={() => setSelectedOperation('menu')}
                        className="p-1 rounded-full hover:bg-white/10 active:scale-90 transition-all cursor-pointer"
                        title="মেনু"
                      >
                        <Power className="w-5 h-5 text-white stroke-[2]" />
                      </button>
                    </div>
                  </div>

                  {/* 2. STAFF PROFILE BAR WITH NAME & EMPLOYEE CODE */}
                  <div className="bg-white border-b border-slate-200 px-5 py-3.5 flex items-center gap-4">
                    <div className="w-11 h-11 rounded-full bg-[#2f6ce5]/10 border-2 border-[#2f6ce5]/30 flex items-center justify-center shrink-0">
                      <div className="w-8 h-8 rounded-full bg-[#2f6ce5] flex items-center justify-center text-white text-xs font-black select-none">
                        V
                      </div>
                    </div>
                    <div>
                      <div className="text-[9px] text-slate-400 font-extrabold uppercase tracking-wide">নিবন্ধিত কর্মকর্তা</div>
                      <div className="text-slate-800 font-extrabold text-sm sm:text-base leading-tight mt-0.5">
                        {staff.name} <span className="font-mono text-xs font-semibold text-slate-500 bg-slate-100 border border-slate-200 px-1.5 py-0.5 rounded-md ml-1.5">{staff.staffId || '009'}</span>
                      </div>
                    </div>
                  </div>

                  {/* BODY AREA */}
                  <div className="p-4 sm:p-5 space-y-6">
                    {activeCardView === 'member_admission' ? (
                      <MemberAdmissionForm
                        onBack={() => setActiveCardView('grid')}
                        branchGroups={branchGroups}
                        staff={staff}
                        org={org}
                        defaultGroupId={selectedGroupIdForSearch}
                        existingMembersCount={groupMembers.length}
                        onSuccess={handleMemberAdmissionSuccess}
                      />
                    ) : activeCardView === 'member_information' ? (
                      <MemberInformationView
                        onBack={() => setActiveCardView('grid')}
                        groupMembers={groupMembers}
                        branchGroups={branchGroups}
                        selectedGroupId={selectedGroupIdForSearch}
                        onUpdateStatus={handleUpdateMemberStatus}
                      />
                    ) : activeCardView === 'member_transaction' ? (
                      <MemberTransactionView
                        onBack={() => setActiveCardView('grid')}
                        groupId={selectedGroupIdForSearch}
                        branchGroups={branchGroups}
                        groupMembers={groupMembers}
                        onSaveTransactions={handleSaveTransactions}
                        staff={staff}
                      />
                    ) : activeCardView === 'loan_proposal' ? (
                      <LoanProposalView
                        onBack={() => setActiveCardView('grid')}
                        branchGroups={branchGroups}
                        groupMembers={groupMembers}
                        workingDay={workingDay}
                        org={org}
                        staff={staff}
                        defaultGroupId={selectedGroupIdForSearch}
                        onSuccess={handleLoanProposalSuccess}
                        holidays={holidays}
                      />
                    ) : activeCardView === 'loan_disburse' ? (
                      <LoanDisburseView
                        onBack={() => setActiveCardView('grid')}
                        branchGroups={branchGroups}
                        groupMembers={groupMembers}
                        workingDay={workingDay}
                        org={org}
                        staff={staff}
                        defaultGroupId={selectedGroupIdForSearch}
                        onSuccess={handleLoanDisburseSuccess}
                      />
                    ) : (
                      <>
                        {/* 3. GROUPS DROPDOWN SELECTOR */}
                        <div className="bg-white rounded-xl border border-slate-200 hover:border-[#2f6ce5]/40 p-2 shadow-2xs transition-all flex items-center gap-2">
                          <Layers className="w-5 h-5 text-[#2f6ce5] ml-2 shrink-0" />
                          <select
                            id="op_group_select"
                            className="w-full bg-transparent border-0 outline-none text-slate-755 font-black text-xs sm:text-sm cursor-pointer py-1.5 focus:ring-0"
                            value={selectedGroupIdForSearch}
                            onChange={(e) => {
                              const val = e.target.value;
                              setSelectedGroupIdForSearch(val);
                              setSelectedMemberIdForSearch('');
                            }}
                          >
                            <option value="" className="text-slate-400 font-bold">-- সমিতি / গ্রুপ নির্বাচন করুন --</option>
                            {branchGroups.map((g) => (
                              <option key={g.id} value={g.id} className="text-slate-800 font-bold">
                                {g.name} ({g.code}) - {g.meetingDay || 'শনিবার'}
                              </option>
                            ))}
                          </select>
                        </div>

                        {/* 4. USER ACTION MENUS TITLE */}
                        <div className="relative border-b-2 border-[#2f6ce5] pb-1.5">
                          <span className="inline-block bg-[#2f6ce5] text-white font-black text-[10px] sm:text-xs px-4 py-1.5 uppercase select-none tracking-wide">
                            User Action Menus
                          </span>
                        </div>

                        {/* 5. 10 BUTTON GRID SYSTEM WITH NO DEMO DATA / ACTIONS */}
                        <div className="grid grid-cols-2 gap-4 sm:gap-5 pb-2">
                          {[
                            { id: 'member_transaction', label: 'Member Transaction', icon: BookOpen, active: true },
                            { id: 'member_information', label: 'Member Information', icon: UserCheck, active: true },
                            { id: 'member_balance', label: 'Member Balance', icon: FileText, active: true },
                            { id: 'member_admission', label: 'Member Admission', icon: UserPlus, active: true },
                            { id: 'add_lts_account', label: 'Add LTS Account', icon: Coins, active: true },
                            { id: 'loan_disburse', label: 'Loan Disburse', icon: HandCoins, active: true },
                            { id: 'loan_proposal', label: 'Loan Proposal', icon: ClipboardList, active: true },
                            { id: 'add_cbs_account', label: 'Add CBS Account', icon: PiggyBank, active: true },
                            { id: 'add_savings_account', label: 'Add Savings Account', icon: DollarSign, active: true },
                            { id: 'return_request', label: 'Return Request', icon: ArrowLeftRight, active: true }
                          ].map((card) => {
                            const IconComponent = card.icon;
                            return (
                              <button
                                key={card.id}
                                type="button"
                                onClick={() => {
                                  if (card.id === 'member_admission') {
                                    setActiveCardView('member_admission');
                                  } else if (card.id === 'member_information') {
                                    setActiveCardView('member_information');
                                  } else if (card.id === 'member_transaction') {
                                    if (!selectedGroupIdForSearch) {
                                      setAlertMsg({ type: 'error', text: 'দয়া করে প্রথমে একটি সমিতি / গ্রুপ নির্বাচন করুন!' });
                                    } else {
                                      setActiveCardView('member_transaction');
                                    }
                                  } else if (card.id === 'loan_proposal') {
                                    if (!selectedGroupIdForSearch) {
                                      setAlertMsg({ type: 'error', text: 'দয়া করে প্রথমে একটি সমিতি / গ্রুপ নির্বাচন করুন!' });
                                    } else {
                                      setActiveCardView('loan_proposal');
                                    }
                                  } else if (card.id === 'loan_disburse') {
                                    if (!selectedGroupIdForSearch) {
                                      setAlertMsg({ type: 'error', text: 'দয়া করে প্রথমে একটি সমিতি / গ্রুপ নির্বাচন করুন!' });
                                    } else {
                                      setActiveCardView('loan_disburse');
                                    }
                                  } else {
                                    setAlertMsg({ type: 'info', text: `"${card.label}" মডিউলটি পরবর্তীতে সক্রিয় করা হবে।` });
                                  }
                                }}
                                className={`flex flex-col rounded-2xl overflow-hidden transition-all duration-200 cursor-pointer active:scale-95 group border ${
                                  card.active 
                                    ? 'border-amber-200 hover:border-amber-400 hover:shadow-xl shadow-[0_4px_12px_rgba(0,0,0,0.1)] bg-white' 
                                    : 'border-amber-100 shadow-[0_4px_10px_rgba(0,0,0,0.06)] bg-white/90 opacity-75'
                                } h-24 sm:h-26`}
                              >
                                <div className={`${card.active ? 'bg-[#2f6ce5] group-hover:bg-[#1d59d1]' : 'bg-[#85a1e0]'} py-2.5 sm:py-3 flex items-center justify-center w-full transition-colors`}>
                                  <IconComponent className="w-5 h-5 text-white stroke-[1.8]" />
                                </div>
                                <div className="bg-[#eaeaea] flex-1 px-2.5 flex items-center justify-center text-slate-850 font-black text-[10px] sm:text-xs text-center leading-tight">
                                  {card.label}
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      </>
                    )}
                  </div>
                </div>
              )}

              {/* SECTION: MOVE GROUP (TRANSFER) */}
              {selectedOperation === 'move_group' && (
                <div id="bm_sub_move_group" className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 max-w-lg mx-auto">
                  <div className="flex justify-between items-center border-b border-slate-100 pb-3 mb-4">
                    <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-1.5">
                      <ArrowLeftRight size={16} className="text-amber-500" />
                      গ্রুপ দ্বায়িত্ব হস্তান্তর (Move Group)
                    </h3>
                    <button 
                      onClick={() => setSelectedOperation('menu')}
                      className="text-xs text-slate-400 hover:text-slate-600 font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <ArrowLeft size={12} /> অপারেশন মেনু
                    </button>
                  </div>

                  {branchGroups.length === 0 ? (
                    <div className="text-center py-6 text-slate-400">
                      <p className="text-xs font-semibold">হস্তান্তর করার মতো কোনো গ্রুপ বিদ্যমান নেই।</p>
                      <p className="text-[10px] text-slate-400 mt-1">প্রথমে একটি গ্রুপ এড করুন।</p>
                    </div>
                  ) : (
                    <form onSubmit={handleMoveGroupAction} className="space-y-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-500 mb-1">কোন গ্রুপটি স্থানান্তর করবেন? *</label>
                        <select 
                          className="w-full px-3 py-2 border border-slate-250 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
                          value={moveGroupTargetId}
                          onChange={(e) => setMoveGroupTargetId(e.target.value)}
                          required
                        >
                          <option value="">-- গ্রুপ নির্বাচন করুন --</option>
                          {branchGroups.map(g => {
                            const matchedStaff = staffList.find(s => s.staffId === g.assignedStaffId || s.id === g.assignedStaffId);
                            return (
                              <option key={g.id} value={g.id}>
                                {g.name} ({g.code}) — বর্তমান দায়িত্ব: {matchedStaff?.name || 'অনির্ধারিত'}
                              </option>
                            );
                          })}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-500 mb-1">নতুন কার দায়িত্বে স্থানান্তর করবেন? *</label>
                        <select 
                          className="w-full px-3 py-2 border border-slate-250 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
                          value={moveGroupDestinationStaffId}
                          onChange={(e) => setMoveGroupDestinationStaffId(e.target.value)}
                          required
                        >
                          <option value="">-- নতুন কর্মকর্তা বা এও নির্বাচন করুন --</option>
                          {branchStaff.map(s => (
                            <option key={s.id} value={s.staffId || s.id}>
                              {s.name} ({s.staffId}) {s.onLeave ? '[ছুটিতে আছেন]' : ''}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="flex gap-2 pt-2">
                        <button 
                          type="button" 
                          onClick={() => setSelectedOperation('menu')}
                          className="flex-1 py-2.5 bg-slate-105 bg-slate-100 text-slate-605 text-slate-600 rounded-xl text-xs font-bold"
                        >
                          বাতিল
                        </button>
                        <button 
                          type="submit" 
                          className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded-xl text-xs transition shadow-sm"
                        >
                          হস্তান্তর নিশ্চিত করুন
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              )}

              {/* SECTION: LOAN PROPOSAL REQUESTS (BM DECISION INTERFACE) */}
              {selectedOperation === 'loan_proposal_requests' && (
                <div id="bm_sub_loan_proposal_requests" className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 max-w-4xl mx-auto animate-in fade-in duration-200">
                  <div className="flex justify-between items-center border-b border-slate-100 pb-3 mb-4">
                    <h3 className="font-extrabold text-slate-800 text-sm sm:text-base flex items-center gap-1.5">
                      <ClipboardList size={18} className="text-[#2f6ce5]" />
                      ঋণ প্রস্তাব রিকুয়েষ্ট ড্যাশবোর্ড (Loan Proposals Operations)
                    </h3>
                    <button 
                      onClick={() => setSelectedOperation('menu')}
                      className="text-xs text-slate-400 hover:text-slate-600 font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <ArrowLeft size={12} /> অপারেশন মেনু
                    </button>
                  </div>

                  {loanProposals.length === 0 ? (
                    <div className="text-center py-12 text-slate-400">
                      <ClipboardList className="w-12 h-12 text-slate-300 mx-auto mb-3 animate-bounce" />
                      <p className="text-xs font-black">কোনো ঋণ প্রস্তাব জমা দেওয়া হয়নি!</p>
                      <p className="text-[10px] text-slate-400 mt-1 font-medium">কর্মী বা অফিসার সাবমিট করলে এখানে রিকুয়েষ্ট জমা হবে।</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {/* Interactive Metrics */}
                      <div className="grid grid-cols-3 gap-3 text-center">
                        <div className="bg-slate-50 border border-slate-200/80 p-2.5 rounded-xl">
                          <span className="text-[9px] text-[#2f6ce5] font-extrabold uppercase">অপেক্ষমাণ (Pending)</span>
                          <strong className="text-sm font-black text-slate-800 block mt-0.5 font-sans">
                            {loanProposals.filter((p: any) => p.status === 'pending').length} টি
                          </strong>
                        </div>
                        <div className="bg-emerald-50 border border-emerald-100 p-2.5 rounded-xl">
                          <span className="text-[9px] text-emerald-600 font-extrabold uppercase">অনুমোদিত (Approved)</span>
                          <strong className="text-sm font-black text-emerald-800 block mt-0.5 font-sans">
                            {loanProposals.filter((p: any) => p.status === 'approved').length} টি
                          </strong>
                        </div>
                        <div className="bg-[#2f6ce5]/5 border border-sky-100 p-2.5 rounded-xl">
                          <span className="text-[9px] text-sky-600 font-extrabold uppercase">বিতরণকৃত (Disbursed)</span>
                          <strong className="text-sm font-black text-sky-800 block mt-0.5 font-sans">
                            {loanProposals.filter((p: any) => p.status === 'disbursed').length} টি
                          </strong>
                        </div>
                      </div>

                      {/* Proposals List Card / Table */}
                      <div className="overflow-x-auto rounded-xl border border-slate-250">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="bg-slate-100/80 border-b border-slate-200 text-[10px] sm:text-xs text-slate-600 font-extrabold uppercase select-none font-sans">
                              <th className="px-3.5 py-2.5 font-bold">সদস্য তথ্য</th>
                              <th className="px-3 py-2.5 font-bold text-center">পরিমাণ ও কিস্তি</th>
                              <th className="px-3 py-2.5 font-bold">উদ্দেশ্য / তারিখ</th>
                              <th className="px-3 py-2.5 font-bold">দাখিলকারী</th>
                              <th className="px-3 py-2.5 font-bold text-center">স্ট্যাটাস</th>
                              <th className="px-3 py-2.5 font-bold text-right">কার্যক্রম</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-150">
                            {loanProposals.map((proposalObj: any) => {
                              const isPending = proposalObj.status === 'pending';
                              const isApproved = proposalObj.status === 'approved';
                              const isDisbursed = proposalObj.status === 'disbursed';

                              // Approve handler
                              const handleApprove = (proposalId: string) => {
                                const updated = loanProposals.map((p) => {
                                  if (p.id === proposalId) {
                                    return { ...p, status: 'approved', approvedBy: staff.name, approvalDay: workingDay };
                                  }
                                  return p;
                                });
                                setLoanProposals(updated);
                                setAlertMsg({
                                  type: 'success',
                                  text: `ঋণ প্রস্তাবটি সফলভাবে অনুমোদন করা হয়েছে! এখন কর্মী এই ঋণ বিতরণ করতে পারবেন।`
                                });
                              };

                              // Decline/Reject handler
                              const handleReject = (proposalId: string) => {
                                const updated = loanProposals.filter((p) => p.id !== proposalId);
                                setLoanProposals(updated);
                                setAlertMsg({
                                  type: 'info',
                                  text: `ঋণ প্রস্তাবটি বাতিল ও অপসারণ করা হয়েছে!`
                                });
                              };

                              return (
                                <tr key={proposalObj.id} className="text-xs sm:text-xs hover:bg-slate-50/50">
                                  {/* Member Info */}
                                  <td className="px-3.5 py-3">
                                    <div className="font-bold text-slate-800">{proposalObj.memberName}</div>
                                    <div className="text-[10px] text-slate-500 font-mono mt-0.5">{proposalObj.memberIdText} · {proposalObj.groupName}</div>
                                  </td>

                                  {/* Amount & Installment details */}
                                  <td className="px-3 py-3 text-center">
                                    <div className="font-extrabold text-slate-800 font-mono">{proposalObj.amount} ৳</div>
                                    <div className="text-[9px] text-slate-500 font-semibold mt-0.5 font-mono">{proposalObj.installmentAmount}৳ × {proposalObj.installmentsCount} কিস্তি</div>
                                  </td>

                                  {/* Purpose & Date */}
                                  <td className="px-3 py-3">
                                    <div className="font-semibold text-slate-705 text-slate-700">{proposalObj.purpose}</div>
                                    <div className="text-[10px] text-slate-400 font-mono mt-0.5">{proposalObj.proposalDate}</div>
                                  </td>

                                  {/* Submitter */}
                                  <td className="px-3 py-3 text-slate-605 text-slate-600 font-bold">
                                    {proposalObj.createdBy}
                                  </td>

                                  {/* Status */}
                                  <td className="px-3 py-3 text-center">
                                    {isPending && (
                                      <span className="px-2 py-0.5 rounded-full text-[9px] font-black tracking-wide text-amber-700 bg-amber-50 border border-amber-200">
                                        অপেক্ষমাণ (Pending)
                                      </span>
                                    )}
                                    {isApproved && (
                                      <span className="px-2 py-0.5 rounded-full text-[9px] font-black tracking-wide text-emerald-700 bg-emerald-50 border border-emerald-200">
                                        অনুমোদিত (Approved)
                                      </span>
                                    )}
                                    {isDisbursed && (
                                      <span className="px-2 py-0.5 rounded-full text-[9px] font-black tracking-wide text-sky-700 bg-[#2f6ce5]/10 border border-sky-200">
                                        বিতরণকৃত (Disbursed)
                                      </span>
                                    )}
                                  </td>

                                  {/* Action Buttons */}
                                  <td className="px-3 py-3 text-right">
                                    {isPending ? (
                                      <div className="flex gap-1.5 justify-end">
                                        <button
                                          type="button"
                                          onClick={() => handleApprove(proposalObj.id)}
                                          className="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-[10px] px-2.5 py-1 rounded-lg shadow-2xs transition-all cursor-pointer"
                                        >
                                          অনুমোদন
                                        </button>
                                        <button
                                          type="button"
                                          onClick={() => handleReject(proposalObj.id)}
                                          className="bg-rose-50 hover:bg-rose-100 text-rose-700 font-extrabold text-[10px] px-2.5 py-1 rounded-lg border border-rose-200 transition-all cursor-pointer"
                                        >
                                          বাতিল
                                        </button>
                                      </div>
                                    ) : (
                                      <span className="text-[9px] text-slate-404 text-slate-400 font-bold italic font-sans">সম্পন্ন</span>
                                    )}
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              )}

            </div>
          ) : (
            <>
              {/* 2. REGULAR BM VIEWS (DASHBOARD, HRM, ACCOUNT) */}

              {/* TABS 1: DASHBOARD VIEW */}
              {activeTab === 'dashboard' && (
                <div id="bm_viewport_dashboard" className="space-y-6 animate-in fade-in duration-100">
                  
                  {/* Branch Brief Banner */}
                  <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                      <h2 className="text-lg font-black text-slate-800">শাখা বিবরণী ড্যাশবোর্ড (Branch Overview)</h2>
                      <p className="text-xs text-slate-500 font-medium mt-0.5">আপনার ব্রাঞ্চ অফিসের সকল কর্মকান্ড এবং কর্মীবাহিনীর অবস্থা পর্যবেক্ষণ করুন।</p>
                    </div>
                    <div className="bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-xl py-1 px-3 text-xs font-extrabold flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                      <span>শাখা সচল রয়েছে</span>
                    </div>
                  </div>

                  {/* STATISTICAL ROW */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    
                    {/* STAT A: Total Staff */}
                    <div className="bg-white rounded-2xl border border-slate-202 border-slate-200 p-4.5 space-y-2 relative overflow-hidden group">
                      <span className="p-2 bg-slate-150 bg-slate-100 rounded-lg inline-block text-slate-700">
                        <Users size={16} />
                      </span>
                      <p className="text-[11px] text-slate-500 font-bold block">মোট কর্মকর্তা ও কর্মী</p>
                      <p className="text-2xl font-black text-slate-850 text-slate-800">{totalStaffCount} জন</p>
                    </div>

                    {/* STAT B: Total Group */}
                    <div className="bg-white rounded-2xl border border-slate-200 p-4.5 space-y-2 relative overflow-hidden group">
                      <span className="p-2 bg-slate-100 text-slate-700 rounded-lg inline-block">
                        <Layers size={16} />
                      </span>
                      <p className="text-[11px] text-slate-500 font-bold block">মোট সঞ্চয়ী ও ঋণ গ্রুপ</p>
                      <p className="text-2xl font-black text-slate-800">{totalGroupsCount} টি</p>
                    </div>

                    {/* STAT C: Active Staff */}
                    <div className="bg-white rounded-2xl border border-slate-200 p-4.5 space-y-2 relative overflow-hidden group">
                      <span className="p-2 bg-emerald-50 text-emerald-700 rounded-lg inline-block">
                        <UserCheck size={16} />
                      </span>
                      <p className="text-[11px] text-slate-400 text-slate-500 font-bold block">কর্মরত মাঠ কর্মী (Active)</p>
                      <p className="text-2xl font-black text-emerald-600">{activeStaffCount} জন</p>
                    </div>

                    {/* STAT D: On Leave Staff */}
                    <div className="bg-white rounded-2xl border border-slate-200 p-4.5 space-y-2 relative overflow-hidden group">
                      <span className="p-2 bg-rose-50 text-rose-700 rounded-lg inline-block">
                        <UserX size={16} />
                      </span>
                      <p className="text-[11px] text-slate-500 font-bold block">ছুটিতে আছেন (On Leave)</p>
                      <p className="text-2xl font-black text-rose-600">{staffOnLeaveCount} জন</p>
                    </div>

                  </div>

                  {/* BRANCH POLICIES & QUICK LINKS */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    
                    {/* Panel 1: Branch Details information */}
                    <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3.5">
                      <h3 className="font-extrabold text-slate-800 text-sm border-b border-indigo-50 pb-2.5 flex items-center gap-1.5">
                        <BookOpen size={16} className="text-emerald-500" />
                        শাখা নিয়ন্ত্রণ ও কর্মপরিধি
                      </h3>
                      <div className="space-y-2.5 text-xs">
                        <div className="flex justify-between py-1 border-b border-slate-50">
                          <span className="text-slate-500">শাখার নাম:</span>
                          <span className="font-bold text-slate-800">হেড অফিস ও প্রধান নিয়ন্ত্রণ শাখা</span>
                        </div>
                        <div className="flex justify-between py-1 border-b border-slate-50">
                          <span className="text-slate-500">অনলাইন পোর্টাল আইডি:</span>
                          <span className="font-mono font-bold text-emerald-600">{staff.branchId || 'MAIN-HO'}</span>
                        </div>
                        <div className="flex justify-between py-1 border-b border-slate-50">
                          <span className="text-slate-500">নিবন্ধিত মোবাইল:</span>
                          <span className="font-bold text-slate-800">{staff.phone}</span>
                        </div>
                        <div className="flex justify-between py-1 border-b border-slate-50">
                          <span className="text-slate-500">দ্বায়িত্বরত প্রধান ব্যবস্থাপক:</span>
                          <span className="font-bold text-emerald-700 underline">{staff.name}</span>
                        </div>
                      </div>
                    </div>

                    {/* Panel 2: ILO stand-by mechanism info */}
                    <div className="bg-gradient-to-br from-indigo-50 to-emerald-50 rounded-2xl border border-slate-200 p-5 space-y-2">
                      <h4 className="font-black text-slate-850 text-slate-850 text-slate-800 text-xs sm:text-sm flex items-center gap-1.5">
                        <ShieldAlert size={16} className="text-indigo-600 shrink-0" />
                        স্ট্যান্ড-বাই ছুটি স্থানান্তর নীতি (ILO AO)
                      </h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed font-semibold">
                        সিস্টেমের নির্ভরযোগ্যতার স্বার্থে আপনার ব্রাঞ্চে একজন ডিফল্ট কর্মকর্তা <span className="font-bold text-indigo-700">"ILO" (আইডি: ILO, পাসওয়ার্ড: 12345)</span> স্বয়ংক্রিয়ভাবে বহাল থাকে।
                      </p>
                      <p className="text-[11.5px] text-slate-505 text-emerald-800 leading-relaxed font-bold">
                        যখনই আপনি কোনো মাঠ কর্মীকে এইচআরএম (HRM) থেকে ছুটিতে পাঠান, ওই কর্মকর্তার অধীনে চালিত সকল গ্রুপ ও সমিতির দৈনিক আদায় প্রক্রিয়া ব্যাহত হওয়া এড়াতে তাৎক্ষণিকভাবে ILO কর্মকর্তাতে স্থানান্তর করা হয়।
                      </p>
                    </div>

                  </div>

                </div>
              )}

              {/* TABS 2: HRM (STAFF OPERATIONS AND LEAVES) */}
              {activeTab === 'hrm' && (
                <div id="bm_viewport_hrm" className="space-y-6 animate-in fade-in duration-100">
                  
                  {/* HRM Action Header */}
                  <div className="flex justify-between items-center flex-wrap gap-4 border-b border-slate-100 pb-4">
                    <div>
                      <h2 className="text-lg font-extrabold text-slate-800 tracking-tight flex items-center gap-2">
                        <Users size={20} className="text-emerald-600" />
                        শাখা মানবসম্পদ প্যানেল (Branch HRM)
                      </h2>
                      <p className="text-xs text-slate-500 font-medium">
                        ব্রাঞ্চে নিয়োজিত কর্মকর্তাদের তথ্য সম্পাদন, নতুন নিয়োগ এবং ছুটিতে যাওয়া নিয়ন্ত্রণ করুন।
                      </p>
                    </div>
                    <button
                      id="bm_hrm_add_staff_btn"
                      onClick={() => {
                        setIsStaffEditMode(false);
                        setEditingStaffId(null);
                        setStaffNameInput('');
                        setStaffPhoneInput('');
                        setStaffDesignationInput('মাঠ কর্মী');
                        setIsStaffModalOpen(true);
                      }}
                      className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <Plus size={15} />
                      <span>নতুন কর্মী যুক্ত করুন</span>
                    </button>
                  </div>

                  {/* STAFF DATATABLE / LIST */}
                  <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="bg-slate-50 text-slate-500 text-[10px] sm:text-xs font-bold uppercase tracking-wider border-b border-slate-150">
                            <th className="py-3.5 px-4">নাম ও ফোন</th>
                            <th className="py-3.5 px-4">পদবি ও যোগদানের তারিখ</th>
                            <th className="py-3.5 px-4">ইউনিক আইডি ও পাসওয়ার্ড</th>
                            <th className="py-3.5 px-4 font-center">ছুটি ও অবস্থা</th>
                            <th className="py-3.5 px-4 text-right">কার্যক্রম</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-xs sm:text-xs text-slate-705">
                          {branchStaff.length === 0 ? (
                            <tr>
                              <td colSpan={5} className="py-12 text-center text-slate-400 font-medium text-xs">
                                বর্তমান ব্রাঞ্চে কোনো কর্মকর্তা তালিকাভুক্ত নেই।
                              </td>
                            </tr>
                          ) : (
                            branchStaff.map(s => {
                              // Check if staff is currently on-leave
                              const isOnLeave = (s as any).onLeave === true;
                              return (
                                <tr key={s.id} className="hover:bg-slate-50/50 transition">
                                  <td className="py-3.5 px-4 font-medium">
                                    <div className="space-y-0.5">
                                      <p className="font-extrabold text-slate-800 text-sm flex items-center gap-1.5">
                                        {s.name}
                                        {s.staffId?.startsWith('ILO') && (
                                          <span className="bg-amber-100 text-amber-800 text-[9px] font-bold px-1.5 py-0.5 rounded-md border border-amber-300">
                                            ডিফল্ট ব্যাকআপ
                                          </span>
                                        )}
                                      </p>
                                      <p className="text-[10px] text-slate-400 font-semibold">{s.phone}</p>
                                    </div>
                                  </td>
                                  
                                  <td className="py-3.5 px-4 text-slate-600">
                                    <div className="space-y-0.5">
                                      <p className="font-bold text-indigo-700">{s.designation}</p>
                                      <p className="text-[10px] text-slate-400 font-mono font-medium">নিয়োগ: {s.joiningDate || 'অনির্ধারিত'}</p>
                                    </div>
                                  </td>

                                  <td className="py-3.5 px-4">
                                    <div className="space-y-1 text-slate-550 font-mono text-[10px] bg-slate-50 p-1.5 rounded-lg border border-slate-100 inline-block min-w-[145px]">
                                      <div className="flex justify-between gap-2">
                                        <span className="text-slate-400">UID:</span>
                                        <span className="font-extrabold text-blue-700">{s.staffId || 'অনির্ধারিত'}</span>
                                      </div>
                                      <div className="flex justify-between gap-2">
                                        <span className="text-slate-400">পাসওয়ার্ড:</span>
                                        <span className="font-extrabold text-slate-700">{s.password || 'অনির্ধারিত'}</span>
                                      </div>
                                    </div>
                                  </td>

                                  <td className="py-3.5 px-4">
                                    {isOnLeave ? (
                                      <div className="space-y-1">
                                        <span className="bg-rose-50 text-rose-700 text-[10px] font-extrabold px-2 py-0.5 rounded-md border border-rose-150 inline-block">
                                          ● ছুটিতে আছেন
                                        </span>
                                        <p className="text-[9px] text-slate-500 font-semibold truncate max-w-[150px]" title={(s as any).leaveReason}>
                                          কারণ: {(s as any).leaveReason}
                                        </p>
                                        <p className="text-[9px] text-slate-400 font-mono">
                                          {(s as any).leaveStart} হতে {(s as any).leaveEnd}
                                        </p>
                                      </div>
                                    ) : (
                                      <span className="bg-emerald-50 text-emerald-700 text-[10px] font-extrabold px-2 py-0.5 rounded-md border border-emerald-150 inline-block">
                                        ● কর্মরত আছেন
                                      </span>
                                    )}
                                  </td>

                                  <td className="py-3.5 px-4 text-right">
                                    <div className="flex items-center justify-end gap-1.5">
                                      {/* GRANT LEAVE BUTTON */}
                                      {!isOnLeave ? (
                                        <button
                                          onClick={() => {
                                            setLeaveStaffTarget(s);
                                            setIsLeaveModalOpen(true);
                                          }}
                                          className="text-[10px] bg-amber-50 hover:bg-amber-100 text-amber-700 font-extrabold py-1 px-2.5 rounded-lg border border-amber-200 transition"
                                          title="ছুটি মঞ্জুর করুন"
                                        >
                                          ছুটি দিন
                                        </button>
                                      ) : (
                                        <button
                                          onClick={() => handleCancelLeave(s)}
                                          className="text-[10px] bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-extrabold py-1 px-2.5 rounded-lg border border-emerald-250 transition"
                                          title="ছুটি ক্যানসেল করুন"
                                        >
                                          ছুটি বাতিল
                                        </button>
                                      )}

                                      {/* EDIT BUTTON (Skip system ILO) */}
                                      {!s.staffId?.startsWith('ILO') && (
                                        <button
                                          onClick={() => openEditStaff(s)}
                                          className="p-1 px-2 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-550 transition"
                                          title="কর্মী তথ্য সংশোধন"
                                        >
                                          <Edit size={12} />
                                        </button>
                                      )}

                                      {/* DELETE BUTTON (Skip system ILO) */}
                                      {!s.staffId?.startsWith('ILO') && (
                                        <button
                                          onClick={() => handleDeleteStaff(s)}
                                          className="p-1 px-2 bg-rose-50 hover:bg-rose-100 rounded-lg text-rose-650 transition"
                                          title="কর্মী ডিলিট"
                                        >
                                          <Trash2 size={12} />
                                        </button>
                                      )}
                                    </div>
                                  </td>
                                </tr>
                              );
                            })
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>

                </div>
              )}

              {/* TABS: HOLIDAYS VIEW / ছুটি ক্যালেন্ডার */}
              {activeTab === 'holidays' && (
                <div id="bm_viewport_holidays" className="space-y-6 animate-in fade-in duration-100">
                  
                  {/* Top Header */}
                  <div className="flex justify-between items-center flex-wrap gap-4 border-b border-slate-100 pb-4">
                    <div>
                      <h2 className="text-lg font-extrabold text-slate-800 tracking-tight flex items-center gap-2">
                        <Calendar size={20} className="text-emerald-600" />
                        সংগঠনের বার্ষিক ছুটি ক্যালেন্ডার (Holidays)
                      </h2>
                      <p className="text-xs text-slate-500 font-semibold font-sans">
                        প্রাক-ঘোষিত পরবর্তী ৩ বছরের ছুটির তালিকা ও সাপ্তাহিক বন্ধের দিনসমূহ দেখুন ও নতুন ছুটি ঘোষণা করুন।
                      </p>
                    </div>
                    <div className="flex items-center gap-2.5">
                      <button
                        type="button"
                        onClick={() => {
                          setEditingHolidayId(null);
                          setHolidayType('direct');
                          setHolidayName('');
                          setHolidayDate(workingDay || new Date().toISOString().split('T')[0]);
                          setHolidayDayOfWeek('শুক্রবার');
                          setIsHolidayModalOpen(true);
                        }}
                        className="px-4.5 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-extrabold text-xs rounded-xl flex items-center gap-1.5 transition duration-150 shadow-xs cursor-pointer text-center"
                      >
                        <Plus size={15} />
                        <span>নতুন ছুটি ঘোষণা</span>
                      </button>
                    </div>
                  </div>

                  {/* Informative Guidance Callout block */}
                  <div className="bg-amber-50/75 border border-amber-200 rounded-2xl p-4 flex gap-3 text-xs text-amber-950 leading-relaxed max-w-4xl">
                    <Info size={18} className="text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-extrabold text-amber-955 mb-1 text-xs">ক্যালেন্ডারে সরকারি ছুটির নির্দেশিকা ও তথ্য:</h4>
                      <p className="mb-0.5">
                        ১. <strong>স্বয়ংক্রিয় সরকারি ছুটিসমূহ:</strong> এই সিস্টেমে ২০২৬, ২০২৭ এবং ২০২৮ সালের সমস্ত প্রধান প্রধান সরকারি ও জাতীয় ছুটিসমূহ ইতোমধ্যে প্রাক-ঘোষিত রয়েছে।
                      </p>
                      <p className="mb-0.5">
                        ২. <strong>জুন মাসের বিবরণ:</strong> সিস্টেমে কাজের তারিখ অনুযায়ী বর্তমান মাস হচ্ছে <strong>জুন ২০২৬</strong>। জুনের পুরো মাসে সাপ্তাহিক ছুটি (শুক্রবার) ছাড়া সরকারি কোনো সাধারণ ছুটি নেই। পূর্ববর্তী বা পরবর্তী মাসগুলোতে (যেমন: ফেব্রুয়ারি ২০২৬, মার্চ ২০২৬ ইত্যাদি) সুন্দরভাবে সব সরকারি লাল চিহ্নিত ছুটির দিন দেখতে পাবেন।
                      </p>
                      <p>
                        ৩. <strong>নতুন ছুটির ঘোষণা:</strong> আপনি যেকোনো বিশেষ ছুটির দিন বা সাপ্তাহিক ছুটির দিন যুক্ত করতে <strong>"নতুন ছুটি ঘোষণা"</strong> বাটনটি ব্যবহার করতে পারেন।
                      </p>
                    </div>
                  </div>

                  {/* Holiday Summary KPIs at a Glance */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-4 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                        <Calendar size={18} />
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-400 font-bold block font-sans">২০২৬ সালের ছুটি</p>
                        <h5 className="text-base font-black text-slate-800">{holidays.filter(h => h.type === 'direct' && h.date?.startsWith('2026')).length} টি</h5>
                      </div>
                    </div>

                    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-4 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-violet-50 text-violet-600 flex items-center justify-center font-bold">
                        <Calendar size={18} />
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-400 font-bold block font-sans">২০২৭ সালের ছুটি</p>
                        <h5 className="text-base font-black text-slate-800">{holidays.filter(h => h.type === 'direct' && h.date?.startsWith('2027')).length} টি</h5>
                      </div>
                    </div>

                    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-4 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-fuchsia-50 text-fuchsia-600 flex items-center justify-center font-bold">
                        <Calendar size={18} />
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-400 font-bold block font-sans">২০২৮ সালের ছুটি</p>
                        <h5 className="text-base font-black text-slate-800">{holidays.filter(h => h.type === 'direct' && h.date?.startsWith('2028')).length} টি</h5>
                      </div>
                    </div>

                    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-4 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center font-bold">
                        <Clock size={18} />
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-400 font-bold block font-sans">নিয়মিত সাপ্তাহিক সাধারণ বন্ধ</p>
                        <h5 className="text-base font-black text-slate-800">{holidays.filter(h => h.type === 'general').length} দিন</h5>
                      </div>
                    </div>
                  </div>

                  {/* Filters and Search Bar */}
                  <div className="bg-white rounded-2xl border border-slate-200/85 p-4 flex flex-wrap gap-4 items-center justify-between shadow-xs">
                    {/* Year Select Tabs */}
                    <div className="flex gap-1 bg-slate-100 p-1.5 rounded-xl">
                      {['all', '2026', '2027', '2028'].map((year) => {
                        const lable = year === 'all' ? 'সকল বছর' : year + ' সাল';
                        return (
                          <button
                            key={year}
                            type="button"
                            onClick={() => setHolidayYearFilter(year)}
                            className={`px-3 py-1.5 rounded-lg font-bold text-xs cursor-pointer transition ${
                              holidayYearFilter === year 
                                ? 'bg-emerald-600 text-white shadow-xs' 
                                : 'text-slate-600 hover:text-slate-800 hover:bg-slate-200/60'
                            }`}
                          >
                            {lable}
                          </button>
                        );
                      })}
                    </div>

                    {/* Search Bar */}
                    <div className="relative w-full sm:w-72">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400 pointer-events-none">
                        <Search size={14} />
                      </span>
                      <input
                        type="text"
                        value={holidaySearchQuery}
                        onChange={(e) => setHolidaySearchQuery(e.target.value)}
                        placeholder="ছুটির নাম বা কারণ খুঁজুন..."
                        className="w-full pl-9 pr-4 py-1.5 border border-slate-200 rounded-xl text-xs bg-slate-5 font-semibold text-slate-700 placeholder:text-slate-400 focus:outline-emerald-600"
                      />
                      {holidaySearchQuery && (
                        <button 
                          type="button"
                          onClick={() => setHolidaySearchQuery('')} 
                          className="absolute inset-y-0 right-0 flex items-center pr-3 text-slate-400 hover:text-slate-600"
                        >
                          <X size={12} />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Main Contents Grid */}
                  <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                    
                    {/* Panel 1: Direct public holidays (At a glance grouped by month) */}
                    <div className="xl:col-span-2 bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 space-y-4">
                      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600">
                            <Calendar size={16} />
                          </div>
                          <div>
                            <h4 className="font-extrabold text-slate-800 text-sm">ঘোষিত নির্দিষ্ট সরকারি ছুটির দিনসমূহ (Direct Holidays)</h4>
                            <p className="text-[10px] text-slate-400">ছুটি সহজে তদারকির জন্য নিচে মাস ভিত্তিক সাজানো তালিকায় দেখানো হলো</p>
                          </div>
                        </div>
                      </div>

                      {/* Month group view helper */}
                      {(() => {
                        const monthsBN = [
                          { value: 1, name: 'জানুয়ারি' },
                          { value: 2, name: 'ফেব্রুয়ারি' },
                          { value: 3, name: 'মার্চ' },
                          { value: 4, name: 'এপ্রিল' },
                          { value: 5, name: 'মে' },
                          { value: 6, name: 'জুন' },
                          { value: 7, name: 'জুলাই' },
                          { value: 8, name: 'আগস্ট' },
                          { value: 9, name: 'সেপ্টেম্বর' },
                          { value: 10, name: 'অক্টোবর' },
                          { value: 11, name: 'নভেম্বর' },
                          { value: 12, name: 'ডিসেম্বর' },
                        ];

                        const filteredHolidays = holidays.filter(h => {
                          if (h.type !== 'direct') return false;
                          if (holidaySearchQuery) {
                            const q = holidaySearchQuery.toLowerCase();
                            if (!h.name.toLowerCase().includes(q) && !(h.date && h.date.includes(q))) return false;
                          }
                          if (holidayYearFilter !== 'all' && h.date) {
                            if (!h.date.startsWith(holidayYearFilter)) return false;
                          }
                          return true;
                        });

                        if (filteredHolidays.length === 0) {
                          return (
                            <div className="py-16 text-center text-slate-400 border-2 border-dashed border-slate-100 rounded-2xl">
                              <Calendar size={32} className="mx-auto text-slate-300 mb-2.5 stroke-1" />
                              <p className="text-xs font-bold text-slate-500">কোনো নির্দিষ্ট ছুটি সচল বা খুঁজে পাওয়া যায়নি।</p>
                            </div>
                          );
                        }

                        // Group by year, then month
                        const years = holidayYearFilter === 'all' ? ['2026', '2027', '2028'] : [holidayYearFilter];

                        return (
                          <div className="space-y-6 max-h-[600px] overflow-y-auto pr-1">
                            {years.map(yr => {
                              const yrHolidays = filteredHolidays.filter(h => h.date?.startsWith(yr));
                              if (yrHolidays.length === 0) return null;

                              return (
                                <div key={yr} className="space-y-3.5">
                                  <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-100">
                                    <span className="font-black text-xs text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-lg">{yr}</span>
                                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">বছরের নির্ধারিত ছুটির ক্যালেন্ডার</span>
                                  </div>

                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                                    {monthsBN.map(m => {
                                      const mHolidays = yrHolidays.filter(h => {
                                        if (!h.date) return false;
                                        const monthPart = parseInt(h.date.split('-')[1], 0); // Wait, let's parse safely with 10 base
                                        return monthPart === m.value;
                                      });

                                      if (mHolidays.length === 0) return null;

                                      return (
                                        <div key={m.value} className="bg-slate-50/40 rounded-xl p-3 border border-slate-150/50 space-y-2">
                                          <h5 className="text-xs font-black text-slate-700 border-b border-slate-150/50 pb-1.5 flex justify-between items-center font-sans">
                                            <span>📅 {m.name}</span>
                                            <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
                                              {mHolidays.length} টি
                                            </span>
                                          </h5>

                                          <div className="space-y-1.5">
                                            {mHolidays.map(h => (
                                              <div key={h.id} className="p-2 bg-white rounded-lg border border-slate-100 shadow-3xs flex items-center justify-between text-xs font-bold font-sans hover:shadow-xs transition duration-155 group">
                                                <div className="space-y-0.5 max-w-[70%] text-left">
                                                  <p className="text-slate-800 text-[11px] leading-tight font-extrabold">{h.name}</p>
                                                  <p className="text-[9px] text-emerald-700 font-semibold">
                                                    📅 {h.date}
                                                  </p>
                                                </div>
                                                <div className="flex items-center gap-1 transition duration-150">
                                                  <button
                                                    type="button"
                                                    onClick={() => handleEditHoliday(h)}
                                                    className="p-1 hover:bg-slate-100 text-slate-500 hover:text-blue-600 border border-slate-100 hover:border-slate-200 rounded-lg cursor-pointer"
                                                    title="সংশোধন করুন"
                                                  >
                                                    <Edit size={11} className="text-blue-600" />
                                                  </button>
                                                  <button
                                                    type="button"
                                                    onClick={() => handleDeleteHoliday(h.id, h.name)}
                                                    className="p-1 hover:bg-rose-50 text-rose-500 hover:text-rose-700 border border-slate-100 hover:border-rose-200 rounded-lg cursor-pointer"
                                                    title="মুছে ফেলুন"
                                                  >
                                                    <Trash2 size={11} className="text-rose-600" />
                                                  </button>
                                                </div>
                                              </div>
                                            ))}
                                          </div>
                                        </div>
                                      );
                                    })}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        );
                      })()}
                    </div>

                    {/* Panel 2: General/weekly holidays */}
                    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 space-y-4 h-fit">
                      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-600">
                            <Clock size={16} />
                          </div>
                          <div>
                            <h4 className="font-extrabold text-slate-800 text-sm">নিয়মিত সাপ্তাহিক ছুটিসমূহ (Weekly Holidays)</h4>
                            <p className="text-[10px] text-slate-400 font-semibold font-sans">সাপ্তাহিক সাধারণ কর্মবিরতি</p>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        {holidays.filter(h => h.type === 'general').length === 0 ? (
                          <div className="py-12 text-center text-slate-400 border-2 border-dashed border-slate-100 rounded-2xl">
                            <Clock size={28} className="mx-auto text-slate-300 mb-2.5 stroke-1" />
                            <p className="text-xs font-semibold">কোনো সাধারণ বা সাপ্তাহিক ছুটি ঘোষিত নেই।</p>
                          </div>
                        ) : (
                          holidays.filter(h => h.type === 'general').map((holiday) => (
                            <div 
                              key={holiday.id} 
                              className="p-3 bg-slate-50 border border-slate-205/50 rounded-xl transition flex items-center justify-between gap-3 text-xs font-semibold hover:shadow-xs transition duration-150 group"
                            >
                              <div className="space-y-1">
                                <div className="flex items-center gap-1.5 font-bold text-slate-800 text-xs">
                                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                                  <span>{holiday.name}</span>
                                </div>
                                <p className="font-extrabold text-emerald-700 text-[10px] bg-emerald-50 px-2 py-0.5 rounded-md inline-block">
                                  প্রতি সপ্তাহের: <span className="underline">{holiday.dayOfWeek}</span>
                                </p>
                              </div>
                              <div className="flex items-center gap-1 transition duration-150 shrink-0">
                                <button
                                  type="button"
                                  onClick={() => handleEditHoliday(holiday)}
                                  className="p-1.5 hover:bg-white border border-slate-200 rounded-lg text-blue-600 cursor-pointer shadow-3xs"
                                  title="সংশোধন করুন"
                                >
                                  <Edit size={12} className="text-blue-600" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteHoliday(holiday.id, holiday.name)}
                                  className="p-1.5 hover:bg-white border border-slate-200 rounded-lg text-rose-600 cursor-pointer shadow-3xs"
                                  title="মুছে ফেলুন"
                                >
                                  <Trash2 size={12} className="text-rose-600" />
                                </button>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>

                  </div>

                </div>
              )}

              {/* TABS 3: ACCOUNT VIEW (BRANCH LEDGER SUMMARY) */}
              {activeTab === 'account' && (
                <div id="bm_viewport_account" className="space-y-6 animate-in fade-in duration-100">
                  
                  {/* Account brief summary cards */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                    <div className="bg-white rounded-2xl border border-slate-200 p-5 flex items-center justify-between">
                      <div className="space-y-1">
                        <span className="text-[10px] font-bold text-slate-400 block">শাখা দৈনিক জমার খাতা</span>
                        <p className="text-xl font-black text-emerald-600">➕ ৳{totalIncome}</p>
                      </div>
                      <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
                        <DollarSign size={20} />
                      </div>
                    </div>

                    <div className="bg-white rounded-2xl border border-slate-200 p-5 flex items-center justify-between">
                      <div className="space-y-1">
                        <span className="text-[10px] font-bold text-slate-400 block">শাখা দৈনিক খরচের খাতা</span>
                        <p className="text-xl font-black text-rose-600">➖ ৳{totalExpense}</p>
                      </div>
                      <div className="p-3 bg-rose-50 text-rose-600 rounded-xl">
                        <DollarSign size={20} />
                      </div>
                    </div>

                    <div className="bg-white rounded-2xl border border-slate-200 p-5 flex items-center justify-between">
                      <div className="space-y-1">
                        <span className="text-[10px] font-bold text-slate-400 block">মোট নিট ক্যাশ ব্যালেন্স</span>
                        <p className="text-xl font-black text-indigo-750 text-slate-800">৳{netBalance}</p>
                      </div>
                      <span className="text-[10px] py-0.5 px-2 bg-indigo-50 text-indigo-700 font-extrabold rounded-md">নিট লাভ</span>
                    </div>

                  </div>

                  {/* Interactive Accounting list and Add transaction */}
                  <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 space-y-4">
                    <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                      <div>
                        <h4 className="font-bold text-slate-800 text-sm">শাখার স্বাধীন হিসাব বই (Branch Ledger Block)</h4>
                        <p className="text-[10px] text-slate-400 font-medium">কোনো ডেমো ডাটা ব্যতীত বাস্তব সংগৃহীত তথ্য ট্র্যাক করার তালিকা</p>
                      </div>
                      <button
                        onClick={() => {
                          setTxType('income');
                          setTxCategory('ভর্তিকরণ ফি');
                          setTxAmount('');
                          setTxNote('');
                          setIsTxModalOpen(true);
                        }}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-[11px] rounded-lg cursor-pointer"
                      >
                        নতুন লেনদেন ভাউচার
                      </button>
                    </div>

                    {transactions.length === 0 ? (
                      <div className="text-center py-12 text-slate-400 border border-dashed border-slate-100 rounded-xl">
                        <CreditCard size={28} className="mx-auto text-slate-350 stroke-1 mb-2" />
                        <p className="text-xs font-semibold">শাখার কোনো লেনদেন ভাউচার এখনো রেকর্ড করা হয়নি।</p>
                        <p className="text-[9px] text-slate-400">নতুন ভাউচার যুক্ত করতে "নতুন লেনদেন" বাটনে ক্লিক করুন।</p>
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="w-full text-left font-sans text-xs">
                          <thead>
                            <tr className="bg-slate-50 text-slate-500 font-bold border-b border-slate-100">
                              <th className="py-2 px-3">লেনদেন আইডি</th>
                              <th className="py-2 px-3">ধরন</th>
                              <th className="py-2 px-3">খাত / বিবরণী</th>
                              <th className="py-2 px-3">পরিমাণ</th>
                              <th className="py-2 px-3">তারিখ ও নোট</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {transactions.map(t => (
                              <tr key={t.id} className="hover:bg-slate-50/50">
                                <td className="py-2.5 px-3 font-mono font-bold text-blue-600">{t.id}</td>
                                <td className="py-2.5 px-3 font-bold">
                                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                    t.type === 'income' ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                                  }`}>
                                    {t.type === 'income' ? 'আয়' : 'ব্যয়'}
                                  </span>
                                </td>
                                <td className="py-2.5 px-3 font-bold text-slate-800">{t.category}</td>
                                <td className={`py-2.5 px-3 font-black text-sm ${t.type === 'income' ? 'text-emerald-605 text-emerald-700' : 'text-rose-605 text-rose-700'}`}>
                                  ৳{t.amount}
                                </td>
                                <td className="py-2.5 px-3">
                                  <p className="font-medium text-slate-500 text-[10px]">{t.note}</p>
                                  <p className="text-[9px] text-slate-400 font-mono leading-none">{t.addDate}</p>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>

                </div>
              )}
            </>
          )}

          {/* -------------------- DYNAMIC RENDER END -------------------- */}

        </div>
      </main>
      </div>

      {/* ==================== HRM ADD/EDIT STAFF MODAL ==================== */}
      {isStaffModalOpen && (
        <div id="bm_modal_hrm_staff" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white p-6 rounded-2xl w-full max-w-sm shadow-2xl relative">
            <h3 className="text-base font-extrabold text-slate-800 mb-4 flex items-center gap-1.5">
              <Users size={18} className="text-emerald-600" />
              {isStaffEditMode ? 'কর্মী তথ্য সম্পাদন করুন' : 'নতুন কর্মকর্তা বা মাঠ কর্মী সংযোজন'}
            </h3>

            <form onSubmit={handleSaveStaff} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">কর্মকর্তা / কর্মীর নাম *</label>
                <input 
                  type="text" 
                  placeholder="যেমন: জনাব আবদুর রহমান" 
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs sm:text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  value={staffNameInput}
                  onChange={(e) => setStaffNameInput(e.target.value)}
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">রেজিস্টার্ড মোবাইল নম্বর *</label>
                <input 
                  type="tel" 
                  placeholder="যেমন: 01712xxxxxx" 
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs sm:text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500" 
                  value={staffPhoneInput}
                  onChange={(e) => setStaffPhoneInput(e.target.value)}
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">পদবি / Designation *</label>
                <select
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs sm:text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  value={staffDesignationInput}
                  onChange={(e) => setStaffDesignationInput(e.target.value)}
                >
                  <option value="মাঠ কর্মী">মাঠ কর্মী (Field Officer - FO)</option>
                  <option value="এলাকা কর্মকর্তা">এলাকা কর্মকর্তা (AO)</option>
                  <option value="শাখা ব্যবস্থাপক">শাখা ব্যবস্থাপক (BM)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">যোগদানের তারিখ *</label>
                <input 
                  type="date" 
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs sm:text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500" 
                  value={staffJoiningDateInput}
                  onChange={(e) => setStaffJoiningDateInput(e.target.value)}
                  required
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button 
                  type="button" 
                  onClick={() => setIsStaffModalOpen(false)} 
                  className="flex-1 py-2 bg-slate-200 rounded-xl text-xs font-bold text-slate-600"
                >
                  বাতিল
                </button>
                <button 
                  type="submit" 
                  className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-sm shadow-emerald-500/10"
                >
                  {isStaffEditMode ? 'হালনাগাদ করুন' : 'নিশ্চিত করুন'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================== GRANT LEAVE MODAL ==================== */}
      {isLeaveModalOpen && leaveStaffTarget && (
        <div id="bm_modal_hrm_leave" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white p-6 rounded-2xl w-full max-w-sm shadow-2xl">
            <div className="flex items-start gap-3 mb-4">
              <div className="p-2 bg-amber-50 text-amber-600 rounded-lg shrink-0">
                <Calendar size={18} />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-slate-800">অফিসিয়াল ছুটি প্রদান এবং গ্রুপ স্থানান্তর</h3>
                <p className="text-[10px] text-slate-400 font-medium">কর্মী: {leaveStaffTarget.name} ({leaveStaffTarget.designation})</p>
              </div>
            </div>

            <div className="mb-4 p-2.5 bg-yellow-50 border border-yellow-250 text-yellow-805 rounded-xl text-[10px] text-amber-800 font-semibold leading-relaxed">
              ⚠️ সতর্কবার্তা: কর্মী ছুটিতে যাওয়ার মধ্যবর্তী সময়ে তার অধীনে থাকা দল/গ্রুপ সমূহকে সচল রাখতে স্বয়ংক্রিয়ভাবে সিস্টেমের স্ট্যান্ডবাই "ILO" অফিসারের দায়িত্বে স্থানান্তর করা হবে!
            </div>

            <form onSubmit={handleGrantLeave} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">ছুটির কারণ / খসড়া মন্তব্য *</label>
                <input 
                  type="text" 
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:outline-none" 
                  value={leaveReason}
                  onChange={(e) => setLeaveReason(e.target.value)}
                  placeholder="যেমন: গুরুতর অসুস্থতা, বিবাহ জনিত ছুটি"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">ছুটির শুরু *</label>
                  <input 
                    type="date" 
                    className="w-full px-2 py-1.5 border border-slate-200 rounded-xl text-xs focus:outline-none" 
                    value={leaveStart}
                    onChange={(e) => setLeaveStart(e.target.value)}
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">ছুটির সমাপ্তি *</label>
                  <input 
                    type="date" 
                    className="w-full px-2 py-1.5 border border-slate-200 rounded-xl text-xs focus:outline-none" 
                    value={leaveEnd}
                    onChange={(e) => setLeaveEnd(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button 
                  type="button" 
                  onClick={() => { setIsLeaveModalOpen(false); setLeaveStaffTarget(null); }} 
                  className="flex-1 py-2 bg-slate-200 rounded-xl text-xs font-bold text-slate-605"
                >
                  বাতিল
                </button>
                <button 
                  type="submit" 
                  className="flex-1 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded-xl text-xs"
                >
                  ছুটি ও গ্রুপ বদলি মঞ্জুর
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================== ACCOUNTS NEW TRANSACTION VOUCHER MODAL ==================== */}
      {isTxModalOpen && (
        <div id="bm_modal_tx_vou" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white p-6 rounded-2xl w-full max-w-sm shadow-2xl">
            <h3 className="text-base font-extrabold text-slate-800 mb-4 flex items-center gap-1.5">
              <CreditCard size={18} className="text-emerald-600" />
              নতুন দৈনিক লেনদেন ভাউচার
            </h3>

            <form onSubmit={handleSaveTransaction} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">লেনদেন ধরন</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => { setTxType('income'); setTxCategory('ভর্তিকরণ ফি'); }}
                    className={`py-1 rounded-xl text-xs font-bold border transition ${
                      txType === 'income' ? 'bg-emerald-50 text-emerald-700 border-emerald-305' : 'bg-slate-50 text-slate-600 border-transparent'
                    }`}
                  >
                    আয় (Income)
                  </button>
                  <button
                    type="button"
                    onClick={() => { setTxType('expense'); setTxCategory('অফিস ভাড়া'); }}
                    className={`py-1 rounded-xl text-xs font-bold border transition ${
                      txType === 'expense' ? 'bg-rose-50 text-rose-700 border-rose-305' : 'bg-slate-50 text-slate-600 border-transparent'
                    }`}
                  >
                    ব্যয় (Expense)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">খাত / বিবরণী *</label>
                {txType === 'income' ? (
                  <select 
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:outline-none"
                    value={txCategory}
                    onChange={(e) => setTxCategory(e.target.value)}
                  >
                    <option value="ভর্তিকরণ ফি">ভর্তিকরণ ফি (Admission Fee)</option>
                    <option value="ঋণ বই ও ফর্ম বিক্রয়">ঋণ বই ও ফর্ম বিক্রয়</option>
                    <option value="ঋণ প্রসেসিং ফি">ঋণ প্রসেসিং ফি</option>
                    <option value="টাকা উত্তোলন সার্ভিস চার্জ">টাকা উত্তোলন চার্জ</option>
                  </select>
                ) : (
                  <select 
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:outline-none"
                    value={txCategory}
                    onChange={(e) => setTxCategory(e.target.value)}
                  >
                    <option value="অফিস ভাড়া">অফিস ভাড়া</option>
                    <option value="বিদ্যুৎ বিল">বিদ্যুৎ ও ইণ্টারনেট বিল</option>
                    <option value="স্টেশনারি ও যাতায়াত">স্টেশনারি ও যাতায়াত ব্যয়</option>
                    <option value="মনোরঞ্জন ও অন্যান্য">মনোরঞ্জন ও অন্যান্য খরচ</option>
                  </select>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-505 mb-1">টাকার পরিমাণ (টাকায়) *</label>
                <input 
                  type="text" 
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:outline-none"
                  value={txAmount}
                  onChange={(e) => setTxAmount(e.target.value)}
                  placeholder="যেমন: 500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">অতিরিক্ত নোট / মন্তব্য</label>
                <input 
                  type="text" 
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:outline-none"
                  value={txNote}
                  onChange={(e) => setTxNote(e.target.value)}
                  placeholder="সংক্ষিপ্ত বিবরণ"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button type="button" onClick={() => setIsTxModalOpen(false)} className="flex-1 py-2 bg-slate-200 rounded-xl text-xs font-bold">বাতিল</button>
                <button type="submit" className="flex-1 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold">সংরক্ষণ করুন</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Change BM/Staff Password */}
      {isChangePasswordModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-100">
          <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-100 animate-in zoom-in-95 duration-150">
            <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200/80 flex justify-between items-center">
              <h3 className="font-bold text-slate-800 text-xs sm:text-sm flex items-center gap-1.5">
                <Key size={16} className="text-emerald-600" /> শাখা পাসওয়ার্ড পরিবর্তন
              </h3>
              <button 
                type="button"
                onClick={() => setIsChangePasswordModalOpen(false)} 
                className="text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>
            
            <form onSubmit={handleBMChangePassword} className="p-5 space-y-4">
              
              {passwordChangeSuccess ? (
                <div className="p-4 bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-xl text-center text-xs font-bold space-y-1">
                  <p>{passwordChangeSuccess}</p>
                </div>
              ) : (
                <>
                  <div className="space-y-3">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-500 mb-1">নতুন পাসওয়ার্ড *</label>
                      <input 
                        type="password" 
                        className="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:outline-none font-bold"
                        placeholder="নতুন পাসওয়ার্ড লিখুন"
                        value={newPasswordVal} 
                        onChange={(e) => setNewPasswordVal(e.target.value)} 
                        required
                      />
                    </div>
                    
                    <div>
                      <label className="block text-[11px] font-bold text-slate-500 mb-1">পাসওয়ার্ড নিশ্চিত করুন *</label>
                      <input 
                        type="password" 
                        className="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:outline-none font-bold"
                        placeholder="পুনরায় পাসওয়ার্ড লিখুন"
                        value={confirmPasswordVal} 
                        onChange={(e) => setConfirmPasswordVal(e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  <div className="flex gap-2.5 pt-2">
                    <button 
                      type="button" 
                      onClick={() => setIsChangePasswordModalOpen(false)}
                      className="flex-1 py-1.5 text-xs font-bold text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200 cursor-pointer"
                    >
                      বাতিল
                    </button>
                    <button 
                      type="submit"
                      className="flex-1 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl cursor-pointer"
                    >
                      পরিবর্তন নিশ্চিত করুন
                    </button>
                  </div>
                </>
              )}
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Declare New Holiday */}
      {isHolidayModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-100 text-left">
          <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-100 animate-in zoom-in-95 duration-150">
            <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200/80 flex justify-between items-center">
              <h3 className="font-bold text-slate-800 text-xs sm:text-sm flex items-center gap-1.5">
                <Calendar size={16} className="text-emerald-600" /> নতুন ছুটি ঘোষণা (Declare Holiday)
              </h3>
              <button type="button" onClick={() => setIsHolidayModalOpen(false)} className="text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer">
                <X size={18} />
              </button>
            </div>
            
            <form onSubmit={handleAddHoliday} className="p-5 space-y-4">
              
              {/* Holiday type selection radio segment */}
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">ছুটির ধরণ</label>
                <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setHolidayType('direct')}
                    className={`py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                      holidayType === 'direct' ? 'bg-white text-slate-800 shadow-xs' : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    সরাসরি বিশেষ ছুটি
                  </button>
                  <button
                    type="button"
                    onClick={() => setHolidayType('general')}
                    className={`py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                      holidayType === 'general' ? 'bg-white text-slate-800 shadow-xs' : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    সাধারণ / সাপ্তাহিক
                  </button>
                </div>
              </div>

              {/* Holiday Reason */}
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1">ছুটির নাম বা কারণ *</label>
                <input 
                  type="text" 
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none placeholder:text-slate-400 font-semibold" 
                  value={holidayName} 
                  onChange={(e) => setHolidayName(e.target.value)}
                  placeholder={holidayType === 'direct' ? 'যেমন: স্বাধীনতা দিবস, শবে বরাত ইত্যাদি' : 'যেমন: সাপ্তাহিক শুক্রবার ছুটি'}
                  required
                />
              </div>

              {/* Specific Date input if HolidayType === 'direct' */}
              {holidayType === 'direct' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">ছুটির নির্দিষ্ট তারিখ *</label>
                  <input 
                    type="date" 
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none font-bold" 
                    value={holidayDate} 
                    onChange={(e) => setHolidayDate(e.target.value)}
                    required
                  />
                </div>
              )}

              {/* Day of Week select dropdown if HolidayType === 'general' */}
              {holidayType === 'general' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">স্থায়ী সাপ্তাহিক সচল দিন *</label>
                  <select
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none font-semibold cursor-pointer"
                    value={holidayDayOfWeek}
                    onChange={(e) => setHolidayDayOfWeek(e.target.value)}
                    required
                  >
                    <option value="শুক্রবার">শুক্রবার (Friday)</option>
                    <option value="শনিবার">শনিবার (Saturday)</option>
                    <option value="রবিবার">রবিবার (Sunday)</option>
                    <option value="সোমবার">সোমবার (Monday)</option>
                    <option value="মঙ্গলবার">মঙ্গলবার (Tuesday)</option>
                    <option value="বুধবার">বুধবার (Wednesday)</option>
                    <option value="বৃহস্পতিবার">বৃহস্পতিবার (Thursday)</option>
                  </select>
                </div>
              )}

              <div className="flex gap-2.5 pt-2">
                <button 
                  type="button" 
                  onClick={() => setIsHolidayModalOpen(false)}
                  className="flex-1 py-1.5 text-xs font-bold text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200 cursor-pointer"
                >
                  বাতিল
                </button>
                <button 
                  type="submit"
                  className="flex-1 py-1.5 text-xs font-bold text-white bg-emerald-600 rounded-xl hover:bg-emerald-700 transition cursor-pointer"
                >
                  ছুটি ঘোষণা করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Custom Confirmation Modal */}
      {confirmModal && confirmModal.isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-100 text-left">
          <div className="bg-white rounded-2xl shadow-xl max-w-sm w-full overflow-hidden border border-slate-100 p-5 space-y-4">
            <h4 className="font-extrabold text-slate-900 text-sm flex items-center gap-1.5">
              ⚠️ {confirmModal.title}
            </h4>
            <p className="text-xs text-slate-600 font-semibold leading-relaxed">
              {confirmModal.message}
            </p>
            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setConfirmModal(null)}
                className="flex-1 py-2 text-xs font-bold text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200 cursor-pointer"
              >
                বাতিল (Cancel)
              </button>
              <button
                type="button"
                onClick={confirmModal.onConfirm}
                className="flex-1 py-2 text-xs font-bold text-white bg-emerald-600 rounded-xl hover:bg-emerald-700 transition cursor-pointer"
              >
                হ্যাঁ, নিশ্চিত (Confirm)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Custom Alert Modal */}
      {alertModal && alertModal.isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-100 text-left">
          <div className="bg-white rounded-2xl shadow-xl max-w-sm w-full overflow-hidden border border-slate-100 p-5 space-y-4">
            <h4 className="font-extrabold text-slate-900 text-sm flex items-center gap-1.5">
              📢 {alertModal.title}
            </h4>
            <p className="text-xs text-slate-600 font-semibold leading-relaxed">
              {alertModal.message}
            </p>
            <div className="flex pt-1.5">
              <button
                type="button"
                onClick={() => setAlertModal(null)}
                className="w-full py-2 text-xs font-bold text-white bg-emerald-600 rounded-xl hover:bg-emerald-700 transition cursor-pointer"
              >
                ঠিক আছে (OK)
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

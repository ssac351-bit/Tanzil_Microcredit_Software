/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Organization, Staff } from './types';
import LoginScreen from './components/LoginScreen';
import SuperAdminDashboard from './components/SuperAdminDashboard';
import OrgAdminDashboard from './components/OrgAdminDashboard';
import BranchManagerDashboard from './components/BranchManagerDashboard';

export default function App() {
  // Authentication states
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userRole, setUserRole] = useState<'super_admin' | 'org_admin' | 'bm' | 'staff' | null>(null);
  const [activeOrg, setActiveOrg] = useState<Organization | null>(null);
  const [activeStaff, setActiveStaff] = useState<Staff | null>(null);

  // Organizations registry (synced centrally via localstorage)
  const [organizations, setOrganizations] = useState<Organization[]>(() => {
    const saved = localStorage.getItem('tanzil_orgs');
    return saved ? JSON.parse(saved) : [];
  });

  // Sync organizations state to localstorage
  useEffect(() => {
    localStorage.setItem('tanzil_orgs', JSON.stringify(organizations));
  }, [organizations]);

  // Handle successful login
  const handleLoginSuccess = (role: 'super_admin' | 'org_admin' | 'bm' | 'staff', activeOrganization?: Organization, matchedStaff?: Staff) => {
    setUserRole(role);
    if (role === 'org_admin' && activeOrganization) {
      setActiveOrg(activeOrganization);
      setActiveStaff(null);
    } else if ((role === 'bm' || role === 'staff') && activeOrganization && matchedStaff) {
      setActiveOrg(activeOrganization);
      setActiveStaff(matchedStaff);
    } else {
      setActiveOrg(null);
      setActiveStaff(null);
    }
    setIsLoggedIn(true);
  };

  // Handle logout
  const handleLogout = () => {
    setIsLoggedIn(false);
    setUserRole(null);
    setActiveOrg(null);
    setActiveStaff(null);
  };

  const handleUpdateOrg = (updatedOrg: Organization) => {
    setActiveOrg(updatedOrg);
    setOrganizations(prev => prev.map(o => o.id === updatedOrg.id ? updatedOrg : o));
  };

  // ROUTER CONTROLS
  if (isLoggedIn) {
    if (userRole === 'super_admin') {
      return (
        <SuperAdminDashboard 
          organizations={organizations}
          setOrganizations={setOrganizations}
          onLogout={handleLogout}
        />
      );
    } else if (userRole === 'org_admin' && activeOrg) {
      return (
        <OrgAdminDashboard 
          org={activeOrg}
          onLogout={handleLogout}
          onUpdateOrg={handleUpdateOrg}
        />
      );
    } else if (userRole === 'bm' && activeOrg && activeStaff) {
      return (
        <BranchManagerDashboard
          org={activeOrg}
          staff={activeStaff}
          onLogout={handleLogout}
        />
      );
    } else if (userRole === 'staff' && activeOrg && activeStaff) {
      return (
        <BranchManagerDashboard
          org={activeOrg}
          staff={activeStaff}
          onLogout={handleLogout}
        />
      );
    }
  }

  // Fallback to beautiful dual Login Screen
  return (
    <LoginScreen 
      organizations={organizations}
      onLoginSuccess={handleLoginSuccess}
    />
  );
}
